<template>
  <v-row no-gutters>
    <v-col cols="9">
      <v-card height="100%">
        <v-card-title>批量设备选择</v-card-title>
        <v-spacer />
        <v-text-field
          v-model="search"
          prepend-inner-icon="search"
          label="Search"
          hide-details
        />
        <v-data-table
          v-model="selected"
          :headers="deviceHeaders"
          :items="deviceList"
          :search="search"
          item-key="address"
          show-select
          :loading="tableLoading"
          disable-pagination
          hide-default-footer
          loading-text="载入设备中"
        >
        </v-data-table>
      </v-card>
    </v-col>
    <v-col cols="3">
      <v-card outlined height="100%" style="margin-left: 8px">
        <v-card-title
          >已选择设备{{ '(' + selected.length + ')台' }}</v-card-title
        >
        <v-list dense>
          <v-subheader>点击可取消选中</v-subheader>
          <v-list-item-group v-model="item" color="primary">
            <v-list-item v-for="(item, i) in selected" :key="i">
              <v-list-item-content>
                <v-list-item-title
                  v-text="item.address"
                  @click="removeSelected(item)"
                />
              </v-list-item-content>
            </v-list-item>
          </v-list-item-group>
        </v-list>
        <v-card-actions>
          <template>
            <slot name="Button1" />
            <slot name="Button2" />
          </template>
        </v-card-actions>
      </v-card>
    </v-col>
  </v-row>
</template>

<script>
export default {
  name: 'MutilDeviceSelector',
  data: () => ({
    boomerServer: 'http://' + process.env.VUE_APP_BOOMER_SERVER,
    onlineSubject:
      process.env.NODE_ENV === 'development'
        ? 'boomer.test.online_devices'
        : 'boomer.online_devices',
    deviceHeaders: [
      { text: '设备平台', value: 'platform' },
      { text: '设备IP', value: 'ip' },
      { text: '设备端口', value: 'port' },
      { text: '账号', value: 'account' },
      { text: 'GroupID', value: 'group_id' },
      { text: '服务器名称', value: 'serverName' }
    ],
    tableLoading: true,
    deviceList: [],
    selected: [],
    item: 0,
    search: ''
  }),
  methods: {
    print(e) {
      console.log(e)
    },
    updateSelected() {
      //  使用当前设备来更新已选中的设备, 删除选中设备中已经不在线的设备
      //  处理方法是取 this.selected 和 this.deviceList 交集, 作为 selected 的新值
      const newSelected = []
      this.deviceList.map(item => {
        this.selected.map(selectedItem => {
          if (item.address === selectedItem.address) {
            newSelected.push(item)
          }
        })
      })
      this.selected = newSelected
    },
    removeSelected(device) {
      this.selected = this.selected.filter(
        item => item.address !== device.address
      )
    },
    handelSetDevice(dList) {
      const devices = dList
      this.deviceList = Object.values(devices)
      this.deviceList = this.deviceList.map(item => {
        let address
        address = item.ip + ':' + item.port
        return { ...item, address }
      })
      this.tableLoading = false
      this.updateSelected()
    },
    loadDevices() {
      this.deviceList = []
      let formData = new FormData()
      this.axios({
        method: 'post',
        url: this.boomerServer + '/boomer/online_devices',
        data: formData,
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }).then(res => {
        if (res.status === 200 && res.data.status === 0) {
          this.handelSetDevice(res.data.data)
        }
      })
      this.$nats.subscribe(this.onlineSubject, event => {
        this.handelSetDevice(event)
      })
    }
  },
  mounted() {
    this.loadDevices()
  }
}
</script>

<style scoped></style>

<template>
  <MonacoEditor
    ref="codeEditor"
    theme="vs-dark"
    class="editor"
    language="lua"
  />
</template>

<script>
export default {
  name: 'CodeEditorWidget',
  data: function() {
    return {
      editor: null
    }
  },
  mounted() {
    this.editor = this.$refs.editor.getEditor()
    //  快捷键绑定
  }
}
</script>

<style scoped></style>

<template lang="pug">
div
  v-container(fluid)
    v-data-table(
      :headers="headers",
      :items="brands",
      :search="search",
      class="elevation-1",
      :sort-by.sync="sortBy",
      :sort-desc.sync="sortDesc"
    )
      //-
        template(v-slot:item="{item}")
          tr(:class="set_row_class(item.lock_status)")
            td
              center {{item.excel_name}}
            td
              center {{item.excel_path}}
            td
              center
                span(v-if="item.lock_status==1") 占用
                span(v-if="item.lock_status==0") 未占用
            td
              center {{item.lock_user.first_name}}
            td
              center {{item.lock_time}}
            td
              v-btn.mx-0(fab, color="error", small, @click="onLock(0,item)", v-if="item.lock_status==1 && checked_user(item)", :loading="lock_loading")
                v-icon() lock
              v-btn.mx-0(fab, color="primary", small, @click="onLock(1,item)", v-if="item.lock_status==0", :loading="lock_loading")
                v-icon() lock_open
      template(v-slot:top)
        v-text-field(v-model="search",label="表格名搜索",class="mx-4")
      template(v-slot:item.lock_status="{ item }")
        span(v-if="item.lock_status==1") 占用
        span(v-if="item.lock_status==0") 未占用
      template(v-slot:item.action="{ item }")
        v-btn.mx-0(fab, color="error", small, @click="onLock(0,item)", v-if="item.lock_status==1 && checked_user(item)", :loading="lock_loading")
          v-icon() lock
        v-btn.mx-0(fab, color="primary", small, @click="onLock(1,item)", v-if="item.lock_status==0", :loading="lock_loading")
          v-icon() lock_open
        v-btn(
          fab,
          small,
          color="#3296fa",
          v-if="item.lock_status==1 && !checked_user(item)",
          @click="sendDing(item)"
        )
          span(class="dingding")
        //-w
          v-btn.mx-0(text, icon, small, @click="onapply(item)", v-if="item.lock_status==1 && !checked_user(item)", :loading="lock_loading")
            v-icon(color="primary") send

</template>

<script>

import store from '@/store'

export default {
  props: [],
  data: () => ({
    headers: [ // headers表头数组，里面是对象
      { text: '表格名称', align: 'center', value: 'excel_name', sortable: true },
      { text: '路径', align: 'center', value: 'excel_path', sortable: false },
      { text: '占用状态', align: 'center', value: 'lock_status', sortable: true },
      { text: '最近操作', align: 'center', value: 'lock_user.first_name', sortable: false },
      { text: '时间', align: 'center', value: 'lock_time', sortable: false },
      { text: '操作', align: 'center', value: 'action', sortable: false }
    ],
    brands: [],
    search: '',
    lock_log: '',
    lock_loading: false,
    sortBy: 'count',
    sortDesc: true,
    commonList: []
  }),
  components: {
  },
  created: function() {
    this.getCommonList()
  },
  watch: {
  },
  computed: {
    user: () => store.getters.user
  },
  methods: {
    checked_user: function(item) {
      let lockUser = item.lock_user
      if (lockUser) {
        if (this.user.username !== lockUser.job_number) {
          return false
        }
      }
      return true
    },
    onLock: function(status, item) {
      this.lock_loading = true
      let myDate = new Date()
      let nowTime = this.time_format(myDate, 'yyyy-MM-ddThh:mm:ss')
      let url = '/excellock/excel/' + item.id + '/'
      this.axios
        .patch(url, {
          lock_status: status,
          lock_user_id: this.user.id,
          lock_time: nowTime
        })
        .then(res => {
          let msg = {
            color: 'info',
            text: '操作成功'
          }
          this.$emit('lock_alert', msg)
          this.$emit('update_locked_list')
          this.getCommonList()
          this.lock_loading = false
        })
    },
    updateExcelList: function() {
      this.axios
        .get('/excellock/excel/')
        .then(res => {
          this.brands = res.data
          for (let i = 0; i < this.brands.length; i++) {
            let id = this.brands[i].id
            if (this.commonList.hasOwnProperty(id)) {
              this.brands[i].count = this.commonList[id]
            } else {
              this.brands[i].count = 0
            }
          }
          console.log(this.brands)
        })
    },
    getCommonList: function() {
      this.axios
        .get('/excellock/excel/get_common_list')
        .then(res => {
          this.commonList = res.data
          console.log(this.commonList)
          this.updateExcelList()
        })
    },
    set_row_class: function(status) {
      if (status === 1) {
        return 'row_red'
      }
    },
    sendDing: function(excel) {
      let url = '/excellock/excel/send_notice/'
      console.log(this.user)
      let params = {
        send_name: this.user.firstName,
        excel_path: excel.excel_path,
        job_number: excel.lock_user.job_number
      }
      this.axios
        .post(url, params)
        .then(res => {
          let msg = {
            color: 'info',
            text: '操作成功'
          }
          this.$emit('lock_alert', msg)
          this.$emit('update_locked_list')
        })
    },
    time_format: function(datatime, fmt) {
      let date = new Date(datatime)
      if (/(y+)/.test(fmt)) {
        fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length))
      }
      let o = {
        'M+': date.getMonth() + 1,
        'd+': date.getDate(),
        'h+': date.getHours(),
        'm+': date.getMinutes(),
        's+': date.getSeconds()
      }
      for (var k in o) {
        if (new RegExp('(' + k + ')').test(fmt)) {
          var str = o[k] + ''
          fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? str : ('00' + str).substr(str.length))
        }
      }
      return fmt
    }
  }
}
</script>
<style lang='sass'>
.v-btn--active
  background-color: green

.row_red
  background-color: #FFC107
</style>

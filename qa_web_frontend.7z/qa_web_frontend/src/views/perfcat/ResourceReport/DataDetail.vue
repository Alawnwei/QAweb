<template lang="pug">
div
  v-form
    v-container(fluid)
      v-row(align="center")
        v-col.d-flex(cols="12", md="2")
          v-select(:items="jobList", label="选择 Job", v-model="searchParams.jobId", required)
        v-col.d-flex(cols="12", md="2")
          v-select(:items="resourceTypeList", label="过滤资源种类", v-model="searchParams.resourceType", required)
        //- v-col.d-flex(cols="12", md="3")
        //-   v-text-field(label="资源路径（模糊）", v-model="searchParams.resourceName")
        v-col.d-flex(cols="12", md="2")
          v-btn.mx-auto(@click="onClickSearch", bottom, dark, :loading="searchButton.loading") 查询
    v-container
      v-row
        v-col.d-flex(cols="12", md="12")
          v-select(:items="filterKeySelections", label="选择列", hint="选择要显示的列", v-model="showColumns", multiple, chips, persistent-hint)
  data-table(:tableData="tableData", :showColumns="showColumns")
</template>

<script>
import DataTable from './DataTable'
import StatCard from './StatCard'
import _ from 'lodash'

export default {
  data: function() {
    return {
      jobList: [],
      resourceTypeList: [],
      tableData: [],
      filterKeySelections: [],
      searchParams: {
        jobId: null,
        resourceType: null,
        resourceName: null
      },
      showColumns: [],
      searchButton: {
        loading: false
      }
    }
  },
  components: {
    'data-table': DataTable,
    'stat-card': StatCard
  },
  props: [],
  watch: {
    'searchParams.resourceType': function(newVal) {
      this.filterKeySelections = _.find(
        this.resourceTypeList,
        o => o.value === newVal
      ).param_keys

      this.showColumns = []
    }
  },
  mounted: function() {
    this.getJobList()
    this.getResourceTypeList()
  },
  methods: {
    getJobList: function() {
      this.axios
        .get('/perfcat/jobs/', {
          job_type: 1
        })
        .then(res => {
          this.jobList = res.data.results.map(o => {
            return {
              text: o.job_label,
              value: o.id
            }
          })
          this.searchParams.jobId = this.jobList[0].value
        })
    },
    getResourceTypeList: function() {
      this.axios.get('/perfcat/resource_types/').then(res => {
        this.resourceTypeList = res.data.map(o => {
          return {
            text: o.name,
            value: o.id,
            param_keys: o.parameter_keys
          }
        })
        this.searchParams.resourceType = this.resourceTypeList[0].value
      })
    },
    updateData: function() {
      return this.axios
        .get('/perfcat/resource_test_results/', {
          params: {
            resource__resource_type_id: this.searchParams.resourceType,
            job: this.searchParams.jobId,
            resource__virtual_path__contains: this.searchParams.resourceName
          }
        })
        .then(res => {
          this.tableData = res.data
        })
    },
    onClickSearch: function() {
      this.searchButton.loading = true
      this.updateData().then(() => {
        this.searchButton.loading = false
      })
    }
  }
}
</script>

<template lang="pug">
v-app
  v-container
    v-row(class="fill-height")
      v-col
        v-sheet(height="64")
          v-toolbar(flat,color="white")
            v-btn.mr-4(outlined, color="grey darken-2" @click="setToday")
              span Today
            v-btn(fab,text,small,color="grey darken-2",@click="prev")
              v-icon(small) mdi-chevron-left
            v-btn(fab,text,small,color="grey darken-2",@click="next")
              v-icon(small) mdi-chevron-right
            v-toolbar-title {{ title }}
            v-spacer
            v-btn.mr-5(color="warning" @click="goPage()") 排班
            v-menu(bottom,right)
              template(v-slot:activator="{ on }")
                v-btn(outlined,color="grey darken-2",v-on="on")
                  span {{ dutyType[type].name }}
                  v-icon(right) mdi-menu-down
              v-list
                v-list-item(@click="type = 'day' ")
                  v-list-item-title 值日表
                v-list-item(@click="type = 'week' ")
                  v-list-item-title 值周表
                v-list-item(@click="type = 'all' ")
                  v-list-item-title 所有值班
        v-sheet(height="1000")
          v-calendar(
            ref="calendar",
            v-model="focus",
            color="primary",
            :now="today",
            :events="events",
            :event-color="getEventColor",
            :event-height="eventHeight",
            type="month",
            :weekdays="weekendays"
            @change="updateRange"
          )
            template(v-slot:day-label="{present, year, month, day}")
              v-btn(depressed, fab, rounded, small, :color="present?'primary':'transparent'")
                span {{getDay(month, day)}}
              v-spacer
              span {{lunnerDay(year, month, day)}}

</template>

<script>
import store from '@/store'
import lunnerCalendar from '@/plugins/lunnerCalendar'
export default {
  data: () => ({
    focus: '',
    start: null,
    end: null,
    today: '',
    group_data: [],
    tmpEvents: [],
    events: [],
    eventHeight: 24,
    colors: ['blue', 'cyan', 'green', 'orange', 'indigo', 'deep-purple', 'grey darken-1'],
    type: 'day',
    weekendays: [1, 2, 3, 4, 5, 6, 0],
    dutyType: {
      day: {
        type: 1,
        name: '值日表'
      },
      week: {
        type: 2,
        name: '值周表'
      },
      all: {
        type: 0,
        name: '所有值班'
      }
    }
  }),
  props: {},
  created: function() {
    this.today = this.formatDate(new Date(), 0)
  },
  computed: {
    user: () => store.getters.user,
    title: function() {
      const { start, end } = this
      if (!start || !end) {
        return ''
      }
      const startMonth = this.monthFormatter(start)
      // const endMonth = this.monthFormatter(end)
      const startYear = start.year
      // const endYear = end.year

      return `${startMonth} ${startYear}`
    },
    monthFormatter: function() {
      return this.$refs.calendar.getFormatter({
        timeZone: 'UTC',
        month: 'long'
      })
    }
  },
  methods: {
    setToday: function() {
      this.focus = this.today
    },
    prev: function() {
      this.$refs.calendar.prev()
    },
    next: function() {
      this.$refs.calendar.next()
    },
    goPage: function() {
      window.location.href = '/checklist/dutymanager'
    },
    get_duty_groups: function() {
      let refreshType = this.dutyType[this.type].type
      let params = {}
      if (refreshType !== 0) {
        params = {
          refresh_type: refreshType
        }
      }
      this.axios.get('/checklist/duty_groups/', { params: params }).then(res => {
        this.group_data = res.data
      })
    },
    getDutyDate: function(groupId) {
      let tempStart = this.checkdate(this.start, 1)
      let tempEnd = this.checkdate(this.end, 7)
      let startDate = this.compareDate(this.today, tempStart) ? this.today : tempStart
      let url = '/checklist/duty_groups/' + groupId + '/predict_duty_list_between_date/'
      let params = {
        start_date: startDate,
        end_date: tempEnd
      }
      this.axios.get(url, { params: params }).then(res => {
        this.dealDuty(res.data.data, groupId)
      })
    },
    dealDuty: function(dutyDateList, groupId) {
      let user = []
      let startDate
      let endDate
      for (let date in dutyDateList) {
        if (user.toString() !== dutyDateList[date].toString()) {
          this.showDuty(user, startDate, endDate, groupId)
          startDate = date
          endDate = date
          user = dutyDateList[date]
        } else {
          endDate = date
        }
      }
      this.showDuty(user, startDate, endDate, groupId)
    },
    showDuty: async function(uids, startDate, endDate, groupId) {
      let users = []
      if (uids.length === 0) {
        return
      }
      for (let i in uids) {
        let userdata = await this.get_user_data(uids[i])
        users.push(userdata.first_name)
      }
      this.events.push({
        name: users.join('，'),
        start: startDate,
        end: endDate,
        color: this.colors[groupId],
        groupId: groupId
      })
      // console.log(this.events.map(x => x.end), '1')
      this.events.sort(this.compare)
    },
    get_user_data: function(uid) {
      let url = '/auth/users/' + uid
      return this.axios.get(url, {}).then(res => {
        let userData = res.data
        return userData
      })
    },
    compare: function(val1, val2) {
      return val1.groupId - val2.groupId
    },
    getEventColor: function(event) {
      return event.color
    },
    updateRange: function({ start, end }) {
      this.start = start
      this.end = end
      this.get_duty_groups(this.type)
    },
    compareDate: function(date1, date2) {
      let oDate1 = new Date(date1)
      let oDate2 = new Date(date2)
      return oDate1.getTime() > oDate2.getTime()
    },
    checkdate: function(date, day) {
      let weekday = date.weekday
      let intervalTime = (weekday - day) * 24 * 60 * 60 * 1000
      let tempDate = new Date(date.date)
      tempDate = tempDate - intervalTime
      let newDate = new Date(tempDate)
      let needDate = this.formatDate(newDate, 0)
      return needDate
    },
    formatDate: function(a, withTime) {
      return withTime ? `${a.getFullYear()}-${a.getMonth() + 1}-${a.getDate()} ${a.getHours()}:${a.getMinutes()}` : `${a.getFullYear()}-${a.getMonth() + 1}-${a.getDate()}`
    },
    lunnerDay: function(y, m, d) {
      let lunner = lunnerCalendar.solar2lunar(y, m, d)
      if (lunner.isFestival) {
        return lunner.festival.join(',')
      }
      if (lunner.isTerm) {
        return lunner.Term
      }
      if (lunner.IDayCn === '初一') {
        return lunner.IMonthCn
      }
      return lunner.IDayCn
    },
    getDay: function(m, d) {
      if (d === 1) {
        return '' + m + '月' + d + '日'
      }
      return '' + d + '日'
    }
  },
  watch: {
    group_data: function(newData, oldData) {
      this.events = []
      newData.forEach(v => {
        this.getDutyDate(v.id)
      })
    },
    type: function(newDate, oldDate) {
      this.get_duty_groups()
    }
  },
  components: {}
}
</script>

<style lang="sass">
.pl-1
  font-size: 16px
</style>

import axios from 'axios'
import VueAxios from 'vue-axios'
import Vue from 'vue'
import store from './store'

if (process.env.NODE_ENV === 'development') {
  axios.defaults.baseURL = 'http://localhost:8000'
} else {
  axios.defaults.baseURL = 'http://qc-procat.ejoy.com:8210' // TODO 填写后端地址
}

axios.interceptors.request.use(config => {
  if (store.getters.jwtToken) {
    config.headers['Authorization'] = 'Bearer ' + store.getters.jwtToken
  }
  return config
})

Vue.use(VueAxios, axios)

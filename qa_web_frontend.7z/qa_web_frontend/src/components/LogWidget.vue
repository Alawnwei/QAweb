<template>
  <div>
    <MonacoEditor
      ref="editor"
      v-model="logMsg"
      theme="vs-dark"
      class="editor"
      language="lua"
    />
    <v-toolbar dense height="48px">
<!--      <v-toolbar-title>日志级别: </v-toolbar-title>-->
<!--      <v-chip-group-->
<!--        v-model="logLevel"-->
<!--        column-->
<!--        multiple-->
<!--      >-->
<!--        <v-chip filter outlined>debug</v-chip>-->
<!--        <v-chip filter outlined>info</v-chip>-->
<!--        <v-chip filter outlined>warning</v-chip>-->
<!--        <v-chip filter outlined>error</v-chip>-->
<!--      </v-chip-group>-->

      <v-spacer></v-spacer>

      <v-toolbar-items>
        <v-switch v-model="scrollToEnd" label="总是显示最新log" style="margin-top: 12px"/>
        <v-btn text @click="empty">清空</v-btn>
      </v-toolbar-items>
    </v-toolbar>
  </div>

</template>

<script>
import MonacoEditor from 'vue-monaco'

export default {
  name: 'LogWidget',
  components: { MonacoEditor },
  props: ['logTopic'],
  data: function () {
    return {
      logLevel: [],
      editor: null,
      sidShowLog: null,
      logStorage: [],
      logBuffer: [],
      logMsg: '',
      filter: [],
      search: '',
      scrollToEnd: false
    }
  },

  methods: {
    subscribe: function() {
      this.sidShowLog = this.$nats.subscribe(this.logTopic, (event) => {
        if (event) {
          event.forEach((v, _) => {
            this.logMsg += v + '\n'
          })
        }
        if (this.scrollToEnd) {
          this.editor.revealLine(this.lineCount, 0)
        }
      })
    },
    unsubscribe: function () {
      if (this.sidShowLog != null) {
        this.$nats.unsubscribe(this.sidShowLog)
      }
    },
    clear: function () {
    //  类似 console 的 clear 功能, 并不是直接清空, 而是直接给你一段空行
      this.logMsg += new Array(45).join('\n')
    },
    empty: function () {
      //  清空 log 内容
      this.logMsg = ''
    }
  },
  computed: {
    lineCount: {
      get: function () {
        if (this.logMsg) {
          return this.logMsg.split('\n').length - 1
        }
        return 0
      }
    }
  },
  watch: {
    logTopic: function (newVal, oldVal) {
      if (oldVal != null) {
        this.unsubscribe()
        this.logMsg = ''
      }
      if (newVal != null && this.logTopic != null) {
        this.subscribe()
      }
    },
    scrollToEnd: function (newVal, _) {
      if (newVal) {
        this.editor.revealLine(this.lineCount, 0)
      }
    }
  },
  mounted: function() {
    if (this.logTopic != null) {
      this.subscribe()
    }
    this.editor = this.$refs.editor.getEditor()
    this.editor.updateOptions({ readOnly: true })
  }
}
</script>

<style scoped>

</style>

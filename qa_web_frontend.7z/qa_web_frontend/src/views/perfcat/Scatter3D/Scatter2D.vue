<template>
  <div>
    <v-chart :options="options" @click="onClick" theme="dark" style="width:100%;height:800px;"></v-chart>
  </div>
</template>

<script>
import Echarts from 'vue-echarts/components/ECharts.vue'
import 'echarts/theme/dark'
import 'echarts/lib/chart/scatter'
import 'echarts/lib/component/title'
import 'echarts/lib/component/legend'

export default {
  data: function() {
    return {
      options: {},
      fieldNames: []
    }
  },
  props: ['dataSet', 'dimensions', 'sizeDataRange', 'colorDataRange'],
  watch: {
    dataSet: function() {
      this.updateOptions()
    },
    dimensions: function() {
      this.updateOptions()
    },
    sizeDataRange: function() {
      this.updateOptions()
    },
    colorDataRange: function() {
      this.updateOptions()
    }
  },
  components: {
    'v-chart': Echarts
  },
  methods: {
    onClick: function(event) {
      this.$emit('onClickPos', event.data)
    },
    updateOptions: function() {
      var options = {
        tooltip: {
          formatter: function(params, ticket, callback) {
            var ret = ''
            params.dimensionNames.forEach((element, index) => {
              ret += element
              ret += ' : '
              ret += params.data[index]
              ret += '<br>'
            })

            return ret
          }
        },
        //        dataZoom: [
        //          {
        //            xAxisIndex: 0
        //          },
        //          {
        //            yAxisIndex: 0
        //          }
        //        ],
        visualMap: [
          {
            top: 10,
            calculable: true,
            dimension: 4,
            min: this.colorDataRange[0],
            max: this.colorDataRange[1],
            inRange: {
              color: [
                '#1710c0',
                '#0b9df0',
                '#00fea8',
                '#00ff0d',
                '#f5f811',
                '#f09a09',
                '#fe0300'
              ].reverse()
            },
            realtime: true, // 是否实时刷新
            textStyle: {
              color: '#fff'
            }
          },
          {
            bottom: 10,
            calculable: true,
            dimension: 5,
            min: this.sizeDataRange[0],
            max: this.sizeDataRange[1],
            inRange: {
              symbolSize: [10, 20]
            },
            textStyle: {
              color: '#fff'
            }
          }
        ],
        xAxis: {
          type: 'value',
          name: 'X 坐标'
        },
        yAxis: {
          type: 'value',
          name: 'Y 坐标'
        },
        series: [
          {
            name: '坐标点测试结果',
            type: 'scatter',
            coordinateSystem: 'cartesian2d',
            dimensions: this.dimensions,
            data: this.dataSet,
            symbolSize: 2,
            itemStyle: {
              borderWidth: 0
              // borderColor: 'rgba(255,255,255,0.8)'
            },
            emphasis: {
              itemStyle: {
                color: '#fff'
              }
            }
          }
        ]
      }

      this.options = options
    }
  },
  mounted: function() {
    this.updateOptions()
  }
}
</script>

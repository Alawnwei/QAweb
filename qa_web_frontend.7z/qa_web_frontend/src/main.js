import '@babel/polyfill'
import Vue from 'vue'
import vuetify from './plugins/vuetify'
import App from './App.vue'
import router from './router'
import store from './store'
import './http'
import '@mdi/font/css/materialdesignicons.css'
import vueNats from 'vue-nats'
import VirtualCollection from 'vue-virtual-collection'

Vue.config.productionTip = false

Vue.use(vueNats, {
  url: 'ws://11.158.142.45:20035/nats',
  json: true, // use JSON data payload
  reconnect: true, // always reconnect
  maxReconnectAttempts: -1, // retry forever
  reconnectTimeWait: 1000 // try to reconnect every second
})

Vue.use(VirtualCollection)

new Vue({
  router,
  store,
  vuetify,
  render: h => h(App)
}).$mount('#app')

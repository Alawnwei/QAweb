<template lang="pug">
    v-container
        v-dialog(v-model='dialog')
            v-card
                v-card-title.headline 历史趋势
                v-card-text
                    v-row
                        v-col(cols='8')
                            DeviceSelector(@changeDevice='changeDevice($event)')
                        v-col(cols='4')
                            v-btn(@click='sendJump()') 跳转指令
                    v-row
                        v-col(cols='12')
                            PostionReport(v-if='currentPoint != null', :positionId='currentPoint[3]')
                v-card-actions
                    v-spacer
                    v-btn(color='green darken-1', text='', @click='dialog = false') 关闭

        v-snackbar(v-model='runResult', top='', :timeout='tipsTimeout', :color='tipsColor') {{ runTips }}

        v-row
            v-col(cols="12")
                v-select(:items="jobs", label="选择任务", v-model="job", dense, @change="onChangeJob")

        v-tabs
            v-tab 表格
            v-tab 散点图
            v-tab-item(style="padding:10px")
                v-data-table(:headers="tableHeaders", :items="tableDataSet", sortBy="fps", disable-pagination, hide-default-footer)
                    template(v-slot:item.action='{ item }')
                        v-btn(@click='onClickShowPos(item)') 历史趋势

            v-tab-item(style="padding-left:30px;padding-right:30px;padding-top:20px")
                v-row
                    v-col
                        v-select(:items="fields", label="颜色指示器维度", v-model="colorY", dense, @change="onChangeSelection")
                    v-col
                        v-select(:items="directions", label="颜色指示器指标", v-model="colorX", dense, @change="onChangeSelection")
                    v-col
                        v-select(:items="fields", label="大小指示器维度", v-model="sizeY", dense, @change="onChangeSelection")
                    v-col
                        v-select(:items="directions", label="大小指示器指标", v-model="sizeX", dense, @change="onChangeSelection")
                    v-col(cols="12")
                        v-tabs(dark color="#ffffff")
                            v-tab 2D图
                            v-tab 3D图
                            v-tab-item
                                scatter2d(:dimensions="dimensions" :data-set="dataSet", :color-data-range="colorDataRange", :size-data-range="sizeDataRange", @onClickPos="onClickPos")
                            v-tab-item
                                scatter3d(:dimensions="dimensions" :data-set="dataSet", :color-data-range="colorDataRange", :size-data-range="sizeDataRange", @onClickPos="onClickPos")

</template>

<script>
import Scatter3D from './Scatter3D'
import Scatter2D from './Scatter2D'
import * as utils from './DataUtil'
import _ from 'lodash'
import StatCard from '../ResourceReport/StatCard'
import DeviceSelector from '../../../components/DeviceSelector'
import PostionReport from '../PositionReport/Index'

export default {
  data: function() {
    return {
      boomerServer: 'http://' + process.env.VUE_APP_BOOMER_SERVER,
      runResult: false,
      tipsColor: '',
      runTips: '',
      tipsTimeout: 3000,
      dialog: false,
      currentDevice: null,
      currentPoint: null,
      jobs: [],
      job: null,
      directions: [],
      fields: [],
      colorX: -1,
      colorY: 'fps',
      sizeX: -1,
      sizeY: 'mem',
      dataSet: [],
      tableDataSet: [],
      originalDataSet: {},
      originalPositionIndex: {},
      originalDirectionIndex: {},
      tableHeaders: [
        {
          sortable: false,
          text: '坐标点信息',
          value: 'pos'
        },
        {
          sortable: true,
          text: '帧率',
          value: 'fps'
        },
        {
          sortable: true,
          text: '内存(MB)',
          value: 'mem'
        },
        {
          sortable: true,
          text: 'drawcall',
          value: 'dp'
        },
        {
          sortable: true,
          text: '顶点数',
          value: 'v_count'
        },

        {
          sortable: false,
          text: '操作',
          value: 'action'
        }
      ],
      tableSetting: {
        descending: true,
        sortBy: 'drawcall',
        rowsPerPage: -1
      },
      statItems: [
        {
          title: '最高面数',
          value: 123123
        },
        {
          title: '最低fps',
          value: 20
        }
      ]
    }
  },
  computed: {
    colorDataRange: function() {
      if (this.fields.length !== 0) {
        return _.find(this.fields, o => o.value === this.colorY).range
      }
      return [0, 0]
    },
    sizeDataRange: function() {
      if (this.fields.length !== 0) {
        return _.find(this.fields, o => o.value === this.sizeY).range
      }
      return [0, 0]
    },
    dimensions: function() {
      if (this.directions.length !== 0) {
        return [
          'x',
          'y',
          'z',
          'positionId',
          _.find(this.fields, o => o.value === this.colorY).text +
            ' - ' +
            _.find(this.directions, o => o.value === this.colorX).text,
          _.find(this.fields, o => o.value === this.sizeY).text +
            ' - ' +
            _.find(this.directions, o => o.value === this.sizeX).text
        ]
      }

      return []
    }
  },
  components: {
    scatter3d: Scatter3D,
    scatter2d: Scatter2D,
    'stat-card': StatCard,
    DeviceSelector,
    PostionReport
  },
  mounted: function() {
    this.initFieldNames()
    this.getJobs().then(_ => {
      return this.getOriginalDataSet()
    })
  },
  methods: {
    sendJump: function() {
      var x = this.currentPoint[0]
      var y = this.currentPoint[1]
      var z = this.currentPoint[2]

      let clientId
      if (this.currentDevice.port) {
        clientId = this.currentDevice.ip + ':' + this.currentDevice.port
      } else {
        clientId = this.currentDevice.ip
      }

      let formData = new FormData()
      formData.append('path', 'M6Project/M6项目/指令脚本/jump.lua')
      formData.append('param', JSON.stringify({ X: x, Y: y, Z: z }))
      formData.append('clientId', clientId)

      this.axios({
        method: 'post',
        url: this.boomerServer + '/scripts/run_file',
        data: formData,
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }).then(res => {
        if (res.status === 200 && res.data.status === 0) {
          this.runResult = true
          this.runTips = '发送指令成功'
          this.tipsColor = 'info'
        } else {
          this.runResult = true
          this.runTips = '发送指令失败'
          this.tipsColor = 'error'
        }
      })
    },
    changeDevice: function(newDevice) {
      this.currentDevice = newDevice
    },
    onClickShowPos: function(item) {
      this.currentPoint = item.posData
      this.dialog = true
    },
    onClickPos: function(data) {
      this.currentPoint = data
      this.dialog = true
    },
    onChangeJob: function() {
      this.getOriginalDataSet()
    },
    getJobs: function() {
      return this.axios.get('/perfcat/jobs/').then(res => {
        this.jobs = res.data.results.map(o => {
          return {
            text: o.job_label,
            value: o.id
          }
        })

        if (this.jobs.length > 0) {
          this.job = this.jobs[0].value
        }
      })
    },
    updateChartData: function() {
      this.dataSet = utils.TransformScatterData(
        this.originalDataSet,
        this.originalPositionIndex,
        this.originalDirectionIndex,
        this.colorX,
        this.colorY,
        this.sizeX,
        this.sizeY
      )
    },
    onChangeSelection: function() {
      this.updateChartData()
    },
    initFieldNames: function() {
      this.fields = utils.GetFieldSelectionItems()
    },
    getOriginalDataSet: function() {
      this.axios
        .get('/perfcat/location_test_results/get_default_scatter3d_data/', {
          params: {
            job: this.job
          }
        })
        .then(res => {
          this.directions = utils.GetXSelectionItems(res.data.directions)
          this.tableDataSet = utils.GetTableDataSet(res.data)
          this.originalDataSet = res.data.data
          this.originalPositionIndex = res.data.positions
          this.originalDirectionIndex = res.data.directions
          this.updateChartData()
        })
    }
  }
}
</script>

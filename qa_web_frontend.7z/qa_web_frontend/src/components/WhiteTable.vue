<template lang="pug">
div
  v-container(fluid)
    v-data-table(
      :headers="headers",
      :items="brands",
      :search="search",
      class="elevation-1",
    )
      template(slot="items",slot-scope="props")
      template(v-slot:top)
        v-toolbar(flat,color="white")
          v-dialog(v-model="new_white_data")
            template(v-slot:activator="{ on }")
              v-btn(color="primary" class="mb-2" v-on="on") 新增白名单
            v-card
              v-card-title
                strong 新增白名单
              v-card-text
                v-container
                  v-row
                    v-col(cols="12",sm="6",md="4")
                      v-text-field(v-model="editedItem.file_name" label="文件路径")
                    v-col(cols="12",sm="6",md="4")
                      v-select(
                        v-model="editedItem.file_limit",
                        :items="limit_items",
                        item-text="text",
                        item-value="value",
                        label="有效时间"
                        )
              v-card-actions
                v-spacer
                v-btn(color="blue darken-1",text,@click="add_white_data") 提交
                v-btn(color="blue darken-1",text,@click="new_white_data = false") 关闭
      template(v-slot:item.file_limit="{ item }")
        span {{item.file_limit | formatDate}}
      template(v-slot:item.action="{ item }")
        v-btn(color="blue darken-1",text,@click="confirm_remove(item)") 删除
    v-dialog(v-model="white_del",persistent,max-width="600px")
      v-card
        v-card-title
          span 白名单移除确认
        v-card-text
          div(style="width:80%,margin-left:5%")
              span 你确定要将一下文件移出白名单吗：
              p.mt-2.subtitle
              span
                strong {{ confirm_data.file_name }}
        v-card-actions
          v-spacer
          v-btn(color="blue darken-1",text,@click="white_del = false") 关闭
          v-btn(color="blue darken-1",text,@click="remove_white_data()") 确认

</template>

<script>

import store from '@/store'

function formatDate(date, fmt) {
  if (/(y+)/.test(fmt)) {
    fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length))
  }
  let o = {
    'M+': date.getMonth() + 1,
    'd+': date.getDate(),
    'h+': date.getHours(),
    'm+': date.getMinutes(),
    's+': date.getSeconds()
  }
  for (let k in o) {
    if (new RegExp(`(${k})`).test(fmt)) {
      let str = o[k] + ''
      fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? str : padLeftZero(str))
    }
  }
  return fmt
}

function padLeftZero(str) {
  return ('00' + str).substr(str.length)
}

export default {
  props: [],
  data: () => ({
    headers: [ // headers表头数组，里面是对象
      { text: '文件路径', align: 'center', value: 'file_name', sortable: false },
      { text: '有效时间', align: 'center', value: 'file_limit', sortable: false },
      { text: '操作', align: 'center', value: 'action', sortable: false }
    ],
    brands: [],
    search: '',
    panel: [],
    apply_data: {},
    new_white_data: false,
    editedItem: {
      file_name: '',
      file_limit: ''
    },
    limit_items: [
      { text: '长期', value: '0' },
      { text: '一天', value: '1' },
      { text: '一周', value: '2' },
      { text: '一个月', value: '3' }
    ],
    white_del: false,
    confirm_data: ''
  }),
  components: {
  },
  filters: {
    formatDate(time) {
      console.log(time)
      if (time == null) {
        return '长期'
      }
      time = time * 1000
      let date = new Date(time)
      console.log(date)
      return formatDate(date, 'yyyy-MM-dd hh:mm')
    }
  },
  created: function() {
    this.updateWhiteList()
  },
  watch: {
  },
  computed: {
    user: () => store.getters.user
  },
  methods: {
    updateWhiteList: function() {
      this.axios
        .get('/get_white_list')
        .then(res => {
          this.brands = res.data
          console.log(this.brands)
        })
    },
    close_white_data: function() {
      this.new_white_data = false
    },
    add_white_data: function() {
      console.log(this.editedItem)
      this.axios
        .post('/set_white_file', this.editedItem)
        .then(res => {
          this.new_white_data = false
          let msg = {}
          if (res.data === 'suc') {
            msg = {
              color: 'info',
              text: '操作成功'
            }
          } else {
            msg = {
              color: 'warning',
              text: res.data
            }
          }
          this.$emit('apply_alert', msg)
          this.updateWhiteList()
        })
    },
    confirm_remove: function(item) {
      this.confirm_data = item
      this.white_del = true
    },
    remove_white_data: function() {
      this.axios
        .post('/del_white_file', this.confirm_data)
        .then(res => {
          this.new_white_data = false
          let msg = {}
          if (res.data === 'suc') {
            msg = {
              color: 'info',
              text: '操作成功'
            }
            this.white_del = false
          } else {
            msg = {
              color: 'warning',
              text: res.data
            }
          }
          this.$emit('apply_alert', msg)
          this.updateWhiteList()
        })
    }
  }
}
</script>
<style lang='sass'>
.v-btn--active
  background-color: green
</style>

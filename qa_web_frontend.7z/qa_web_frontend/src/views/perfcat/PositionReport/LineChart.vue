<template lang="pug">
  div.echarts-container
    v-chart(:options="options", style="width:100%")
</template>
<script>
import Echarts from 'vue-echarts/components/ECharts.vue'
import 'echarts/lib/chart/line'
import 'echarts/lib/component/title'
import 'echarts/lib/component/legend'

export default {
  props: ['labels', 'dataset'],
  components: {
    'v-chart': Echarts
  },
  watch: {
    dataset: function() {
      this.updateOptions()
    }
  },
  data: function() {
    return {
      options: {}
    }
  },
  mounted: function() {
    this.updateOptions()
  },
  methods: {
    updateOptions: function() {
      this.options = {
        legend: {},
        tooltip: {},
        xAxis: { type: 'category' },
        yAxis: {},
        dataset: {
          source: this.dataset
        },
        series: [{ type: 'line', seriesLayoutBy: 'row' }]
      }
    }
  }
}
</script>

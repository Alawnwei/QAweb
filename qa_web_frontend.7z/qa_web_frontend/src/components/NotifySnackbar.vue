<template>
  <v-snackbar
    v-model="$attrs.isNotify"
    :timeout="timeout"
    :color="color"
    :left="x === 'left'"
    :right="x === 'right'"
    :top="y === 'top'"
    :bottom="y === 'bottom'"
    @input="$emit('close')"
  >
    {{text}}
    <template v-slot:action="{ attrs }">
      <v-btn
        dark
        text
        v-bind="attrs"
        @click="$emit('close')"
      >
        Close
      </v-btn>
    </template>
  </v-snackbar>
</template>

<script>
export default {
  name: 'NotifySnackbar',
  props: {
    text: {
      type: String,
      default: 'no data'
    },
    timeout: {
      type: Number,
      default: 2000
    },
    color: {
      type: String,
      default: 'error'
    },
    x: {
      type: String,
      default: 'left'
    },
    y: {
      type: String,
      default: 'bottom'
    }
  },
  data: () => {
    return {
      value: false
    }
  }
}
</script>

<style scoped>

</style>

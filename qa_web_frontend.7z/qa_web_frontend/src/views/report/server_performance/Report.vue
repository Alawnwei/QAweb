/* eslint-disable */
<template>
  <div>
    <v-row>
      <v-col cols="3">
        <v-select
          :items="nodes"
          v-model="currentNode"
          label="选择服务器节点"
          solo
        ></v-select>
      </v-col>
      <v-col cols="3">
        <v-text-field
          :value="startTime"
          v-model="startTime"
          label="开始压测时间"
          solo
        ></v-text-field>
      </v-col>
      <v-col cols="3">
        <v-text-field
          :value="endTime"
          v-model="endTime"
          label="结束压测时间"
          solo
        ></v-text-field>
      </v-col>
      <v-col cols="3">
        <v-btn @click="refresh">刷新</v-btn>
      </v-col>
    </v-row>
    <v-row>
      <v-col cols="6" v-for="(option, index) in options" :key="index">
        <v-chart :options="option" />
      </v-col>
    </v-row>
  </div>
</template>

<script>
import Echarts from 'vue-echarts/components/ECharts.vue'
import 'echarts/lib/chart/line'
import 'echarts/lib/component/title'
import 'echarts/lib/component/legend'
import 'echarts/lib/component/tooltip'
import 'echarts/lib/component/dataZoom'
import store from '@/store'
import _ from 'lodash'

export default {
  props: [],
  components: {
    'v-chart': Echarts
  },
  computed: {
    user: () => store.getters.user
  },
  watch: {
    currentNode: function(newVal, _) {
      if (newVal !== null) {
        this.fetchData()
      }
    }
  },
  data: function() {
    return {
      startTime: '',
      endTime: '',
      currentNode: null,
      nodes: [],
      boomerServer: 'http://' + process.env.VUE_APP_BOOMER_SERVER,
      optionTemplate: {
        title: {
          text: ''
        },
        tooltip: {
          show: true,
          trigger: 'axis',
          axisPointer: {
            animation: false
          }
        },
        dataZoom: [
          {
            show: true,
            start: 0,
            end: 100
          }
        ],
        xAxis: {
          data: []
        },
        yAxis: {
          type: 'value'
        },
        series: [
          {
            data: [],
            type: 'line'
          }
        ]
      },
      options: [],
      metrics: {
        gs_cpu_use: {
          name: 'CPU使用率'
        },
        gs_vms: {
          name: 'gs_vms'
        },
        gs_rss: {
          name: 'gs_rss'
        }
      }
    }
  },
  methods: {
    formatDate: function(timestamp) {
      var date = new Date(timestamp * 1000)
      var Y = date.getFullYear() + '-'
      var M =
        (date.getMonth() + 1 < 10
          ? '0' + (date.getMonth() + 1)
          : date.getMonth() + 1) + '-'
      var D =
        (date.getDate() < 10 ? '0' + date.getDate() : date.getDate()) + ' '
      var h =
        (date.getHours() < 10 ? '0' + date.getHours() : date.getHours()) + ':'
      var m =
        (date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes()) +
        ':'
      var s =
        date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds()
      return Y + M + D + h + m + s
    },
    getNodes: function() {
      let uri = 'api/v1/series'
      let host = 'm6-prometheus.mid-test.ejoy.com'
      let matchKey = encodeURI('match[]')
      let matchValue = encodeURI('gs_cpu_use{group=~"default"}')
      let curDate = Date.parse(new Date()) / 1000
      let start = curDate - 24 * 3600
      let end = curDate
      this.axios
        .get(
          this.boomerServer +
            '/prometheus/proxy/?target-uri=' +
            uri +
            '&target-host=' +
            host +
            '&' +
            matchKey +
            '=' +
            matchValue +
            '&end=' +
            end +
            '&start=' +
            start
        )
        .then(res => {
          if (res.status === 200) {
            let data = res.data.data
            this.nodes = []
            for (let i = 0; i < data.length; i++) {
              this.nodes.push(data[i].node)
            }
            if (this.nodes.length > 0) {
              this.currentNode = this.nodes[0]
            }
          }
        })
    },
    refresh: function() {
      this.fetchData()
    },
    fetchData: function() {
      let start = new Date(this.startTime).getTime() / 1000
      let end = new Date(this.endTime).getTime() / 1000
      let group = 'default' // this.$route.query.group
      let node = this.currentNode // this.$route.query.node
      let host = 'm6-prometheus.mid-test.ejoy.com'
      let uri = 'api/v1/query_range'
      let axiosArray = []
      for (let metric in this.metrics) {
        if (group !== undefined && node !== undefined) {
          metric = encodeURI(
            metric + '{group=~"' + group + '",node=~"' + node + '"}'
          )
        }
        let newPromise = this.axios({
          method: 'get',
          url:
            this.boomerServer +
            '/prometheus/proxy/?target-uri=' +
            uri +
            '&target-host=' +
            host +
            '&query=' +
            metric +
            '&start=' +
            start +
            '&end=' +
            end +
            '&step=30'
        })
        axiosArray.push(newPromise)
      }
      this.axios.all(axiosArray).then(
        this.axios.spread((...responses) => {
          this.options = []
          responses.forEach(res => {
            if (res.status === 200) {
              let result = res.data.data.result[0]
              let metric = result.metric.__name__
              let metricName = this.metrics[metric].name
              let option = _.cloneDeep(this.optionTemplate)
              for (let i = 0; i < result.values.length; i++) {
                let item = result.values[i]
                option.title.text = metricName
                option.xAxis.data.push(this.formatDate(item[0]))
                option.series[0].data.push(item[1])
              }
              this.options.push(option)
              console.log(this.options)
            } else {
            }
          })
        })
      )
    }
  },
  mounted: function() {
    this.startTime = this.formatDate(Number(this.$route.query.start))
    this.endTime = this.formatDate(Number(this.$route.query.end))
    this.getNodes()
  }
}
</script>

<style></style>

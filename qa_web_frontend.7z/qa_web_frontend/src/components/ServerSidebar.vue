<template>
  <v-navigation-drawer
    bottom
    floating
    absolute
    v-model="value"
  >
    <v-list>
      <v-list-item class="px-2">
        <v-list-item-avatar>
          <v-icon>mdi-server-network</v-icon>
        </v-list-item-avatar>
        <v-list-item-content>
          <v-list-item-title class="title">服务器列表</v-list-item-title>
        </v-list-item-content>
        <v-icon @click="close">mdi-close-circle </v-icon>
      </v-list-item>
    </v-list>
    <v-divider></v-divider>
    <v-list-group
      value="true"
      prepend-icon="mdi-server"
      v-for="serverType in serverTypes"
      :key="serverType"
    >
      <template v-slot:activator>
        <v-list-item-title v-text="serverType" style="text-transform: uppercase"></v-list-item-title>
      </template>
      <div
        v-for="server in servers"
        :key="server.group_id"
      >
        <v-list-item
          v-if="server.group === serverType"
          @click="onSelectedServer(server)"
        >
          <v-list-item-action v-if="currentServer[server.group]===server.address">
            <v-icon color="primary">mdi-arrow-right-bold </v-icon>
          </v-list-item-action>
          <v-list-item-title v-text="server.name"></v-list-item-title>
          <v-list-item-icon>
            <v-tooltip bottom>
              <template v-slot:activator="{ on, attrs }">
                <v-icon v-bind="attrs" v-on="on">
                  mdi-server-minus
                </v-icon>
              </template>
              <span style="white-space: pre-line">{{formatter(server)}}</span>
            </v-tooltip>
          </v-list-item-icon>
        </v-list-item>
      </div>
    </v-list-group>
  </v-navigation-drawer>
</template>

<script>
export default {
  name: 'ServerSidebar',
  props: {
    title: {
      type: String,
      default: 'Sidebar 标题'
    },
    value: {
      type: Boolean,
      default: false
    }
  },
  data: function () {
    return {
      serverSwitchCD: 2000,
      isCD: true,
      serverTypes: [],
      servers: [
        {
          'id': 1,
          'group': 'gs',
          'group_id': 'dev_liwenf',
          'ip': 'm6-qa-test001.ejoy.com',
          'name': 'liwenf',
          'port': 10100,
          'etcd_port': 12379,
          'sidecar': null,
          'robot_service_port': null
        }
      ],
      currentServer: {
        'gs': '',
        'ds': ''
      }
    }
  },
  methods: {
    print(content) {
      console.log(content)
    },
    formatter(server) {
      const tmp = Object.keys(server).map(attr => (`${attr}\t:\t${server[attr]}`))
      return tmp.join('\n')
    },
    close() {
      this.$emit('close')
    },
    onSelectedServer(server) {
      if (!this.isCD) {
        console.log('selectedServerNotCoolDown')
        this.$emit('selectedServerNotCoolDown', '后台处理中, 请稍等 2 秒再切换服务器')
        return
      }
      console.log('clicked server: ', server.address)
      if (this.currentServer[server.group] !== server.address) {
        this.currentServer[server.group] = server.address
        this.$emit('changeServer', { ...server })
      }
      this.isCD = false
      const that = this
      setTimeout(() => {
        that.isCD = true
      }, this.serverSwitchCD)
    },
    updateServerType() {
      this.servers.map(server => {
        if (!this.serverTypes.includes(server.group)) {
          this.serverTypes.push(server.group)
        }
      })
    },
    loadServer() {
      this.axios.get('/gsmanager/gs_agents/').then(
        res => {
          if (res.status === 200) {
            // 清除之前的 gs
            this.servers = this.servers.filter(server => server.group !== 'gs')
            // 添加现有的 gs
            this.servers = this.servers.concat(res.data.map(server => ({ ...server, group: 'gs', address: `${server.ip}:${server.port}` })))
            this.updateServerType()
          }
        }
      )
    }
  },
  mounted() {
    this.loadServer()
  }
}
</script>

<style scoped>

</style>

<template lang="pug">
  div
    div
      table.table.is-hoverable.has-text-centered
        tr
          th 项目
          th
            strong 值
          th 上次数据
          th 相对上次
          th 相对上次(%)
        tr.has-text-centered(v-for="col in cols")
          td
            strong {{ getValue(col, 'label') }}
          td
            strong {{ getValue(col, 'currentValue') }}
          td
            strong {{ getValue(col, 'lastValue') }}
          td {{ getValue(col, 'change') }}
          td.has-text-success(v-if="getValue(col, 'changeInPercent') > 10") +{{ getValue(col, 'changeInPercent') }}%
          td.has-text-danger(v-else-if="getValue(col, 'changeInPercent') < -10") {{ getValue(col, 'changeInPercent') }}%
          td(v-else-if="getValue(col, 'changeInPercent') > 0") +{{ getValue(col, 'changeInPercent') }}%
          td(v-else) {{ getValue(col, 'changeInPercent') }}
      br
</template>

<script>
export default {
  props: ['cols', 'labels', 'reportId'],
  data: function() {
    return {
      rows: {}
    }
  },
  created: function() {
    this.axios
      .get('/report/api/client_performance_report/recent_data', {
        params: {
          cols: this.cols,
          reportId: this.reportId
        }
      })
      .then(res => {
        let ans = {}

        for (let i = 0; i < this.cols.length; i++) {
          let cv = res.data[this.cols[i]]['current_value']
          let lv = res.data[this.cols[i]]['last_value']

          ans[this.cols[i]] = {
            label: this.labels[i],
            currentValue: cv,
            lastValue: lv,
            change: (cv - lv).toFixed(2),
            changeInPercent: (((cv - lv) * 100) / cv).toFixed(2)
          }
        }

        this.rows = ans
      })
  },
  methods: {
    getValue(col, name) {
      if (this.rows[col]) {
        return this.rows[col][name]
      }

      return null
    }
  }
}
</script>
<style scoped lang="sass" src="@/../node_modules/bulma/bulma.sass"></style>
<style scoped>
.content table th {
  text-align: center;
}

table td {
  text-align: center;
}
</style>

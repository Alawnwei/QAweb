<template>
  <v-card elevation="0">
    <v-dialog v-model="taskInfoDialog" width="60%">
      <v-card>
        <v-card-title class="headline">任务详情{{currentTask.taskName?('-' + currentTask.taskName):''}}</v-card-title>
        <v-card-text>
          <v-row>
            <v-col cols="6">
              <v-text-field
                v-model="currentTask.taskName"
                :rules="taskNameRule"
                class="taskInfo"
                counter="20"
                label="数据名称"
                hint="可简要描述测试的目的或对象"
              />
            </v-col>
            <v-col cols="6">
              <v-text-field
                v-model="currentTask.projectName"
                class="taskInfo"
                label="项目名称"
                disabled
              />
            </v-col>
          </v-row>
          <v-row>
            <v-col cols="6">
              <v-text-field
                v-model="currentTask.userName"
                class="taskInfo"
                label="测试用户"
                disabled
              />
            </v-col>
            <v-col cols="6">
              <v-text-field
                v-model="currentTask.userEmail"
                class="taskInfo"
                label="用户邮箱"
                disabled
              />
            </v-col>
          </v-row>
          <v-row>
            <v-col cols="6">
              <v-text-field
                :value="normalizeTime(currentTask.startTime)"
                class="taskInfo"
                label="开始时间"
                disabled
              />
            </v-col>
            <v-col cols="6">
              <v-text-field
                :value="normalizeTime(currentTask.endTime)"
                class="taskInfo"
                label="结束时间"
                disabled
              />
            </v-col>
          </v-row>
          <v-row>
            <v-col>
              <v-select
                :items="platformChoices"
                label="设备平台"
                v-model="currentTaskPlatform"
                @change="changePlatform($event)"
              />
            </v-col>
          </v-row>
        </v-card-text>
        <v-card-actions>
          <v-btn color="green darken-1" text @click="deleteTask()" :loading="editLoading">删除</v-btn>
          <v-spacer />
          <v-btn color="green darken-1" text @click="taskInfoDialog=false" :loading="editLoading">取消</v-btn>
          <v-btn color="green darken-1" text @click="saveTask()" :loading="editLoading">修改</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
    <v-card-title>
      性能历史
      <v-spacer/>
      <v-text-field
        v-model="search"
        append-icon="search"
        label="Search"
        single-line
        hide-details
        clearable
        dense
      />
    </v-card-title>
    <v-data-table
      :loading="dataLoading || editLoading"
      loading-text="Loading Data"
      :search="search"
      :headers="headers"
      :items="rawTaskList"
      disable-pagination
      @click:row="openRow($event)"
    >
      <template v-slot:item.action="{ item }">
        <v-icon
          @click="openEditDialog(item)"
        >
          edit
        </v-icon>
        <v-icon v-if="!inCompare(item)" @click="addCompareTask(item)">
          add
        </v-icon>
        <v-icon v-else @click="delCompareTask(item)">
          mdi-check
        </v-icon>
      </template>
      <template v-slot:item.startTime="{ item }">
        {{normalizeTime(item.startTime)}}
      </template>
      <template v-slot:item.endTime="{ item }">
        {{normalizeTime(item.endTime)}}
      </template>
      <template v-slot:item.periodTime="{ item }">
        {{getPeriod(item.startTime, item.endTime)}}
      </template>
      <template v-slot:item.platform="{ item }">
        {{getDeviceInfo(item.deviceInfo).platform}}
      </template>
    </v-data-table>
    <v-bottom-sheet v-model="taskListDialog" persistent inset hide-overlay >
      <v-list>
        <v-subheader>
          对比数据
          <v-spacer></v-spacer>
          <v-btn @click="compareTasks">对比</v-btn>
          <v-btn @click="taskListDialog=false" style="margin-left: 12px">关闭</v-btn>
        </v-subheader>
        <v-list-item v-for="(task, index) in compareTaskList" :key="index">
          <v-list-item-icon>
            <v-icon>mdi-star</v-icon>
          </v-list-item-icon>
          <v-list-item-content>
            <v-list-item-title v-text="task.taskName" @click="delCompareTask(task)"></v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </v-list>
    </v-bottom-sheet>
  </v-card>
</template>

<script>
import store from '@/store'
import { getPeriod, getDeviceInfo } from './Utils'

export default {
  name: 'TaskTable',
  data() {
    return {
      platformChoices: ['Windows', 'Android', 'iOS', 'Others'],
      currentTaskPlatform: '',
      boomerServer: 'http://' + process.env.VUE_APP_BOOMER_SERVER,
      projectId: 1, // M6 目前默认给一个 projectId
      search: store.getters.user ? store.getters.user.firstName : '',
      currentTask: {},
      compareTaskList: [],
      taskNameRule: [v => v.length <= 20 || '不可超过20个字符, 多余字符将被舍弃'],
      rawTaskList: [],
      taskListDialog: false,
      dataLoading: false,
      taskInfoDialog: false,
      editLoading: false,
      headers: [
        { text: '任务名', value: 'taskName', sortable: false, align: 'center' },
        { text: '创建人', value: 'userName', align: 'center' },
        { text: '设备系统', value: 'platform', align: 'center' },
        { text: '创建时间', value: 'startTime', align: 'center' },
        { text: '结束时间', value: 'endTime', align: 'center' },
        { text: '持续时间(s)', value: 'periodTime', align: 'center' },
        { text: '操作', value: 'action', align: 'center', sortable: false }
      ]
    }
  },
  methods: {
    print: function (item) {
      console.log(item)
    },
    openRow: function (item) {
      if (!this.taskInfoDialog && !this.taskListDialog) {
        this.getData([item.id])
      }
    },
    openEditDialog: function (item) {
      this.currentTask = item
      const deviceInfo = this.getDeviceInfo(item.deviceInfo)
      this.currentTaskPlatform = deviceInfo.platform
      this.taskInfoDialog = true
    },
    normalizeTime: function(time) {
      const date = new Date(time)
      return date.toLocaleString('chinese', { hour12: false })
    },
    getPeriod: function(startTime, endTime) {
      return getPeriod(startTime, endTime)
    },
    getDeviceInfo: function(deviceInfoStr) {
      return getDeviceInfo(deviceInfoStr)
    },
    changePlatform: function(platform) {
      const deviceInfo = this.getDeviceInfo(this.currentTask.deviceInfo)
      deviceInfo.platform = platform
      this.currentTask.deviceInfo = JSON.stringify(deviceInfo)
    },
    getTasks: function () {
      this.dataLoading = true
      this.axios({
        method: 'post',
        url: this.boomerServer + '/api/profile/get_profile_task_list',
        params: { projectId: this.projectId }
      }).then(res => {
        if (res.data.status === 0) {
          this.rawTaskList = res.data.data
          this.taskInfoDialog = false
          this.dataLoading = false
        }
      })
    },
    saveTask: function () {
      if (this.currentTask.taskName.length === 0) {
        return
      }
      if (this.currentTask.taskName.length > 20) {
        this.currentTask.taskName = this.currentTask.taskName.substring(0, 19)
      }
      const formData = new FormData()

      formData.append('taskInfo', JSON.stringify(this.currentTask))
      formData.append('clientId', '')
      this.editLoading = true

      this.axios({
        method: 'post',
        url: this.boomerServer + '/api/profile/save_task',
        data: formData
      }).then(res => {
        if (res.data.status === 0) {
          this.editLoading = false
          this.getTasks()
        }
      })
    },
    deleteTask: function () {
      this.editLoading = true
      this.axios({
        method: 'post',
        url: this.boomerServer + '/api/profile/delete_task',
        params: { taskId: this.currentTask.id }
      }).then(res => {
        if (res.data.status === 0) {
          this.editLoading = false
          this.getTasks()
        }
      })
    },
    inCompare: function (targetTask) {
      const matched = this.compareTaskList.filter(task => targetTask.id === task.id)
      return matched.length > 0
    },
    compareTasks: function () {
      this.taskListDialog = false
      const taskList = this.compareTaskList.map(task => task.id)
      this.getData(taskList)
    },
    addCompareTask: function (taskToAdd) {
      this.taskListDialog = true
      for (let i = 0; i < this.compareTaskList.length; i++) {
        if (taskToAdd.id === this.compareTaskList[i].id) {
          console.log('same task in line')
          return
        }
      }
      this.compareTaskList.push(taskToAdd)
    },
    delCompareTask: function (taskToDel) {
      this.compareTaskList = this.compareTaskList.filter(task => task.id !== taskToDel.id)
      if (this.compareTaskList.length === 0) {
        this.taskListDialog = false
      }
    },
    getData: function (taskIdList) {
      const formData = new FormData()
      formData.append('taskIdList', JSON.stringify(taskIdList))
      this.axios({
        method: 'post',
        url: this.boomerServer + '/api/profile/get_task_data',
        data: formData
      }).then(res => {
        if (res.data.status === 0) {
          this.$emit('updateData', res.data.data)
        }
      })
    }
  },
  watch: {
  },
  mounted() {
    this.getTasks()
  }
}
</script>

<style scoped>

</style>

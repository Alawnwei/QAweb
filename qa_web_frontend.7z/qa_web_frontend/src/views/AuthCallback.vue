<template lang='pug'>
  div 您已授权成功，请稍候。
</template>

<script>
import store from '../store'

export default {
  name: 'AuthCallback',
  created: function() {
    let url = location.href

    if (!url.includes('?')) {
      url = url.replace('#', '?') // 不知道为什么有时候是 hash 有时候是 queryString
    }

    let accessToken = new URL(url).searchParams.get('access_token')
    this.axios
      .get('/auth/token', {
        params: {
          access_token: accessToken
        }
      })
      .then(response => {
        store.commit('updateJwtToken', response.data.token)
        let nextUrl = store.getters.nextUrl
        window.location.href = nextUrl || '/'
      })
  }
}
</script>

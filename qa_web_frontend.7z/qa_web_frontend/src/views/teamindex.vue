<template lang='pug'>
  v-app
    div.title QA-WEB 导航
    div(my-3)
      div(class="d-flex flex-row mb-6 justify-center", flat,tile)
        div(
          v-for="col,key in orderdata",
          :key = "key",
          class="d-flex flex-column mx-1 my_column",
          outlined,
          tile
          )
          v-card.my-1(
            v-for="row in col",
            :key = "row.index",
            @click="onClickCard(row.url)"
            )
            v-img(v-if="row.img", height="250", :src="row.img")
            v-img(v-else,height="250", src="http://qc-procat.ejoy.com:8210/static/images/gallery.jpg")
            v-card-title {{row.name}}
            v-card-text {{row.description}}
            v-divider.mx-4
            v-card-title(v-if="row.user.length") 项目成员
            v-card-title(v-else)
            v-card-text(v-if="row.user.length")
              v-chip-group(column,active-class="deep-purple accent-4 white--text")
                v-chip(dark, v-for="username in row.user", :key="username",color="deep-purple") {{username}}
    div.ma-5
      v-divider
      div(class="d-flex justify-center mt-2")
        div
          v-img(src="https://cdn.aligames.com/fe/prod/public/basement/public/images/logo_161e209.png", width="200")
      v-flex(py-2, text-center, xs12)
        | ©2020 &nbsp;
        strong 灵犀互娱
</template>

<script>
export default {
  name: 'App',
  data() {
    return {
      line: parseInt((document.body.clientWidth || document.documentElement.clientWidth) / 400),
      teamdata: []
    }
  },
  computed: {
    orderdata() {
      return this.deal_data(this.teamdata)
    }
  },
  created: function() {
    this.get_navi_data()
  },
  watch: {
  },
  mounted: function() {
  },
  methods: {
    get_navi_data() {
      this.axios
        .get('/get_project_data', {
        })
        .then(res => {
          this.teamdata = res.data
        })
    },
    deal_data(teamdata) {
      let orderdata = []
      for (let i in teamdata) {
        let item = teamdata[i]
        let index = item.data.index
        let column = index % this.line
        let row = parseInt(index / this.line)

        if (Array.isArray(orderdata[column])) {
          orderdata[column][row] = item.data
        } else {
          orderdata[column] = []
          orderdata[column][row] = item.data
        }
      }
      return orderdata
    },
    onClickCard(url) {
      window.location.href = url
    }
  }
}
</script>

<style lang="sass">

  .title
    text-align: center
    margin: 40px
    font-size: 30px
  .collection
    margin-top: 20px
    background-color: #e3e3e3
  .vue-virtual-collection
    margin: auto
  .my_column
    width: 400px
  #app
    color: #2c3e50
    background-color: #e3e3e3

</style>

<template lang="pug">
  v-card
    v-card-title 资源数据列表
      v-spacer
      v-text-field(v-model="search", append-icon="search", label="模糊查找（快速过滤）", single-line, hide-details)
    v-data-table(:headers="headers", :items="tableDataItems", :search="search", @click:row="onClickRow", multi-sort)
      //- template(v-slot:expanded-item="{ item }") {{ item.attributes }}
</template>
<script>
import { DataTableHeaders, transformTableData } from './Utils'

export default {
  data: function() {
    return {
      search: '',
      tableDataItems: []
    }
  },
  props: ['tableData', 'showColumns'],
  watch: {
    tableData: function(newVal) {
      this.tableDataItems = transformTableData(newVal)
    }
  },
  components: {},
  computed: {
    headers: function() {
      return DataTableHeaders.concat(
        this.showColumns.map(o => {
          return {
            text: o,
            value: o
          }
        })
      )
    }
  },
  mounted: function() {},
  methods: {
    onClickRow: function(e) {
      console.log(e)
    }
  }
}
</script>

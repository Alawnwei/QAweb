<template lang="pug">
div
  v-row
      v-col(v-for="item, index in datasetList", :key="index" cols="6")
        line-chart(:dataset="item")
</template>

<script>
import LineChart from './LineChart'
import _ from 'lodash'

export default {
  data: function() {
    return {
      datasetList: []
    }
  },
  components: {
    'line-chart': LineChart
  },
  props: ['positionId'],
  watch: {
    positionId: function(newValue, _) {
      this.updateData(newValue)
    }
  },
  mounted: function() {
    this.updateData(this.positionId)
  },
  methods: {
    updateData: function(positionId) {
      this.axios.get('/perfcat/positions/' + positionId.toString() + '/get_position_report_history_data/').then(res => {
        let performanceData = _.omit(res.data, ['labels'])
        let labels = _.pick(res.data, ['labels'])

        this.datasetList = _.mapValues(performanceData, o => _.merge(labels, o))

        this.datasetList = res.data.slice(1).map(o => [res.data[0], o])
      })
    }
  }
}
</script>

import Vue from 'vue'
import Router from 'vue-router'
import store from './store'

Vue.use(Router)

let router = new Router({
  mode: 'history',
  base: process.env.BASE_URL,
  routes: [
    {
      path: '/',
      name: 'home',
      redirect: '/feedback' // 根目录先redirect 到 feedback
    },
    {
      path: '/about',
      name: 'about',
      // route level code-splitting
      // this generates a separate chunk (about.[hash].js) for this route
      // which is lazy-loaded when the route is visited.
      component: () => import(/* webpackChunkName: "about" */ './views/About.vue')
    },
    {
      path: '/auth',
      name: 'auth',
      component: () => import('./views/Auth.vue')
    },
    {
      path: '/auth_callback',
      name: 'auth_callback',
      component: () => import('./views/AuthCallback.vue')
    },
    {
      path: '/report',
      component: () => import('./views/report/Index.vue'),
      children: [
        {
          path: 'client-performance',
          component: () => import('./views/report/client_performance/Index.vue'),
          children: [
            {
              path: ':reportId/preview',
              component: () => import('./views/report/client_performance/Preview.vue'),
              props: true
            }
          ]
        },
        {
          path: 'server-performance',
          component: () => import('./views/report/server_performance/Report.vue')
        }
      ]
    },
    {
      path: '/rank',
      component: () => import('./views/rank/Index.vue'),
      children: [
        {
          path: '',
          redirect: '/rank/default'
        },
        {
          path: ':month',
          name: 'rank',
          component: () => import('./views/rank/Rank.vue'),
          props: true
        }
      ]
    },
    {
      path: '/feedback',
      component: () => import('./views/feedback/Index.vue'),
      children: [
        {
          path: '',
          component: () => import('./views/feedback/Dashboard.vue')
        }
        // {
        //   path: ':issue_id',
        //   component: () => import('./views/feedback/Dashboard.vue')
        // }
        // {
        //   path: ':month',
        //   name: 'feedback',
        //   component: () => import('./views/feedback/Rank.vue'),
        //   props: true
        // }
      ]
    },
    {
      path: '/skyee',
      component: () => import('./views/skyee/Index.vue'),
      children: [
        {
          path: 'current-thread',
          component: () => import('./views/skyee/CurrentThread.vue')
        },
        {
          path: 'thread/:serial',
          component: () => import('./views/skyee/Thread.vue'),
          props: true
        }
        // {
        //   path: 'thread-list',
        //   name: 'feedback',
        //   component: () => import('./views/feedback/Rank.vue'),
        //   props: true
        // }
      ]
    },
    {
      path: '/perfcat',
      component: () => import('./views/perfcat/Index.vue'),
      children: [
        {
          path: 'rule-report',
          component: () => import('./views/perfcat/RuleReport.vue')
        },
        {
          path: 'perf-report',
          component: () => import('./views/perfcat/PerfReport.vue'),
          props: true
        },
        {
          path: 'location-report',
          component: () => import('./views/perfcat/LocationReport/Index.vue'),
          props: true
        },
        {
          path: 'position-report/:positionId',
          component: () => import('./views/perfcat/PositionReport/Index.vue'),
          props: true
        },
        {
          path: 'resource-report',
          component: () => import('./views/perfcat/ResourceReport/Report.vue'),
          props: true
        },
        {
          path: 'resource-report-detail',
          component: () => import('./views/perfcat/ResourceReport/DataDetail.vue'),
          props: true
        },
        {
          path: 'dynamic-report',
          component: () => import('./views/perfcat/DynamicReport/LineChart.vue'),
          props: true
        },
        {
          path: 'profile-history',
          component: () => import('./views/perfcat/ProfileHistory/History.vue'),
          props: true
        },
        {
          path: 'heatmap',
          component: () => import('./views/perfcat/Heatmap/Index.vue'),
          props: true
        },
        {
          path: 'scatter-3d',
          component: () => import('./views/perfcat/Scatter3D/Index.vue'),
          props: true
        },
        {
          path: 'script-mgr',
          component: () => import('./views/perfcat/ScriptMgr/Index'),
          props: true
        }
      ]
    },
    {
      path: '/gm',
      component: () => import('./views/gm/Index.vue'),
      children: [
        {
          path: 'gm-directive',
          component: () => import('./views/gm/Directive/Index.vue')
        },
        {
          path: 'gm-mgr',
          component: () => import('./views/gm/Directive/Index.vue'),
          props: true
        }
      ]
    },
    {
      path: '/maplock',
      component: () => import('./views/maplock/Index.vue'),
      children: [
        {
          path: '',
          component: () => import('./views/maplock/Dashboard.vue')
        },
        {
          path: 'white',
          component: () => import('./views/maplock/White_list.vue')
        },
        {
          path: 'apply',
          component: () => import('./views/maplock/Apply_list.vue')
        }
        // {
        //   path: ':month',
        //   name: 'feedback',
        //   component: () => import('./views/feedback/Rank.vue'),
        //   props: true
        // }
      ]
    },
    {
      path: '/checklist',
      component: () => import('./views/checklist/Index.vue'),
      children: [
        {
          path: '',
          component: () => import('./views/checklist/step_list.vue')
        },
        {
          path: 'dutymanager',
          redirect: '/checklist/dutyManager/day' // 根目录先redirect 到 feedback
        },
        {
          path: 'dutymanager/:type',
          name: 'dutymanager',
          component: () => import('./views/checklist/duty.vue'),
          props: true
        },
        {
          path: 'dutylist',
          name: 'dutylist',
          component: () => import('./views/checklist/dutylist.vue'),
          props: true
        }
      ]
    },
    {
      path: '/cmdtable',
      component: () => import('./views/gmtab/Index.vue')
    },
    {
      path: '/excellock',
      component: () => import('./views/excellock/Index.vue'),
      children: [
        {
          path: '',
          component: () => import('./views/excellock/Dashboard.vue')
        },
        {
          path: 'white',
          component: () => import('./views/excellock/White_list.vue')
        },
        {
          path: 'apply',
          component: () => import('./views/excellock/Apply_list.vue')
        }
        // {
        //   path: ':month',
        //   name: 'feedback',
        //   component: () => import('./views/feedback/Rank.vue'),
        //   props: true
        // }
      ]
    },
    {
      path: '/serverRegressionTest',
      component: () => import('./views/serverRegressionTest/Index.vue'),
      children: [
        {
          path: 'Server_log_op',
          component: () => import('./views/serverRegressionTest/Server_log_operate.vue')
        },
        {
          path: 'Server_log_op/:file_name',
          name: 'server_log_op',
          component: () => import('./views/serverRegressionTest/Server_log_operate.vue')
        }
        // {
        //   path: ':month',
        //   name: 'feedback',
        //   component: () => import('./views/feedback/Rank.vue'),
        //   props: true
        // }
      ]
    },
    {
      path: '/server-test',
      component: () => import('./views/servertest/Index'),
      children: [
        {
          path: 'test',
          component: () => import('./views/servertest/Test')
        },
        {
          path: 'pressure-test',
          component: () => import('./views/servertest/PressureTest')
        }
      ]
    },
    {
      path: '/team',
      component: () => import('./views/teamindex')
    }
  ]
})

// ------------------ 认证，全局路由劫持 -------------------

const RESPONSE_TYPE = 'token'
const AUTH_URL = 'https://one.ejoy.com/oauth'
const PRODUCT_CODE_M6 = 'P10463' // TODO 填写one 认证项目组
const SCOPE = 'profile'
const STATE = 'login'
const NONCE = Math.floor(Math.random() * 1000000)
const REDIRECT_URI = window.location.protocol + '//' + window.location.hostname + ':' + window.location.port + router.resolve('auth_callback').resolved.fullPath

router.beforeEach((to, from, next) => {
  if (to.path === '/auth_callback' || to.path === '/team') {
    next() // 如果是请求回调或QAweb导航，直接放行
  } else if (store.getters.jwtToken) {
    next() // 如果已有jwt，放行
    // TODO 此处可加上相关权限配置
  } else {
    // 暂时的做法 后续会迁移到质效平台
    let PRODUCT_CODE = PRODUCT_CODE_M6
    store.commit('updateNextUrl', to.fullPath)
    let params = {
      response_type: RESPONSE_TYPE,
      product_code: PRODUCT_CODE,
      scope: SCOPE,
      state: STATE,
      nonce: NONCE,
      redirect_uri: REDIRECT_URI
    }
    let toUrl =
      AUTH_URL +
      '?' +
      Object.entries(params)
        .map(e => e.join('='))
        .join('&')
    window.location.href = toUrl
  }
})
export default router

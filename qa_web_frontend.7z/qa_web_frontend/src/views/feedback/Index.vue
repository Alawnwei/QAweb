<template lang="pug">
v-app
  router-view.pb-4
  v-footer.py-0(height='auto', dark, fixed)
    v-layout(justify-center, row, wrap)
      v-flex(py-2, text-center, white--text, xs12)
        | 反馈平台 ©2019 &nbsp;
        strong M6 QA
</template>

<script>
import store from '@/store'

export default {
  data: () => ({}),
  computed: {
    user: () => store.getters.user
  },
  props: {
    source: String
  },
  methods: {
    clickNavigation: function(item) {
      this.$router.push(item.link)
    }
  },
  components: {
    'feedback-iterator': () => import('@/components/FeedbackIterator.vue')
  }
}
</script>

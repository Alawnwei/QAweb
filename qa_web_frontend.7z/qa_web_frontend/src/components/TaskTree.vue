<template>
  <div>
    <v-dialog v-model="taskInfoDialog" width="60%">
      <v-card>
        <v-card-title class="headline">任务详情{{currentTask.taskName?('-' + currentTask.taskName):''}}</v-card-title>
        <v-card-text>
          <v-row>
            <v-col cols="6">
              <v-text-field
                v-model="currentTask.taskName"
                :rules="taskNameRule"
                class="taskInfo"
                counter="20"
                label="数据名称"
                hint="可简要描述测试的目的或对象"
              />
            </v-col>
            <v-col cols="6">
              <v-text-field
                v-model="currentTask.projectName"
                class="taskInfo"
                label="项目名称"
                disabled
              />
            </v-col>
          </v-row>
          <v-row>
            <v-col cols="6">
              <v-text-field
                v-model="currentTask.userName"
                class="taskInfo"
                label="测试用户"
                disabled
              />
            </v-col>
            <v-col cols="6">
              <v-text-field
                v-model="currentTask.userEmail"
                class="taskInfo"
                label="用户邮箱"
                disabled
              />
            </v-col>
          </v-row>
          <v-row>
            <v-col cols="6">
              <v-text-field
                :value="normalizeTime(currentTask.startTime)"
                class="taskInfo"
                label="开始时间"
                disabled
              />
            </v-col>
            <v-col cols="6">
              <v-text-field
                :value="normalizeTime(currentTask.endTime)"
                class="taskInfo"
                label="结束时间"
                disabled
              />
            </v-col>
          </v-row>
        </v-card-text>
        <v-card-actions>
          <v-btn color="green darken-1" text @click="deleteTask()" :loading="editLoading">删除</v-btn>
          <v-spacer></v-spacer>
          <v-btn color="green darken-1" text @click="taskInfoDialog=false" :loading="editLoading">取消</v-btn>
          <v-btn color="green darken-1" text @click="saveTask()" :loading="editLoading">修改</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
    <v-row>
      <v-col cols="6">
        <v-card>
          <v-card-title>
            数据列表
          </v-card-title>
          <v-treeview
            selectable
            dense
            hoverable
            activatable
            open-on-click
            :items="taskList"
            @update:active="handleSelected($event)"
            item-text="displayName"
            v-model="selectedTask"
          >
            <template v-slot:append="{ item }">
              <div v-show="item.startTime">{{item.userName + ' @ ' + normalizeTime(item.startTime)}}</div>
              <v-btn v-show="item.startTime" icon @click="openTask(item)"><v-icon>mdi-pencil</v-icon></v-btn>
            </template>
          </v-treeview>
        </v-card>
      </v-col>
      <v-col cols="6">
        <slot name="timeline"/>
      </v-col>
    </v-row>
  </div>

</template>

<script>
export default {
  data: function() {
    return {
      boomerServer: 'http://' + process.env.VUE_APP_BOOMER_SERVER,
      rawTaskList: [],
      selectedTask: [],
      currentTask: {},
      taskNameRule: [v => v.length <= 20 || '不可超过20个字符, 多余字符将被舍弃'],
      projectId: 1, // M6 目前默认给一个 projectId
      taskInfoDialog: false,
      editLoading: false
    }
  },
  name: 'TaskTree',
  computed: {
    taskList: function () {
      let users = {}
      const result = []
      this.rawTaskList.map(task => {
        const displayName = task.taskName
        if (task.userName in users) {
          users[task.userName].push({ ...task, displayName })
        } else {
          users[task.userName] = [{ ...task, displayName }]
        }
      })
      Object.keys(users).map(key => {
        result.push({ displayName: key, children: users[key] })
      })
      return result
    }
  },
  watch: {
    selectedTask: function (newVal, oldVal) {
      this.getData()
    }
  },
  methods: {
    print: function(msg) {
      console.log(msg)
    },
    normalizeTime: function(time) {
      const date = new Date(time)
      return date.toLocaleString()
    },
    openTask: function(task) {
      this.currentTask = task
      this.taskInfoDialog = true
    },
    getTasks: function () {
      this.axios({
        method: 'post',
        url: this.boomerServer + '/api/profile/get_profile_task_list',
        params: { projectId: this.projectId }
      }).then(res => {
        if (res.data.status === 0) {
          this.rawTaskList = res.data.data
          this.taskInfoDialog = false
        }
      })
    },
    handleSelected: function (selected) {
      if (!selected || selected.length === 0) {
        return
      }
      const selectedId = selected[0]
      if (this.selectedTask.includes(selectedId)) {
        this.selectedTask = this.selectedTask.filter(item => item !== selectedId)
      } else {
        this.selectedTask.push(selectedId)
      }
    },
    getData: function () {
      const formData = new FormData()
      formData.append('taskIdList', JSON.stringify(this.selectedTask))

      this.axios({
        method: 'post',
        url: this.boomerServer + '/api/profile/get_task_data',
        data: formData
      }).then(res => {
        if (res.data.status === 0) {
          this.$emit('updateData', res.data.data)
        }
      })
    },
    deleteTask: function () {
      this.editLoading = true
      this.axios({
        method: 'post',
        url: this.boomerServer + '/api/profile/delete_task',
        params: { taskId: this.currentTask.id }
      }).then(res => {
        if (res.data.status === 0) {
          this.editLoading = false
          this.getTasks()
        }
      })
    },
    saveTask: function () {
      if (this.currentTask.taskName.length === 0) {
        return
      }
      if (this.currentTask.taskName.length > 20) {
        this.currentTask.taskName = this.currentTask.taskName.substring(0, 19)
      }
      const formData = new FormData()

      formData.append('taskInfo', JSON.stringify(this.currentTask))
      formData.append('clientId', '')
      this.editLoading = true

      this.axios({
        method: 'post',
        url: this.boomerServer + '/api/profile/save_task',
        data: formData
      }).then(res => {
        if (res.data.status === 0) {
          this.editLoading = false
          this.getTasks()
        }
      })
    }
  },
  mounted() {
    this.getTasks()
  }
}
</script>

<style scoped>
  .taskInfo {
    margin-left: 24px;
    margin-right: 24px;
  }
</style>

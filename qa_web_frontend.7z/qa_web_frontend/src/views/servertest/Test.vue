<template lang="pug">
  div
</template>

<script>
export default {
  mounted: function() {
    var ws = new WebSocket('ws://localhost:8000/ws/servertest/gsrobotrpc')

    ws.onopen = function(evt) {
      console.log('Connection open ...')
      ws.send('ping')
    }

    ws.onmessage = function(evt) {
      console.log('Received Message: ' + evt.data)
    }

    ws.onclose = function(evt) {
      console.log('Connection closed.')
    }
  }
}
</script>

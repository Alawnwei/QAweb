import Vue from 'vue'
import Vuex from 'vuex'
import createPersistedState from 'vuex-persistedstate'
import { Base64 } from 'js-base64'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    auth: {
      id: null,
      token: null,
      username: null,
      email: null,
      firstname: null
    },
    nextUrl: null,
    createIssueDialog: {
      display: false,
      content: '',
      title: ''
    }
  },
  mutations: {
    updateJwtToken: (state, token) => {
      state.auth.token = token
      let payload = Base64.decode(token.split('.')[1])
      let data = JSON.parse(payload)
      state.auth.id = data.id
      state.auth.username = data.username
      state.auth.email = data.email
      state.auth.firstName = data.first_name
    },
    updateLocalJwtToken: state => {
      state.auth.token = 'test_token'
      state.auth.username = 'admin'
      state.auth.email = 'admin@admin.com'
      state.auth.firstName = 'admin'
    },
    updateNextUrl: (state, nextUrl) => {
      state.nextUrl = nextUrl
    },
    updateFirstName: (state, name) => {
      state.auth.firstName = name
    }
  },
  actions: {},
  getters: {
    jwtToken: state => state.auth.token,
    nextUrl: state => state.nextUrl,
    user: state => ({
      id: state.auth.id,
      username: state.auth.username,
      firstName: state.auth.firstName,
      email: state.auth.email
    })
  },
  plugins: [
    createPersistedState({
      storage: window.sessionStorage
    })
  ] // 储存状态到 localStorage 确保页面刷新后不丢失
})

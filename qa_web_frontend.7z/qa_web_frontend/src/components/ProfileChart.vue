<template>
  <v-chart :options="options" :init-options="initOptions" style="width:100%; margin-left: 24px; margin-right: 24px;"/>
</template>

<script>
import Echarts from 'vue-echarts/components/ECharts.vue'
import 'echarts/lib/chart/line'
import 'echarts/lib/component/title'
import 'echarts/lib/component/legend'
import 'echarts/lib/component/tooltip'
import 'echarts/lib/component/dataZoom'
import 'echarts/lib/component/markArea'

export default {
  components: {
    'v-chart': Echarts
  },
  props: ['options'],
  name: 'ProfileChart',
  data: () => ({
    initOptions: {
    }
  }),
  watch: {
  },
  computed: {},
  methods: {
  },
  mounted() {
  }
}
</script>

<style scoped>

</style>

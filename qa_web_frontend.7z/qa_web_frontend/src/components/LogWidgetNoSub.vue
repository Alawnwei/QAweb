<template>
  <div>
    <v-toolbar dense dark height="48px">
      <v-toolbar-title v-text="'Logger: ' + loggerName"></v-toolbar-title>
      <v-spacer></v-spacer>
      <v-toolbar-items>
        <v-switch v-model="scrollToEnd" label="跟随 log 滚动" style="margin-top: 12px"/>
        <v-btn text @click="empty">清空</v-btn>
      </v-toolbar-items>
    </v-toolbar>
    <MonacoEditor
      ref="editor"
      v-model="logContent"
      theme="vs-dark"
      class="editor"
      language="lua"
      :options="editorOptions"
    />
  </div>

</template>

<script>
import MonacoEditor from 'vue-monaco'

export default {
  name: 'LogWidgetNoSub',
  components: { MonacoEditor },
  props: ['loggerName'],
  data: function () {
    return {
      editor: null,
      logContent: '',
      filter: [],
      search: '',
      scrollToEnd: false,
      editorOptions: {
        readOnly: true,
        automaticLayout: true
      }
    }
  },

  methods: {
    clear: function () {
      //  类似 console 的 clear 功能, 并不是直接清空, 而是直接给你一段空行
      this.logContent += new Array(45).join('\n')
      this.editor.revealLine(this.lineCount, 0)
    },
    reload: function () {
      this.editor.layout()
      console.log('reload!')
    },
    empty: function () {
      //  清空 log 内容
      this.logContent = ''
    }
  },
  computed: {
    lineCount: {
      get: function () {
        if (this.logContent) {
          return this.logContent.split('\n').length - 1
        }
        return 0
      }
    }
  },
  watch: {
    scrollToEnd: function (newVal, _) {
      if (newVal) {
        this.editor.revealLine(this.lineCount, 0)
      }
    }
  },
  mounted: function () {
    this.editor = this.$refs.editor.getEditor()
  }
}
</script>

<style scoped>
  .editor {
    height: 720px;
  }
</style>

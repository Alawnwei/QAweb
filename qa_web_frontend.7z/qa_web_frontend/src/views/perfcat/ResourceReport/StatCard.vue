<template lang="pug">
  v-card.mx-auto(max-width="344", outlined)
    v-list-item(three-line)
      v-list-item-content
        .overline.mb-4 {{ title }}
        v-list-item-title.headline.mb-1 {{ value }}
</template>

<script>
export default {
  props: ['title', 'value']
}
</script>

<template lang="pug">
div
  v-container(fluid)
    v-data-iterator(:items="items"
                    :server-items-length="pagination.totalItems"
                    :items-per-page.sync="pagination.itemsPerPage"
                    :sort-by="pagination.sortBy"
                    :sort-desc="pagination.descending"
                    :page.sync="pagination.page"
                    @update:options="onUpdatePagination"
                    :footer-props="{ itemsPerPageOptions }"
                    )
      template(#default="props")
        v-row
          v-col(v-for="item in props.items", :key="item.id", cols="1", sm="4", md="3", lg="2")
            feedback-card(:issue_id="item.id",
                          :title="item.title",
                          :content="item.content",
                          :status="item.status",
                          :changed="item.changed",
                          :assignedToUserList="assignedToUserList"
                          :selected="selectedCard === item.id"
                          @update-list="updateData"
                          @show-create-issue-dialog="onShowCreateIssueDialog"
                          @on-click-zoom-in="onClickZoomIn"
                          @on-select-card="onSelectCard"
                          )
</template>

<script>
import store from '@/store'
import _ from 'lodash'

export default {
  props: ['title', 'dataFilter', 'assignedToUserList'],
  data: () => ({
    itemsPerPageOptions: [12],
    totalItems: 100,
    pagination: {
      rowsPerPage: 12,
      itemsPerPage: 12,
      descending: false,
      page: 1,
      sortBy: 'created_at',
      totalItems: 12
    },
    items: [],
    selectedCard: null
  }),
  components: {
    'feedback-card': () => import('./FeedbackCard.vue')
  },
  created: function() {
    this.updateData = _.debounce(this.update, 200)

    function retrieveImageFromClipboardAsBlob(pasteEvent, callback) {
      // 定义读取clipboard image的函数
      // 最终回调获取的参数是一个文件类型
      if (pasteEvent.clipboardData === false) {
        if (typeof callback === 'function') {
          callback(undefined)
        }
      }

      var items = pasteEvent.clipboardData.items

      if (items === undefined) {
        if (typeof callback === 'function') {
          callback(undefined)
        }
      }

      for (var i = 0; i < items.length; i++) {
        // Skip content if not image
        if (items[i].type.indexOf('image') === -1) continue
        // Retrieve image on clipboard as blob
        var blob = items[i].getAsFile()

        if (typeof callback === 'function') {
          callback(blob)
        }
      }
    }
    let iteratorObj = this
    window.addEventListener(
      'paste',
      function(e) {
        if (iteratorObj.selectedCard === null) {
          return
        }
        retrieveImageFromClipboardAsBlob(e, function(imageBlob) {
          // 传入一个回调，在读取完clipboard的image后发生
          let images = [imageBlob]
          let headers = {
            'Content-Type': 'multipart/form-data;charset=UTF-8'
          }
          let formData = new FormData()
          formData.append('issue_id', iteratorObj.selectedCard)
          images.forEach(element => {
            formData.append('images[]', element)
          })
          iteratorObj.axios
            .post('/feedback/api/append_images_to_issue/', formData, {
              headers: headers
            })
            .then(res => {
              iteratorObj.notifyIssueToUpdate(iteratorObj.selectedCard)
            })
        })
      },
      false
    )
  },
  watch: {
    dataFilter: {
      handler: function(val, _) {
        this.updateData()
      },
      deep: true
    }
  },
  methods: {
    update: function() {
      let params = {
        type: this.type,
        per_page: this.pagination.itemsPerPage,
        page: this.pagination.page,
        filter: this.dataFilter,
        username: store.getters.user.username
      }
      this.axios
        .get('/feedback/api/get_issue_list/', {
          params: params
        })
        .then(res => {
          this.pagination.totalItems = res.data.data.total
          var issueList = res.data.data.issue_list

          for (var i = 0; i < issueList.length; i++) {
            issueList[i]['changed'] = true
          }

          this.selectedCard = null
          this.items = issueList
        })
    },
    notifyIssueToUpdate: function(issueId) {
      // 提供一种机制通知子组件去update自己的详细数据
      for (var i = 0; i < this.items.length; i++) {
        if (this.items[i]['id'] === issueId) {
          this.items[i]['changed'] = !this.items[i]['changed']
        }
      }
    },
    onUpdatePagination: function(pagination) {
      this.updateData()
    },
    onShowCreateIssueDialog: function(payload) {
      this.$emit('show-create-issue-dialog', payload)
    },
    onClickZoomIn: function(payload) {
      this.$emit('on-click-zoom-in', payload)
    },
    onSelectCard: function(payload) {
      this.selectedCard = payload.issueId
    }
  }
}
</script>
<style lang="sass">
.v-btn--active
  background-color: green
</style>

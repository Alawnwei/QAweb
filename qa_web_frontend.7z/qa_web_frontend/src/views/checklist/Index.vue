<template lang="pug">
v-app
  div
    v-toolbar(fixed, dark)
      v-toolbar-title M6 CheckList
      v-spacer
      v-toolbar-items.hidden-sm-and-down
        v-btn(color="cyan", @click="goAdmin('/admin/checklist/')") Checklist管理
        v-btn(color="green", @click="goPage('checklist/')")  模块Checklist
        v-btn(color="green", @click="goPage('checklist/')") 维护Checklist
        v-btn(color="blue", @click="goPage('checklist/dutylist')") 值班表
        v-btn(text) 欢迎你，{{ user.firstName }}
  router-view.pb-4
  v-footer.py-0(height='auto', dark, fixed)
    v-layout(justify-center, row, wrap)
      v-flex(py-2, text-center, white--text, xs12)
        | 反馈平台 ©2019 &nbsp;
        strong M6 QA
</template>

<script>
import store from '@/store'

export default {
  data: () => ({}),
  computed: {
    user: () => store.getters.user
  },
  props: {
    source: String
  },
  methods: {
    clickNavigation: function(item) {
      this.$router.push(item.link)
    },
    goPage: function(page) {
      window.location.href = '/' + page
    },
    goAdmin: function(page) {
      window.location.href = this.axios.defaults.baseURL + page
    }
  },
  components: {
  }
}
</script>

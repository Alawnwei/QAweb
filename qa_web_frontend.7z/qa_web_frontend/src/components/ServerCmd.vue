<template>
  <div style="width: 100%">
    <v-toolbar dense class="elevation-0">
      <v-autocomplete
        ref="autocomplete"
        hide-details
        prepend-icon="mdi-console-line"
        single-line
        solo-inverted
        clearable
        hide-no-data
        placeholder="输入指令, Enter 运行"
        v-model="cmdContent"
        @keydown.enter="sendCmd"
        :items="cmdList"
      ></v-autocomplete>
      <v-tooltip bottom>
        <template v-slot:activator="{ on, attrs }">
          <v-btn :disabled="cmdHistory.length === 0" icon v-bind="attrs" v-on="on" @click="historyDialog=true">
            <v-icon>edit</v-icon>
          </v-btn>
        </template>
        <span>编辑历史</span>
      </v-tooltip>
      <v-tooltip bottom>
        <template v-slot:activator="{ on, attrs }">
          <v-btn  icon v-bind="attrs" v-on="on" @click="sendCmd">
            <v-icon>send</v-icon>
          </v-btn>
        </template>
        <span>发送指令</span>
      </v-tooltip>
    </v-toolbar>
    <v-dialog v-model="historyDialog" width="40%" scrollable>
      <v-card>
        <v-card-title>
          <div class="font-weight-bold">指令历史</div>
          <v-spacer />
          <div class="font-weight-light">最后执行时间</div>
        </v-card-title>
        <v-card-text>
          <v-list
            shaped
          >
            <v-list-item-group>
              <v-list-item
                v-for="item in cmdHistory"
                :key="item.cmd"
              >
                <v-list-item-content v-text="item.cmd" />
                <v-list-item-action>
                  <v-list-item-action-text v-text="item.time" />
                  <v-btn icon @click="clearCmd(item.cmd)">
                    <v-icon>clear</v-icon>
                  </v-btn>
                </v-list-item-action>
              </v-list-item>
            </v-list-item-group>
          </v-list>
        </v-card-text>
        <v-card-actions>
          <div class="text--secondary font-weight-light px-4">*点击可直接运行</div>
          <v-spacer />
          <v-btn text class="px-4" color="blue darken-1" @click="historyDialog=false">Close</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </div>

</template>

<script>
export default {
  // TODO 添加执行状态提示
  name: 'ServerCmd',
  data: function () {
    return {
      cmdContent: '',
      autocomplete: undefined,
      cmdHistory: [],
      historyDialog: false
    }
  },
  methods: {
    print: function (e) {
      console.log(e)
    },
    clearCmd: function (cmd) {
      this.cmdHistory = this.cmdHistory.filter(ch => (ch.cmd !== cmd))
    },
    loadCmdHistory: function () {
      const cmdHistory = window.localStorage.getItem('cmdHistory')
      if (cmdHistory) {
        this.cmdHistory = JSON.parse(cmdHistory)
      }
    },
    refreshCmdHistory: function (cmd) {
      this.cmdHistory = this.cmdHistory.filter(hCmd => hCmd.cmd !== cmd)
      this.cmdHistory.push({ cmd, time: (new Date()).toLocaleString() })
      window.localStorage.setItem('cmdHistory', JSON.stringify(this.cmdHistory))
    },
    sendCmd: function () {
    // // TODO 发消息回调相关处理
      console.log('sendCmd')
      if (!this.cmdContent || this.cmdContent.length === 0) {
        if (!this.autocomplete.lazySearch && this.autocomplete.lazySearch.length !== 0) {
          console.log('send:' + this.autocomplete.lazySearch)
          this.$emit('executeCmd', { name: 'tempCmd', content: this.autocomplete.lazySearch })
          this.refreshCmdHistory(this.autocomplete.lazySearch)
        }
      } else {
        console.log('send:' + this.cmdContent)
        this.$emit('executeCmd', { name: 'tempCmd', content: this.cmdContent })
        this.refreshCmdHistory(this.cmdContent)
      }
      this.autocomplete.lazySearch = ''
      this.cmdContent = ''
    }
  },
  computed: {
    cmdList: function () {
      return this.cmdHistory.map(ch => (ch.cmd))
    }
  },
  mounted() {
    this.loadCmdHistory()
    this.autocomplete = this.$refs.autocomplete
  }
}
</script>

<style scoped>

</style>

<template lang="pug">
v-app
  div(data-app="true")
    v-app-bar(fixed, dark, app, clipped-left)
      v-toolbar-title M1 GM
      v-spacer
      v-toolbar-items.hidden-sm-and-down
        v-btn(text) 欢迎你，{{ user.firstName }}
    v-content
      v-container(fluid='')
        v-row
          v-col(cols="12", sm="2")
            navigation
          v-col(cols="12", sm="10")
            router-view

</template>

<script>
import store from '@/store'
import Navigation from './Navigation'

export default {
  data: () => ({}),
  computed: {
    user: () => store.getters.user
  },
  props: {},
  methods: {},
  components: {
    navigation: Navigation
  }
}
</script>

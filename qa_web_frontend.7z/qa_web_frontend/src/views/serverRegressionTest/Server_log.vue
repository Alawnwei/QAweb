<template lang="pug">
v-navigation-drawer(permanent=true)
    v-list
      router-link(:to="total[0].link+total[0].title")
        v-list-item
          v-list-item-content(style="color:blue") {{total[0].title}}
      v-divider
      router-link(v-for="(item,index) in caseData['CASE_LIST']",:to="items[0].link + item", :key="index")
          v-list-item
            v-list-item-content(:style="{color:color_show(item)}") {{ item }}
            v-icon(small,right,:color="color_show(item)") {{state_show(item)}}
</template>

<script>
export default {
  props: [''],
  data: function() {
    return {
      items: [
        { link: '/serverRegressionTest/Server_log_op/' }
      ],
      total: [
        { title: '服务器Log', link: '/serverRegressionTest/Server_log_op/' }
      ],
      caseData: {},
      file_name: '',
      file_point: ''
    }
  },
  created: function() {

  },
  mounted: function() {

  },
  watch: {

  },
  methods: {
    state_show: function(item) {
      if (this.caseData['DONE_CASE_LIST'].indexOf(item) !== -1) {
        return 'mdi-checkbox-marked-circle'
      } else if (this.caseData['FAIL_CASE_LIST'].indexOf(item) !== -1) {
        return 'mdi-cancel'
      } else if (this.caseData['RUNNINT_CASE'] != null) {
        if (this.caseData['RUNNINT_CASE'].indexOf(item) !== -1) {
          return 'mdi-arrow-left'
        }
      } else {
        return 'mdi-checkbox-marked-circle'
      }
    },
    color_show: function(item) {
      if (this.caseData['DONE_CASE_LIST'].indexOf(item) !== -1) {
        return 'green'
      } else if (this.caseData['FAIL_CASE_LIST'].indexOf(item) !== -1) {
        return 'red'
      } else if (this.caseData['RUNNINT_CASE'] != null) {
        console.log('有脚本在运行中')
        if (this.caseData['RUNNINT_CASE'].indexOf(item) !== -1) {
          return 'gray'
        }
      } else {
        return 'blue'
      }
    },
    set_Case_Data: function(data) {
      this.caseData = data
    },
    senddata: function() {

    }
  }
}
</script>

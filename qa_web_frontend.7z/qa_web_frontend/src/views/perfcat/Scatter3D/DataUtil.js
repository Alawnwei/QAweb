import _ from 'lodash'

let Statistics = [
  {
    text: '最差值',
    value: -1,
    method: _.max
  },
  {
    text: '平均值',
    value: -2,
    method: _.mean
  }
  // {
  //   text: '最小值',
  //   value: -3,
  //   method: _.min
  // }
]

let Fields = [
  {
    text: 'FPS',
    value: 'fps',
    range: [0, 120]
  },
  {
    text: 'DP',
    value: 'dp',
    range: [0, 300]
  },
  {
    text: '三角面数',
    value: 'f_count',
    range: [0, 100000]
  },
  {
    text: '顶点数',
    value: 'v_count',
    range: [0, 100000]
  },
  {
    text: '内存',
    value: 'mem',
    range: [3000, 4000]
  }
]

let GetFieldSelectionItems = function() {
  return Fields
}

let GetTableDataSet = function(data) {
  let tableResult = []
  let mData = {}
  for (var posKey in data.data) {
    var posData = data.data[posKey]
    for (var dirKey in posData) {
      var dirData = posData[dirKey]
      if (mData.fps === undefined) {
        mData = dirData
      } else {
        if (dirData.fps < mData.fps) {
          mData.fps = dirData.fps
        }
        if (dirData.mem > mData.mem) {
          mData.mem = dirData.mem
        }
        if (dirData.v_count > mData.v_count) {
          mData.fsp = dirData.fps
        }
        if (dirData.dp > mData.dp) {
          mData.dp = dirData.dp
        }
      }
    }
    let pos = data.positions[posKey]
    pos[3] = posKey
    mData.pos = '(' + pos[0] + ',' + pos[1] + ',' + pos[2] + ')'
    mData.posData = pos
    tableResult.push(mData)
  }

  return tableResult
}

let GetXSelectionItems = function(originalDirections) {
  // v[3] 是方向的tag值，目前还没用到
  let original = _.map(originalDirections, (v, index) => {
    return {
      text: '(' + v[0] + ',' + v[1] + ',' + v[2] + ')', // v[3],
      value: index
    }
  })

  let statistics = _.map(Statistics, o => {
    return {
      text: o.text,
      value: o.value
    }
  })

  return _.concat(statistics, original)
}

let TransformScatterData = function(
  data,
  positionIndex,
  directionIndex,
  colorX,
  colorY,
  sizeX,
  sizeY
) {
  // 把api下发的数据转换成 scatter 图表展示的格式
  // colorX: 颜色指示器数据维度（维度指方向这一层，包括东西南北，或者平均中位数等等）
  // colorY: 颜色指示器数据指标
  // sizeX: 大小指示器数据维度
  // sizeY: 大小指示器数据指标

  var res = [] // 先初始化一个数组用来存放结果

  _.forEach(data, (positionData, positionId) => {
    var positionRes = []

    positionIndex[positionId].slice(0, 3).forEach(cood => {
      positionRes.push(cood)
    })

    positionRes.push(positionId)

    positionRes.push(getPositionDataByIndex(positionData, colorX, colorY)) //  push 颜色指示器数据
    positionRes.push(getPositionDataByIndex(positionData, sizeX, sizeY)) // push 大小指示器数据

    res.push(positionRes)
  })

  return res
}

let getPositionDataByIndex = function(positionData, xIndex, yName) {
  if (xIndex >= 0) {
    return positionData[xIndex][yName]
  } else {
    let tempArray = _.map(positionData, yName) // 用于统计的数组
    var statisticsMethod = _.find(Statistics, o => o.value === xIndex).method
    if (yName === 'fps' && statisticsMethod === _.max) {
      return _.min(tempArray)
    }
    return statisticsMethod(tempArray)
  }
}

export {
  Statistics,
  GetFieldSelectionItems,
  GetXSelectionItems,
  TransformScatterData,
  GetTableDataSet
}

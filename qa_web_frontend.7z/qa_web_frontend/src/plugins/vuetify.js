import Vue from 'vue'
import Vuetify from 'vuetify'
import 'vuetify/dist/vuetify.min.css'
import zhHans from 'vuetify/es5/locale/zh-Hans'

Vue.use(Vuetify)

const opts = {
  // customProperties: true,
  icons: {
    iconfont: 'mdi'
  },
  lang: {
    locales: { 'zh-Hans': zhHans },
    current: 'zh-Hans'
  },
  theme: {
    dark: false
  }
}

export default new Vuetify(opts)

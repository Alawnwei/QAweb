<template>
  <div>
    <v-chart :options="options" @click="onClick" theme="dark" style="width:100%;height:800px;"></v-chart>
  </div>
</template>

<script>
import Echarts from 'vue-echarts/components/ECharts.vue'
import 'echarts/theme/dark'
import 'echarts/lib/chart/scatter'
import 'echarts/lib/component/title'
import 'echarts/lib/component/legend'
import 'echarts-gl'

export default {
  data: function() {
    return {
      options: {},
      fieldNames: []
    }
  },
  props: ['dataSet', 'dimensions', 'sizeDataRange', 'colorDataRange'],
  watch: {
    dataSet: function() {
      this.updateOptions()
    },
    dimensions: function() {
      this.updateOptions()
    },
    sizeDataRange: function() {
      this.updateOptions()
    },
    colorDataRange: function() {
      this.updateOptions()
    }
  },
  components: {
    'v-chart': Echarts
  },
  methods: {
    onClick: function(event) {
      this.$emit('onClickPos', event.data)
    },
    updateOptions: function() {
      var options = {
        tooltip: {},
        visualMap: [
          {
            top: 10,
            calculable: true,
            dimension: 4,
            min: this.colorDataRange[0],
            max: this.colorDataRange[1],
            inRange: {
              color: ['#1710c0', '#0b9df0', '#00fea8', '#00ff0d', '#f5f811', '#f09a09', '#fe0300'].reverse()
            },
            realtime: true, // 是否实时刷新
            textStyle: {
              color: '#fff'
            }
          },
          {
            bottom: 10,
            calculable: true,
            dimension: 5,
            min: this.sizeDataRange[0],
            max: this.sizeDataRange[1],
            inRange: {
              symbolSize: [10, 20]
            },
            textStyle: {
              color: '#fff'
            }
          }
        ],
        xAxis3D: {
          type: 'value',
          name: 'X 坐标'
        },
        yAxis3D: {
          type: 'value',
          name: 'Y 坐标'
        },
        zAxis3D: {
          type: 'value',
          name: 'Z 坐标',
          max: '10000',
          min: '-5000'
        },
        grid3D: {
          axisLine: {
            lineStyle: {
              color: '#fff'
            }
          },
          axisPointer: {
            lineStyle: {
              color: '#ffbd67'
            }
          },
          viewControl: {
            minDistance: 0,
            panSensitivity: 10,
            autoRotate: false
            // projection: 'orthographic'
          }
        },
        series: [
          {
            type: 'scatter3D',
            dimensions: this.dimensions,
            data: this.dataSet,
            symbolSize: 2,
            itemStyle: {
              borderWidth: 0
              // borderColor: 'rgba(255,255,255,0.8)'
            },
            emphasis: {
              itemStyle: {
                color: '#fff'
              }
            }
          }
        ]
      }

      this.options = options
    }
  },
  mounted: function() {
    this.updateOptions()
  }
}
</script>

<template lang='pug'>
div
  v-toolbar(fixed, dark)
    v-toolbar-title M6 MapLock
    v-spacer
    v-toolbar-items.hidden-sm-and-down
      v-btn(text) 欢迎你，{{ user.firstName }}
  v-content
  v-container(style="width:60%;background-color:#fafafa;margin-top:30px;margin-bottom: 30px;")
    div
      v-content(color="cyan") 申请内容
    div(style="margin-top:5%")
      v-expansion-panels(
      :accordion="accordion",
      :popout="popout",
      :inset="inset",
      :multiple="multiple",
      :focusable="focusable",
      :disabled="disabled",
      :readonly="readonly",
      :flat="flat",
      :hover="hover",
      :tile="tile"
      )
        v-expansion-panel(v-for="(item,i) in 3",:key="i",style="margin-top:15px")
          v-expansion-panel-header
            v-col(cols="8") 地图名称
            v-col(cols="4",class="text_secondary")
              v-fade-transition(leave-absolute)
                v-row(style="width:100%")
                  span 审批人：
                  strong.blue--text 张三
          v-expansion-panel-content
            v-row
              strong 涉及文件
            v-row
              span XXX/XXX/XXX
            v-row
              span XXX/XXX/XXX
            v-row
              span XXX/XXX/XXX

    div(style="margin-top:5%")
    div
      v-from
        v-textarea(label="申请理由")
        v-btn(color="success",@click="test") 提交
        v-btn(color="warning",@click="test") 重置
</template>

<script>
import store from '@/store'

export default {
  data: () => ({
    filter: {
    },
    common_list: [],
    accordion: false,
    popout: false,
    inset: false,
    multiple: false,
    disabled: false,
    readonly: false,
    focusable: false,
    flat: false,
    hover: false,
    tile: false
  }),
  computed: {
    user: () => store.getters.user
  },
  created: function() {
  },
  props: {
    source: String
  },
  methods: {
    test: function() {
      console.log(1)
    }
  },
  components: {
  }
}
</script>

<template>
  <v-card style="margin-top: 8px;">
    <v-subheader>对比结论</v-subheader>
    <v-row>
      <v-col cols="2">
        <v-subheader>数据A</v-subheader>
        <v-skeleton-loader
          class="reportContent"
          type="image, text@4"
        />
      </v-col>
    </v-row>

    <v-subheader>关键数据</v-subheader>
    <v-skeleton-loader
      class="reportContent"
      type="card"
    />
    <v-subheader>数据详情</v-subheader>
    <v-skeleton-loader
      class="reportContent"
      type="card"
    />
  </v-card>

</template>

<script>
export default {
  name: 'DataReport'
}
</script>

<style scoped>
  .reportContent{
    margin-left: 32px;
  }
</style>

<template lang="pug">
div
  v-container(fluid)
    v-data-table(
      :headers="headers",
      :items="brands",
      :search="search",
      class="elevation-1",
      @click:row="show_row"
    )
      template(slot="items",slot-scope="props")
      template(v-slot:item.action="{ item }")
        v-btn(color="blue darken-1",text) 处理
    v-dialog(v-model="check_data",persistent, @click:outside="close_check_data")
      v-card
        v-card-title
          strong {{apply_data._id}}
        v-card-text
          p.subtitle
          strong 申请人：
          strong.blue--text {{apply_data.apply_user}}
          p.subtitle
          span 申请有效时间：
          span.blue--text {{apply_data.limit_time}}
          p.subtitle
          div
            v-textarea(outlined,v-model="apply_data.apply_log", label="申请原因", disabled=true)
          span 申请内容：
          v-expansion-panels(multiple=true, v-model="panel")
            v-expansion-panel(style="margin-top:5px" v-for="(umap_data,i) in apply_data.apply_data",:key="i")
              v-expansion-panel-header
                v-col(cols="6") {{umap_data.umap_name}}
                v-col(cols="4")
                  span 审批人：
                  span.blue--text {{umap_data.lock_user}}
                v-col(cols="2") 审批状态：
                  span(v-if="umap_data.ci_status===0") 未审批
                  span(v-if="umap_data.ci_status===1")
                    span.green--text 通过
                  span(v-if="umap_data.ci_status===2")
                    span.red--text 拒绝
              v-expansion-panel-content
                div(v-for="(file_path,j) in umap_data.components", :key="j")
                  p.subtitle
                  span {{file_path}}
                v-card-actions
                  v-spacer
                  div(v-if="umap_data.lock_job_number === user.username && umap_data.ci_status===0")
                    v-btn.mx-0(text, icon, small, @click="response_apply(umap_data.umap_name,1)")
                      v-icon(color="primary") done_outline
                    v-btn.mx-0(text, icon, small, @click="response_apply(umap_data.umap_name,2)")
                      v-icon(color="primary") block
          v-card-actions
            v-spacer
            v-btn(color="blue darken-1",text,@click="check_data = false") 关闭

</template>

<script>

import store from '@/store'

export default {
  props: [],
  data: () => ({
    headers: [ // headers表头数组，里面是对象
      { text: '申请编号', align: 'center', value: '_id', sortable: false },
      { text: '申请人', align: 'center', value: 'apply_user', sortable: false },
      { text: '申请时间', align: 'center', value: 'apply_time', sortable: false },
      { text: '申请地图', align: 'center', value: 'umap_name', sortable: false },
      { text: '操作', align: 'center', value: 'action', sortable: false }
    ],
    brands: [],
    search: '',
    panel: [],
    apply_data: {},
    check_data: false
  }),
  components: {
  },
  created: function() {
    this.updateWaitApplyList()
  },
  watch: {
  },
  computed: {
    user: () => store.getters.user
  },
  methods: {
    updateWaitApplyList: function() {
      this.axios
        .get('/get_wait_apply_list', {
          params: {
            job_num: this.user.username
          }
        })
        .then(res => {
          this.brands = res.data
        })
    },
    show_row: function(item) {
      this.get_apply_data(item._id)
    },
    get_apply_data: function(id) {
      this.axios
        .get('/get_apply_data', {
          params: {
            apply_id: id
          }
        })
        .then(res => {
          this.apply_data = res.data
          this.apply_umap_data = this.apply_data.apply_data
          for (let i = 0; i < this.apply_umap_data.length; i++) {
            console.log(this.apply_umap_data[i]['lock_job_number'])
            if (this.apply_umap_data[i]['lock_job_number'] === this.user.username) {
              this.panel.push(i)
              console.log(this.panel)
            }
          }
          this.check_data = true
        })
    },
    close_check_data: function() {
      this.check_data = false
    },
    response_apply: function(umapName, ciStatus) {
      this.axios
        .post('/response_apply', {
          apply_id: this.apply_data._id,
          umap_name: umapName,
          ci_status: ciStatus
        })
        .then(res => {
          this.check_data = false
          let msg = {}
          if (res.data === 'suc') {
            msg = {
              color: 'info',
              text: '操作成功'
            }
          } else {
            msg = {
              color: 'warning',
              text: res.data
            }
          }
          console.log(msg)
          this.updateWaitApplyList()
          this.$emit('apply_alert', msg)
        })
    }
  }
}
</script>
<style lang='sass'>
.v-btn--active
  background-color: green
</style>

<template lang="pug">
  div
    v-chart(:options="options")
</template>
<script>
import Echarts from 'vue-echarts/components/ECharts.vue'
import 'echarts/lib/chart/line'
import 'echarts/lib/component/title'
import 'echarts/lib/component/legend'

export default {
  props: ['labels', 'cols', 'title'],
  components: {
    'v-chart': Echarts
  },
  data: function() {
    return {
      options: null
    }
  },
  mounted: function() {
    this.axios
      .get('/report/api/client_performance_report/history_data', {
        params: {
          cols: this.cols
        }
      })
      .then(res => {
        let series = []
        for (var i = 0; i < this.cols.length; i++) {
          series[i] = {
            name: this.labels[i],
            type: 'line',
            data: res.data.map(item => item[this.cols[i]]),
            markLine: false,
            label: {
              show: true,
              fontSize: 10,
              distance: 5,
              position: 'bottom'
            }
          }
        }

        this.options = {
          title: {
            text: this.title
          },
          legend: {
            orient: 'verticle',
            right: 0,
            top: 0,
            data: this.labels
          },
          tooltip: {
            trigger: 'axis'
          },
          xAxis: {
            data: res.data.map(item => item['title'].slice(-4))
          },
          yAxis: {
            splitLine: {
              show: false
            }
          },
          toolbox: {
            left: 'center',
            feature: {
              dataZoom: {
                yAxisIndex: 'none'
              },
              restore: {},
              saveAsImage: {}
            }
          },
          dataZoom: [
            {
              type: 'inside'
            }
          ],
          series: series
        }
      })
  }
}
</script>

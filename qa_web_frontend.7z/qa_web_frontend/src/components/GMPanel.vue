<template>
  <div>
    <v-snackbar
      v-model="runResult"
      top
      :timeout="tipsTimeout"
      :color="tipsColor"
    >
      {{ runTips }}
    </v-snackbar>
    <v-row>
      <v-col cols="8">
        <v-text-field
          v-model="gmCmd"
          label="输入GM指令"
          style="margin-left: 0px"
        ></v-text-field>
      </v-col>
      <v-col cols="3">
        <v-btn
          color="#F5F5F5"
          style="margin-top: 10px;margin-left: -5px;"
          @click="sendGM()"
          >发送</v-btn
        >
      </v-col>
    </v-row>
  </div>
</template>

<script>
import store from '@/store'

export default {
  name: 'GMPanel',
  data: () => ({
    boomerServer: 'http://' + process.env.VUE_APP_BOOMER_SERVER,
    gmCmd: '',
    runResult: false,
    tipsColor: '',
    runTips: '',
    tipsTimeout: 3000
  }),
  computed: {
    user: () => store.getters.user
  },
  watch: {},
  methods: {
    sendGM() {
      if (this.$store.state.currentDevice === undefined) {
        this.runResult = true
        this.runTips = '未选择设备'
        this.tipsColor = 'error'
        return
      }
      let formData = new FormData()
      formData.append('cmd', this.gmCmd)
      formData.append('clientId', this.$store.state.currentDevice.ip)

      this.axios({
        method: 'post',
        url: this.boomerServer + '/gm/send_cmd',
        data: formData,
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }).then(res => {
        if (res.status === 200 && res.data.status === 0) {
          this.runResult = true
          this.runTips = '发送指令成功'
          this.tipsColor = 'info'
        } else {
          this.runResult = true
          this.runTips = '发送指令失败'
          this.tipsColor = 'error'
        }
      })
    }
  },
  mounted() {}
}
</script>

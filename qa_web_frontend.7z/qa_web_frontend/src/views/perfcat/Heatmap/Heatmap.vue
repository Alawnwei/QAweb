<template lang="pug">
  div.echarts-container
    v-chart(:options="options", style="width:100%")
</template>

<script>
export default {
  data: function() {
    return {
      options: {}
    }
  },
  mounted: function() {
    var xData = [...Array(100).keys()]
    var yData = [...Array(100).keys()]

    this.axios
      .get('/perfcat/location_test_results/', {
        params: {
          job: 10,
          limit: 0
        }
      })
      .then(res => {})

    var options = {
      tooltip: {},
      xAxis: {
        type: 'category',
        data: xData
      },
      yAxis: {
        type: 'category',
        data: yData
      },
      visualMap: {
        type: 'piecewise'
      }
    }

    this.options = options
  }
}
</script>

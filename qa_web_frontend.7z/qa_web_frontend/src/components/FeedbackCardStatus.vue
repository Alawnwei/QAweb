<template lang="pug">
  v-chip.chip(small, outlined, flat, :color="statusColor") {{ statusText }}
</template>
<script>
export default {
  props: ['status'],
  computed: {
    statusText: function() {
      let dic = [
        '未定义',
        '新建',
        '挂起',
        '低优先级',
        '已开单',
        '已忽略',
        '已处理'
      ]

      return dic[this.status]
    },
    statusColor: function() {
      let dic = ['yellow', 'green', 'orange', 'grey', 'red', 'red', 'red']

      return dic[this.status]
    }
  }
}
</script>

<style lang="sass" scoped>
.chip
  position: absolute
  right: .5em
  top: 1em
</style>

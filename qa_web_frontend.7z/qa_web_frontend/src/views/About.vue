<template lang="pug">
.about
  h1 This is an about page
</template>

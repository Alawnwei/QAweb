<template lang='pug'>
v-app
  v-navigation-drawer(v-model='drawer', dark='', fixed='', app='')
    v-list
      v-list-tile(v-for='item in items', :key='item.title', @click='clickNavigation(item)')
        v-list-tile-action
          v-icon {{ item.icon }}
        v-list-tile-content
          v-list-tile-title {{ item.title }}
  v-toolbar(dark='', app='', fixed='')
    v-toolbar-side-icon(@click.stop='drawer = !drawer')
    v-toolbar-title M6 游戏战绩查询
    v-spacer
    v-toolbar-items.hidden-sm-and-down
      v-btn(text='') 欢迎你，{{ user.firstName }}
  v-content
    v-container(fluid='')
      router-view
  v-footer(height='auto', color='primary lighten-3')
    v-layout(justify-center='', row='', wrap='')
      v-flex(primary='', lighten-2='', py-3='', text-xs-center='', white--text='', xs12='')
        | ©2018 —
        strong M6QA
</template>

<script>
import store from '@/store'
import '../../plugins/vuetify'

export default {
  data: () => ({
    drawer: false,
    items: [
      { icon: 'sort', title: '排行榜', link: '/rank' },
      {
        icon: 'sort',
        title: '新建客户端性能报告',
        link: '/report/performance/client/new'
      }
    ]
  }),
  computed: {
    user: () => store.getters.user
  },
  props: {
    source: String
  },
  methods: {
    clickNavigation: function(item) {
      this.$router.push(item.link)
    }
  }
}
</script>

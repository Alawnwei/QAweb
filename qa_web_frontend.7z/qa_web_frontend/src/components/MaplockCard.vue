<template lang="pug">
  v-card(height="300px", outlined, @click="onClickCard")
    div.card-content.pb-3
      v-card-text.pb-0
        v-chip.chip(small, outlined, flat, :color="typeTextColor") {{ typeText }}
        div.d-block
          span.h4
            strong {{ umap_data.umap_name }}
          p.mt-2.subtitle
              strong.blue--text {{ umap_data.umap_path }}
      v-card-text
        strong.d-block.card-content {{ umap_data.lock_log }}
      v-card-text
        div.d-block
          div.my-2
          p.subtitle
            span(v-if="umap_data.umap_lock === 'unlock' ") 最近操作
            span(v-else) 锁定用户
            span.blue--text {{ umap_data.lock_user?umap_data.lock_user:'无' }}
          p.subtitle
            span 操作时间
            span.blue--text {{ umap_data.lock_time?umap_data.lock_time:'--' }}
    div.card-actions
      v-card-actions.actions
        v-tooltip(top, v-if="umap_data.umap_lock=='unlock'")
          template(v-slot:activator="{ on }")
            v-btn.mx-0(text, icon, small, @click="map_lock = true", v-on="on", :loading="lock_loading")
              v-icon(color="primary") lock
          span 上锁
        v-tooltip(top v-if="umap_data.umap_lock=='enlock'&& user.username == umap_data.job_num")
          template(v-slot:activator="{ on }")
            v-btn.mx-0(text, icon, small, @click="map_unlock = true", v-on="on", :loading="lock_loading")
              v-icon(color="primary") lock_open
          span 解锁
        v-tooltip(top v-if="umap_data.umap_lock=='enlock'&& user.username != umap_data.job_num")
          template(v-slot:activator="{ on }")
            v-btn.mx-0(text, icon, small, @click="onSendApply", v-on="on")
              v-icon(color="primary") send
          span 申請
    v-dialog(v-model="map_lock",persistent,max-width="600px")
      v-card
        v-card-title
          span 地图锁定确认
        v-card-text
          div(style="width:80%,margin-left:5%")
              span 你要锁定的地图为：
              p.mt-2.subtitle
              span
                strong {{ umap_data.umap_name }}
              div(style="width:80%")
                strong.blue--text(style="word-wrap:break-word") {{ umap_data.umap_path }}
          v-textarea("label"="记录日志",v-model="lock_log")
        v-card-actions
          v-spacer
          v-btn(color="blue darken-1",text,@click="map_lock = false") 关闭
          v-btn(color="blue darken-1",text,@click="onLock('enlock')") 确认
    v-dialog(v-model="map_unlock",persistent,max-width="600px")
      v-card
        v-card-title
          span 地图解锁确认
        v-card-text
          div(style="width:80%,margin-left:5%")
              span 你要解锁的地图为：
              p.mt-2.subtitle
              span
                strong {{ umap_data.umap_name }}
              div(style="width:80%")
                strong.blue--text(style="word-wrap:break-word") {{ umap_data.umap_path }}
        v-card-actions
          v-spacer
          v-btn(color="blue darken-1",text,@click="map_unlock = false") 关闭
          v-btn(color="blue darken-1",text,@click="onLock('unlock')") 确认
</template>

<script>

import store from '@/store'

export default {
  data: () => {
    return {
      umap_data: '',
      map_lock: false,
      map_unlock: false,
      lock_log: '',
      lock_loading: false
    }
  },
  props: [
    'umapId'
  ],
  components: {
  },
  watch: {
    umap_id: function() {
      this.get_umap_data()
    }
  },
  created: function() {
    this.get_umap_data()
  },
  computed: {
    user: () => store.getters.user,
    typeText: function() {
      if (this.umap_data.umap_lock === 'unlock') {
        return '正常'
      } else {
        return '锁定'
      }
    },
    typeTextColor: function() {
      if (this.umap_data.umap_lock === 'unlock') {
        return 'primary'
      } else {
        return 'warning'
      }
    }
  },
  methods: {
    get_umap_data: function() {
      this.axios
        .get('/get_umap_data', {
          params: {
            umap_id: this.umapId
          }
        })
        .then(res => {
          this.umap_data = res.data
        })
    },
    onLock: function(status) {
      console.log(this.umapId)
      let msg = ''
      if (status === 'enlock') {
        msg = this.lock_log
        if (msg === '') {
          let msg = {
            color: 'warning',
            text: '请记录上锁日志'
          }
          this.$emit('lock_alert', msg)
          return
        }
      } else {
        msg = '正常'
      }
      this.lock_loading = true
      if (status === 'enlock') {
        this.map_lock = false
      } else {
        this.map_unlock = false
      }
      this.axios
        .post('/svn_lock_umap', {
          umap: this.umapId,
          status: status,
          ci_user: this.user.firstName,
          ci_msg: msg,
          ci_job_number: this.user.username
        })
        .then(res => {
          console.log(res.data)
          if (res.data === 'suc') {
            let msg = {
              color: 'info',
              text: '操作成功'
            }
            this.$emit('lock_alert', msg)
          } else {
            let msg = {
              color: 'warning',
              text: res.data
            }
            this.$emit('lock_alert', msg)
          }
          this.get_umap_data()
          this.$emit('update_locked_list')
          this.lock_loading = false
        })
    },
    onSendApply: function(event, target) {
      console.log('onSendApply')
    },
    onClickCard: function() {
    }
  },
  mounted: function() {
  }
}
</script>
<style lang="sass" scoped>
.actions
  position: absolute
  bottom: 0em
  right: 0em
.card-content
  max-height: 340px
  overflow-y: auto
.card-content::-webkit-scrollbar
  width: 0 !important
p.subtitle
  font-size: .5em
  font-weight: 400
  color: grey
  margin: 0 0
h4
  padding: 10px 0
.card-title
  position: relative
.card-content
  width: 100%
.v-btn.type-btn
  min-width: 40px
  min-height: 0px
  height: 20px
  padding: 0
  margin: 0
.zoom-in
  position: absolute
  right: .5em
.active-card
  border: 1px solid green !important
.chip
  position: absolute
  right: .5em
  top: 1em
</style>

<template lang="pug">
v-app
  div
    v-toolbar(fixed, dark)
      v-toolbar-title M6 服务器自动回归测试
      v-spacer
      v-toolbar-items.hidden-sm-and-down
        v-btn(text) 欢迎你，{{ user.firstName }}
    v-content
      v-container(fluid='')
        v-row(dense,style="min-width:1000px")
          v-col(md="2")
            ServerLog(ref="case_Data")
          v-col(md="10")
            v-row
              v-col(cols="4",style="min-width:300px")
                v-text-field(solo,:disabled="isEditor",prefix="分支名:",filled=true,style="width:300px",:value="branch_Name_",v-show="textareaShow")
                v-autocomplete(prepend-icon="mdi-database-search",label="分支名:",style="width:300px",:items="all_branch",v-show="!textareaShow",ref="editor_branch_Name",:filter="customFilter",item-text="branch_name",v-model="branch_Name")
              v-col(cols="1")
                v-dialog(v-model="changeBranchDialog",width="500")
                  template(v-slot:activator="{on}")
                    v-btn(color="primary",height="55",style="margin-left:-200px",@click="editorShow()",v-show="isEditor")
                      span 编辑
                    v-btn(color="red lighten-2",height="55",style="margin-left:-200px",@click="changeBranch()",v-show="!isEditor",v-on="on")
                      span 修改
                  v-card
                    v-card-title  确认
                    v-card-text(style="font-size:22px;font-weight:bold") 你确定切换到分支{{branch_Name}}吗？
                    v-card-actions
                      v-row(justify="center",dense)
                        v-col(cols="2")
                          v-btn(color="orange",@click="cancale_ChangeBN()") 关闭
                        v-col(cols="2")
                          v-btn(color="primary",@click="gs_edit_branch()") 确认
              v-col(cols="2",style="margin-left:-200px;margin-top:-10px")
                v-dialog(v-model="stopServerRestartDialog",width="500")
                  template(v-slot:activator="{on}")
                    v-btn(color="gray",fab=true,x-large=true,@click="server_op()",v-show="isShow")
                      v-progress-circular(size=70,:indeterminate="isCircular",color="primary")
                        span(style="font-size:10px;color:black") {{server_state_show}}
                    v-btn(color="gray",fab=true,x-large=true,@click.stop="stopServerRestartDialog = !stopServerRestartDialog",v-show="stopIsShow")
                      v-progress-circular(size=70,:indeterminate="isCircular",color="primary")
                        span(style="font-size:10px;color:black") 停止启动
                  v-card
                    v-card-title  确认
                    v-card-text(style="font-size:22px;font-weight:bold") 你确定停止服务器启动吗？
                    v-card-actions
                      v-row(justify="center",dense)
                        v-col(cols="2")
                          v-btn(color="orange",@click="stopServerRestartDialog = !stopServerRestartDialog") 关闭
                        v-col(cols="2")
                          v-btn(color="primary",@click.stop="server_stop()") 确认
              v-col(cols="2",style="margin-left:-150px;margin-top:-10px")
                v-btn(color="gray",fab=true,x-large=true,@click="runAllCase()")
                  v-progress-circular(size=70,:indeterminate="caseCircular",color="primary")
                    span(style="font-size:10px;color:black") 重跑case
              v-col(cols="2",style="margin-left:-150px;margin-top:-10px")
                span 当前服务器状态：
                v-btn(:color="serverbt_state_show(server_state)",height="55",style="margin-top:10px") {{serverBtn_state}}
            v-row
              router-view()

  v-footer.py-0(height='auto', dark, fixed)
    v-layout(justify-center, row, wrap)
      v-flex(py-2, text-center, white--text, xs12)
        | 反馈平台 ©2019 &nbsp;
        strong M6 QA
</template>

<script>
import store from '@/store'
import ServerLog from './Server_log'
import qs from 'qs'
export default {
  data: () => ({
    serverBtn_state: null,
    textareaShow: true,
    stopServerRestartDialog: false,
    all_branch: [],
    branch_Name: null,
    branch_Name_: null,
    isEditor: true,
    isCircular: false,
    isRestart: false,
    changeBranchDialog: false,
    isShow: true,
    stopIsShow: false,
    caseData: [],
    server_state_show: '服务器重启',
    server_state: 0,
    emptyList: [],
    caseCircular: false,
    interval: null,
    flag: 'run',
    all_branch_: [{
      'branch_name': null
    }]
  }),
  computed: {
    user: () => store.getters.user
  },
  created() {
    this.get_gs_all_branches()
    this.get_gs_current_branch()
    this.getCaseData()
    this.get_gs_server_status()
  },
  mounted() {
    this.setInterval_useRuler(this.flag)
  },
  destroyed() {
    clearInterval(this.interval)
  },
  watch: {
    caseData: function() {
      this.$refs.case_Data.set_Case_Data(this.caseData)
      this.set_case_Circular_status()
    },
    server_state: function() {
      this.set_circular_status(this.server_state)
      // if(this.server_state==2){
      this.$refs.case_Data.set_Case_Data(this.caseData)
      // }else{
      //   this.$refs.case_Data.set_Case_Data(this.emptyList)
      // }
    }
  },
  methods: {
    customFilter(item, queryText, itemText) {
      const branchN = item.branch_name.toLowerCase()
      const searchText = queryText.toLowerCase()
      return branchN.indexOf(searchText) > -1
    },
    // eslint-disable-next-line camelcase
    serverbt_state_show: function(server_State) {
      // eslint-disable-next-line camelcase
      if (server_State === 0) {
        this.serverBtn_state = '未启动'
        return 'gray'
      // eslint-disable-next-line camelcase
      } else if (server_State === 1) {
        this.serverBtn_state = '启动中'
        return 'red'
      } else {
        this.serverBtn_state = '已启动'
        return 'primary'
      }
    },
    setInterval_useRuler: function(val) {
      if (val === 'stop') {
        clearInterval(this.interval)
        this.interval = null
      } else {
        this.interval = setInterval(() => {
          this.getCaseData()
          this.get_gs_server_status()
          this.get_gs_current_branch()
        }, 10000)
      }
    },
    cancale_ChangeBN: function() {
      this.flag = 'run'
      this.changeBranchDialog = !this.changeBranchDialog
      this.textareaShow = !this.textareaShow
      this.setInterval_useRuler(this.flag)
    },
    clickNavigation: function(item) {
      this.$router.push(item.link)
    },
    goPage: function(page) {
      window.location.href = '/' + page
    },
    set_circular_status: function(val) {
      switch (val) {
        case 1:
          this.stopServerRestartDialog = false
          this.isCircular = true
          this.stopIsShow = true
          this.isShow = false
          break
        case 2:
          this.server_state_show = '服务器重启'
          this.isCircular = false
          this.stopIsShow = false
          this.isShow = true
          break
        case 0:
          this.server_state_show = '服务器启动'
          this.isCircular = false
          this.stopIsShow = false
          this.isShow = true
      }
    },
    set_case_Circular_status: function() {
      if (this.caseData['RUNNINT_CASE'] != null) {
        this.caseCircular = true
      } else {
        this.caseCircular = false
      }
    },
    editorShow: function() {
      this.$refs.editor_branch_Name.focus()
      this.branch_Name = ' '
      this.flag = 'stop'
      this.setInterval_useRuler(this.flag)
      this.textareaShow = !this.textareaShow
      this.isEditor = !this.isEditor
    },
    changeBranch: function() {
      var that = this
      that.isEditor = !that.isEditor
    },
    getCaseData: function() {
      this.axios.get('http://qc-procat.ejoy.com:8210/gs_auto_unit_testing/gs_auto_unit_testing/get_cases/')
        .then(res => {
          this.caseData = res.data
        })
    },
    get_gs_server_status: function() {
      this.axios.get('http://qc-procat.ejoy.com:8210/gs_auto_unit_testing/gs_auto_unit_testing/get_gs_server_status/')
        .then(res => {
          this.server_state = res.data
        })
    },
    server_restart: function() {
      this.axios.get('http://qc-procat.ejoy.com:8210/gs_auto_unit_testing/gs_auto_unit_testing/restart_gs_server/')
        .then(res => {

        })
        .catch(function(error) {
          console.log(error)
        })
    },
    server_stop: function() {
      if (this.server_state === 0) {
        alert('服务器已关闭')
      } else {
        // TODO 发送服务器停止的接口
      }
    },
    server_op: function() {
      if (this.server_state === 1) {
        alert('服务器正在启动中...')
      } else {
        this.isCircular = true
        this.server_restart()
      }
    },
    runAllCase: function() {
      this.caseCircular = true
      this.axios.get('http://qc-procat.ejoy.com:8210/gs_auto_unit_testing/gs_auto_unit_testing/run_all_cases/')
        .then(res => {
        })
        .catch(function(error) {
          console.log(error)
        })
    },
    get_gs_current_branch: function() {
      this.axios.get('http://qc-procat.ejoy.com:8210/gs_auto_unit_testing/gs_auto_unit_testing/get_gs_current_branch/')
        .then(res => {
          this.branch_Name_ = res.data
          this.branch_Name = res.data
        })
    },
    get_gs_all_branches: function() {
      this.axios.get('http://qc-procat.ejoy.com:8210/gs_auto_unit_testing/gs_auto_unit_testing/get_gs_all_branches/')
        .then(res => {
          for (let i = 0; i < res.data.length; i++) {
            this.all_branch.push({
              'branch_name': res.data[i]
            })
          }
          this.all_branch_['branch_name'] = res.data
        })
    },
    gs_edit_branch: function() {
      this.flag = 'run'
      let newBranch = this.branch_Name.replace(' ', '')
      if (newBranch === '') {
        this.branch_Name = this.branch_Name_
        alert('不能为空')
      } else if (this.all_branch_['branch_name'].indexOf(newBranch) === -1) {
        this.branch_Name = this.branch_Name_
        alert('没有该分支！请输入已存在的分支进行切换~')
      } else if (newBranch === this.branch_Name_) {
        this.branch_Name = this.branch_Name_
        alert('目前就是在该分支下')
      } else {
        this.branch_Name_ = this.branch_name
        let data_ = {
          'branch_name': this.branch_Name
        }
        let data = qs.stringify(data_)
        this.axios.post('http://qc-procat.ejoy.com:8210/gs_auto_unit_testing/gs_auto_unit_testing/gs_edit_branch/', data)
          .then(res => {
            this.server_restart()
            this.get_gs_current_branch()
            alert('切换分支成功，等待服务器重启完成。')
          })
      }
      this.changeBranchDialog = false
      this.setInterval_useRuler(this.flag)
      this.textareaShow = !this.textareaShow
    }
  },
  components: {
    ServerLog: ServerLog
  }
}
</script>

<template>
  <v-app id="inspire">
    <v-container fluid>
      <v-select v-model="curJobs" :items="allJobs" multiple label="请选择Job"></v-select>
      <v-btn-toggle v-model="curMetrics" mandatory>
        <span v-for="(item, index) in metricsList" :key="index">
          <v-btn :value="item">{{ item }}</v-btn>
        </span>
      </v-btn-toggle>
      <!--<ve-line :data="curChartData"></ve-line>-->
      <ve-histogram :data="curChartData"></ve-histogram>
    </v-container>
  </v-app>
</template>

<script>
import VeHistogram from 'v-charts/lib/histogram'

export default {
  components: {
    VeHistogram
  },
  data: () => {
    return {
      curJobs: [],
      allJobs: [],
      curMetrics: '',
      metricsList: [],
      chartData: {},
      curChartData: {}
    }
  },
  watch: {
    curMetrics: function(val) {
      this.onChangeMetric(val)
    },
    curJobs: function(val) {
      if (val.length > 0) {
        this.getLocationResult()
      }
    }
  },
  mounted: function() {
    this.getJobs()
  },
  props: {},
  methods: {
    changeMetric: function() {
      // 前端动态 更换metics
      this.curChartData = {}
      this.curChartData['columns'] = this.chartData.columns
      this.curChartData['rows'] = []
      for (var i = 0; i < this.chartData.rows.length; i++) {
        var row = this.chartData.rows[i]
        var copy = {}
        this.curChartData.rows.push(copy)
        for (var key in row) {
          var val = row[key]
          if (val instanceof Map || val instanceof Object) {
            // 取当前的维度
            copy[key] = val[this.curMetrics]
          } else {
            copy[key] = val
          }
        }
      }
      // alert(JSON.stringify(this.curChartData))
    },
    onChangeMetric: function(metric) {
      // alert(metric)
      this.curMetrics = metric
      this.changeMetric()
    },
    getJobs: function() {
      this.axios.get('perfcat/jobs/', {}).then(res => {
        if (res.status === 200) {
          var list = []
          for (var i = 0; i < res.data.length; i++) {
            list.push(res.data[i].id)
          }
          this.allJobs = list
        }
      })
    },
    getLocationResult: function() {
      this.axios
        .post('/perfcat/location_test_results/jobCharData/', {
          jobs: this.curJobs
        })
        .then(res => {
          if (res.data.success) {
            // debugger
            this.chartData = res.data.perfData.chartData
            // alert(JSON.stringify(this.chartData))
            this.metricsList = res.data.perfData.metrics
            // 默认先取第一个维度
            this.curMetrics = this.metricsList[0]
            this.changeMetric()
          }
        })
    }
  }
}
</script>

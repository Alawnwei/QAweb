<template>
  <v-autocomplete
    v-model="currentDevice"
    :items="deviceList"
    :item-text="displayDeviceInfo"
    label="当前设备"
    placeholder="No device selected"
    prepend-inner-icon=""
    outlined
    return-object
    @change="onSelectDevice($event)"
    @focusout="isFocused = false"
    @focusin="isFocused = true"
  >
    <template v-slot:prepend-inner>
      <v-icon :color="deviceOnlineStatusColor">mdi-alarm-light</v-icon>
    </template>
  </v-autocomplete>
</template>

<script>
import _ from 'lodash'
import store from '@/store'

export default {
  name: 'DeviceSelector',
  props: {
    filterSameIp: {
      type: Boolean,
      default: false
    }
  },
  data: () => ({
    boomerServer: 'http://' + process.env.VUE_APP_BOOMER_SERVER,
    onlineSubject: process.env.VUE_APP_ONLINE_SUBJECT,
    currentDevice: {},
    devicePanel: 0,
    devices: {},
    deviceList: [],
    deviceOnlineStatus: true,
    isFocused: false
  }),
  computed: {
    user: () => store.getters.user,
    deviceOnlineStatusColor: function() {
      if (this.currentDevice.ip === undefined) return null
      return this.deviceOnlineStatus ? 'green' : 'red'
    }
  },
  watch: {
    currentDevice: function(newVal, _) {
      if (newVal !== null && newVal !== undefined) {
        const profileTopic = 'boomer.profile.' + newVal.ip
        const logTopic = this.filterSameIp ? 'boomer.showLog.' + newVal.ip + '.>' : 'boomer.showLog.' + newVal.ip + '.port:' + newVal.port

        this.$store.state.currentDevice = newVal
        window.localStorage.setItem('lastDevice', JSON.stringify(newVal))
        this.$emit('changeDevice', { ...newVal, profileTopic, logTopic })
      }
    }
  },
  methods: {
    onSelectDevice(device) {
      if (device !== null && device !== undefined) {
        this.currentDevice = device
        this.deviceOnlineStatus = true
      }
    },
    displayDeviceInfo(device) {
      if (!device) return 'No device was selected'
      return (
        (device.bindName != null ? '[' + device.bindName + '] ' : '') +
        (device.platform != null ? device.platform + '-' : '') +
        (device.serverName !== undefined ? `[${device.serverName}]` : '') +
        (device.account != null ? device.account + '-' : '') +
        device.ip
      )
    },
    handelSetDevice(dList) {
      this.devices = dList

      let currentDeviceOnline = false
      let deviceIpList = []
      this.deviceList = Object.values(this.devices).filter(device => {
        // 如果使用了filterSameIp属性, 会对新的设备列表进行判断, 如果不包含currentDevice, 则清空 currentDevice
        if (!this.filterSameIp) {
          if (!currentDeviceOnline && device.ip === this.currentDevice.ip) {
            currentDeviceOnline = true
          }
          return true
        } else {
          if (!currentDeviceOnline && device.ip === this.currentDevice.ip && (this.currentDevice.account === undefined || device.account === this.currentDevice.account)) {
            currentDeviceOnline = true
          }
        }
        // 保障同一个 ip 只有一个设备
        if (!deviceIpList.includes(device.ip)) {
          deviceIpList.push(device.ip)
          return true
        }
        return false
      })

      this.deviceOnlineStatus = currentDeviceOnline

      // 下面的请求拉取 M6 平台的设备绑定数据, 给设备一个更直观的名字
      this.axios.get('http://qc-procat.ejoy.com:8210/get_user_device?email=' + store.getters.user.email, {}).then(res => {
        if (res.status === 200) {
          let myDevices = res.data
          let myDevicesMap = {}
          for (let i = 0; i < myDevices.length; i++) {
            myDevicesMap[myDevices[i]['mac']] = myDevices[i]['device_name']
          }
          let tmpMyList = []
          let tmpOtherList = []
          let setCurDevice = null
          for (var i = 0; i < this.deviceList.length; i++) {
            let di = this.deviceList[i]
            if (this.currentDevice !== undefined && this.currentDevice.ip === di.ip && (this.currentDevice.account === undefined || this.currentDevice.account === di.account)) {
              setCurDevice = di
            }
            if (myDevicesMap[di.mac_address] !== undefined) {
              di.bindName = myDevicesMap[di.mac_address]
              tmpMyList.push(di)
            } else {
              tmpOtherList.push(di)
            }
          }
          this.deviceList = _.concat(tmpMyList, tmpOtherList)
          if (setCurDevice !== null && setCurDevice !== undefined && this.isFocused) {
            this.currentDevice = setCurDevice
          }
        }
      })
    },
    loadDevices() {
      this.deviceList = []
      let formData = new FormData()
      this.axios({
        method: 'post',
        url: this.boomerServer + '/boomer/online_devices',
        data: formData,
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }).then(res => {
        if (res.status === 200 && res.data.status === 0) {
          // console.log('sub');
          // console.log(res.data.data);
          this.handelSetDevice(res.data.data)
        }
      })
      this.$nats.subscribe(this.onlineSubject, event => {
        // console.log('sub');
        // console.log(event);
        this.handelSetDevice(event)
      })
    }
  },
  mounted() {
    const lastDevice = window.localStorage.getItem('lastDevice')
    if (lastDevice !== null && lastDevice !== undefined) {
      this.currentDevice = JSON.parse(lastDevice)
      this.$store.state.currentDevice = this.currentDevice
    }
    this.loadDevices()
  }
}
</script>

<style scoped></style>

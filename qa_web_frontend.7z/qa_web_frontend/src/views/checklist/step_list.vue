<template lang='pug'>
v-container
  v-row
    v-col(cols=2)
      div(class="my_col_left")
        v-navigation-drawer(permanent,floating)
          v-list-item-content
            strong 当前进度:
            v-progress-circular(
            :rotate="0",
            :size="150",
            width="35"
            :value="progress",
            color="success",
            style="{'margin':'50px 20px'}",
            )
              h2 {{progress}}%
          v-divider
          v-navigation-drawer(permanent,right,floating)
            div(class="nav_list",id="nav_list",style="height:600px")
              v-list(dense)
                v-list-item(
                  v-for="(item,i) in todolist",
                  :key = "item.id",
                  @click="scorllToExpanel(item.id)",
                  two-line
                )
                  v-list-item-icon
                    v-icon(:color="color_status(item)") {{icon_status(item)}}
                  v-list-item-content
                    v-list-item-title
                      strong {{item.title}}
                    v-list-item-subtitle
                      small 负责人: {{item.current_responsible_user[0].first_name}}
    v-col(cols=8)
      v-content
        v-card(elevation="0")
          v-card-title
          v-card-text
            v-expansion-panels(multiple,v-model="panel",disabled)
              v-expansion-panel(v-for="(item,i) in todolist",:id="'id'+item.id",:key='item.id')
                v-expansion-panel-header(:color="color_status(item)",disable-icon-rotate)
                  span(v-if="item.check_status")
                    strong.white--text {{item.title}}
                  span(v-else)
                    strong.black--text {{item.title}}

                v-expansion-panel-content
                  v-card-text(class="panel_description")
                    p.subtitle
                    span.black--text
                      strong 事项：
                    p.subtitle
                    span.black--text {{item.description}}
                    v-divider
                    p.subtitle
                    span
                      strong.black--text 负责人:
                    p.subtitle
                    span.mr-4(v-for="user in item.current_responsible_user",:key="user.job_number")
                        span.black--text {{user.first_name}}
                    v-divider
                  v-card-actions(v-if="item.check_status === 2")
                    v-spacer
                    div(class="check_actions")
                      span
                        strong 确认人：
                      span.blue--text {{item.checked_user.first_name}}
                    div(class="check_actions")
                      span
                        strong 确认时间：
                      span.blue--text {{ time_format(item.checked_time,'yyyy-MM-dd hh:mm:ss')}}
                  v-card-actions(v-else)
                    v-btn(
                      dark,
                      color="#3296fa",
                      text-color="white",
                      style="",
                      @click="confirm_send(item)",
                      v-if="item.check_status != 2"
                    )
                      span(class="dingding")
                      strong.white--text 钉钉提醒
                    v-spacer
                    v-btn(color="blue darken-1",dark,@click="confirm_finish(item)",:disabled="!check_allow_user_id(item)")
                      strong 确认完成
                v-progress-linear(:buffer-value="buffer_status(item)",stream,:color="color_status(item)",height="10")
            v-dialog(v-model="finish_confirm",width="500")
              v-card
                v-card-title(primary-title)
                  span 事项完成确认
                v-card-text
                  span 事项
                  span.warning--text {{confirm_item.title}}
                  span 已完成
                v-card-actions
                  v-spacer
                  v-btn(color="primary", text, @click="finish(confirm_item)") 确认
            v-dialog(v-model="send_confirm",width="500")
              v-card
                v-card-title(primary-title)
                  span 钉钉提醒
                v-card-text
                  span 将要发送钉钉提醒
                v-card-actions
                  v-spacer
                  v-btn(color="primary", text, @click="do_send_dd_notice(send_item)") 确认发送
    v-col(cols=2)
        div(class="my_col")
          v-navigation-drawer(permanent,floating)
            v-list-item
              v-list-item-content
                v-list-item-title
                  h2.strong 值班表
            v-divider
            v-card(v-for="duty_group, i in duty_list", :key="i")
              v-card-title()
                span {{duty_group.name}}
              v-card-text
                v-list-item(v-for="username, j in duty_group.users",:key="j")
                  v-list-item-content
                    v-list-item-title {{ username }}

</template>

<script>
import store from '@/store'

export default {
  data: () => ({
    panel: [],
    todolist: [],
    progress: 0,
    finish_confirm: false,
    confirm_item: {},
    send_confirm: false,
    send_item: {},
    send_user: {},
    duty_list: []
  }),
  computed: {
    user: () => store.getters.user
  },
  created: function() {
    this.updateTodoList()
    this.getDuty()
  },
  props: {
  },
  methods: {
    scorllToExpanel: function(itemid) {
      let idselector = '#id' + itemid
      let selectorOption = { block: 'center', inline: 'center' }
      document.querySelector(idselector).scrollIntoView(selectorOption)
    },
    updateTodoList: function() {
      this.axios
        .get('/checklist/todolists', {})
        .then(res => {
          this.todolist = res.data
          console.log(this.todolist)
          this.updataProgress()
        })
    },
    updataProgress: function() {
      let i = 0
      let sum = 0
      let todolist = this.todolist
      for (i; i < todolist.length; i++) {
        let index = this.panel.indexOf(i)
        if (index === -1) {
          this.panel.push(i)
        }
        if (todolist[i].check_status === 2) {
          sum += 1
        }
        continue
      }
      this.progress = Math.round(sum / i * 100)
      this.height_option()
    },
    confirm_send: function(item) {
      if (item.check_status) {
        return
      }
      this.send_item = item
      this.send_confirm = true
    },
    do_send_dd_notice: function(item) {
      let userList = item.related_user
      userList.push(item.responsible_user)
      for (let j = 0; j < userList.length; j++) {
        this.send_dd_notice(userList[j], item)
      }
      this.send_confirm = false
    },
    send_dd_notice: function(user, item) {
      this.axios
        .post('/checklist/todolists/send_notice/', {
          'job_number': user.job_number,
          'todo_title': item.title
        })
        .then(res => {
          // console.log(res.data)
        })
    },
    confirm_finish: function(item) {
      this.confirm_item = item
      this.finish_confirm = true
    },
    check_allow_user_id: function(item) {
      let allowList = []
      allowList.push(item.responsible_user.id)
      let relatedUser = item.related_user
      for (let i = 0; i < relatedUser.length; i++) {
        allowList.push(relatedUser[i].id)
      }
      // todo 从服务器获取当天值日/值周同学的id
      // console.log(allowList.includes(this.user.id))
      return allowList.includes(this.user.id)
    },
    finish: function(item) {
      // console.log(item.id)
      let isAllow = this.check_allow_user_id(item)
      // console.log(isAllow)
      if (!isAllow) {
        alert('您暂时无法确认本次流程')
        this.finish_confirm = false
        return
      }
      let url = '/checklist/todolists/' + item.id + '/'
      let myDate = new Date()
      let nowTime = this.time_format(myDate, 'yyyy-MM-ddThh:mm:ss')
      // console.log(nowTime)
      // console.log(this.user)
      let params = {
        checked_user_id: this.user.id,
        check_status: 2,
        checked_time: nowTime
      }
      // console.log(this.user.id)
      // console.log(params)
      this.axios
        .patch(url, params)
        .then(res => {
          // console.log(res.data)
          this.finish_confirm = false
          this.updateTodoList()
        })
    },
    time_format: function(datatime, fmt) {
      let date = new Date(datatime)
      if (/(y+)/.test(fmt)) {
        fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length))
      }
      let o = {
        'M+': date.getMonth() + 1,
        'd+': date.getDate(),
        'h+': date.getHours(),
        'm+': date.getMinutes(),
        's+': date.getSeconds()
      }
      for (var k in o) {
        if (new RegExp('(' + k + ')').test(fmt)) {
          var str = o[k] + ''
          fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? str : ('00' + str).substr(str.length))
        }
      }
      return fmt
    },
    height_option: function() {
      // 控制主模块布局
      // let clientWidth = document.body.clientWidth
      let clientHeight = document.body.clientHeight
      let doc = document.getElementById('nav_list')
      let itemHeight = this.todolist.length * 60 + 20
      let windowHeight = clientHeight * 0.6
      let needHeight = itemHeight > windowHeight ? windowHeight : itemHeight
      let newHeight = needHeight + 'px'
      doc.style.height = newHeight
      // console.log(newHeight)
    },
    color_status: function(item) {
      if (item.check_status === 2) {
        return 'cyan'
      } else if (item.check_status === 1) {
        return 'pink lighten-3'
      } else {
        return 'orange lighten-3'
      }
    },
    buffer_status: function(item) {
      if (item.check_status === 2) {
        return 100
      } else if (item.check_status === 1) {
        return 50
      } else {
        return 10
      }
    },
    icon_status: function(item) {
      if (item.check_status === 2) {
        return 'check_circle'
      } else if (item.check_status === 1) {
        return 'warning'
      } else {
        return 'play_circle_filled'
      }
    },
    getDuty: function() {
      let params = {
        refresh_type: 2
      }
      this.axios
        .get('/checklist/duty_groups/', {
          params: params
        })
        .then(res => {
          this.dealFirstDuty(res.data)
        })
    },
    dealFirstDuty: async function(groupData) {
      for (let i in groupData) {
        let dutyData = {}
        let group = groupData[i]
        dutyData.name = group.name
        dutyData.users = []
        for (let j in group.duty_order[0]) {
          let uid = group.duty_order[0][j]
          let uname = await this.getUserNameById(uid)
          dutyData.users.push(uname)
        }
        this.duty_list.push(dutyData)
      }
      console.log(this.duty_list)
    },
    getUserNameById: async function(uid) {
      let url = '/auth/users/' + uid
      let name = await this.axios
        .get(url, {})
        .then(res => {
          let userData = res.data
          return userData.first_name
        })
      return name
    }
  },
  components: {
  }
}

</script>

<style lang="sass" scoped>

.v-btn--disabled
  color: black !important
  background: blue !important

.v-expansion-panel
  margin: 0.5% 0

.col
  padding: 0 !important

.panel_description
  margin: 1% 0

.my_col
  position: fixed
  margin-left:2%

.my_col_left
  position: fixed
  margin-right:3%

.check_actions
  margin: auto 15px

.dingding
  display: inline-block
  width: 2em
  height: 2em
  margin-right:0.5em
  vertical-align: -0.125em
  background: url('https://api.iconify.design/ant-design:dingding-outlined.svg?height=18&color=%23ffffff') no-repeat center center / contain

</style>

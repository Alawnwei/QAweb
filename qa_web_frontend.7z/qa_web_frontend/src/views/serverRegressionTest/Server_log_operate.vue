<template lang="pug">
    v-content
      v-container(fluid=true)
        v-card(elevation="2",style="min-width:800px")
          v-toolbar(flat=true)
            v-toolbar-title {{card_title}}
            v-spacer
            v-switch(
              hide-details,
              v-model="disable",
              label="追踪服务器日志",
              v-show="switch_isShow",
              style="margin-right:50px;")
            v-btn(large=true,@click.stop="changeCode('p')",value="p") python展示
            v-btn(large=true,@click.stop="changeCode('l')",value="l") lua展示
            v-btn(large=true,@click.stop="changeCode('c')",value="c") C++展示
            v-btn(large=true,@click.stop="dialog=true") 查看源码
          v-divider
          v-card-text
            MonacoEditor(
              ref="editor",
              theme="High Contrast Dark",
              class="editor",
              v-model="case_detail",
              :language="language")
          v-divider
          v-card-actions
            v-row
              v-col(cols="4",sm="2")
                v-text-field(solo=true,prefix="负责人:",disabled)
              v-spacer
              v-spacer
              v-col(cols="2",sm="1",align="right")
                v-btn(color="gray",large=true,@click="clearMsg()") 清屏
              v-col(cols="2",sm="1")
                v-btn(color="primary",large=true,@click="run_single_case({file_name})") 重跑脚本
</template>
<script>
import MonacoEditor from 'vue-monaco'
import qs from 'qs'
export default {
  components: {
    MonacoEditor
  },
  computed: {
  },
  watch: {
    $route() {
      if (this.$route.params.file_name !== '服务器Log') {
        clearInterval(this.myInterval)
        this.file_name = this.$route.params.file_name
        this.file_point = 0
        this.add_content = []
        this.case_detail_ = ''
        this.case_detail = ''
        this.disable = false
        this.switch_isShow = false
        this.flag = 'runCase'
        this.log_sync(this.file_point, this.file_name, this.flag)
      } else {
        this.file_name = this.server_LOG
        this.file_point = 0
        this.add_content = []
        this.case_detail = ''
        this.flag = 'runServe'
        this.switch_isShow = true
        this.disable = false
      }
    },
    file_name: function () {
      if (this.file_name === 'sys') {
        this.card_title = '服务器Log'
      } else {
        this.card_title = this.file_name
      }
    },
    disable: function() {
      if (this.disable === false) {
        console.log(this.flag)
      } else {
        this.log_sync(this.file_point, this.file_name, this.flag)
      }
    }
  },
  destroyed() {
    clearInterval(this.myInterval)
  },
  data: () => ({
    case_detail: '',
    case_detail_: '',
    language: '',
    dialog: false,
    testdata: '',
    file_name: '',
    file_point: 0,
    add_content: [],
    card_title: '服务器Log',
    server_LOG: 'sys',
    myInterval: null,
    clientHeight: '',
    disable: false,
    switch_isShow: false,
    array_cache: [],
    array_cache_: [],
    flag: 'runCase'
  }),
  created() {
    this.file_name = this.$route.params.file_name
    if (this.file_name === '服务器Log') {
      this.file_name = this.server_LOG
      this.switch_isShow = true
    } else {
      this.switch_isShow = false
      this.log_sync(this.file_point, this.file_name, this.flag)
    }
  },
  mounted() {

  },
  methods: {
    run_server_log: function() {
      if (this.disable === true) {
        this.flag = 'run'
        this.log_sync(this.file_point, this.file_name, this.flag)
      } else {

      }
    },
    changeCode: function(val) {
      switch (val) {
        case 'p':
          this.language = 'python'
          console.log(this.language)
          break
        case 'l':
          this.language = 'lua'
          console.log(this.language)
          break
        case 'c':
          this.language = 'cpp'
          console.log(this.language)
      }
    },
    clearMsg: function() {
      this.file_point = 0
      this.add_content = []
      this.case_detail_ = ''
      this.case_detail = ''
    },
    log_sync: function(filePoint, fileName, flag) {
      let data_ = {
        'file_name': fileName,
        'file_point': filePoint
      }
      let data = qs.stringify(data_)
      this.axios.post('http://qc-procat.ejoy.com:8210/gs_auto_unit_testing/gs_auto_unit_testing/log_sync/', data)
        .then(res => {
          if (this.file_point !== res.data['file_point'] && fileName === this.server_LOG && flag === 'runServe') {
            this.file_point = res.data['file_point']
            console.log(this.file_point)
            // this.log_sync(this.file_point, this.file_name)
            this.add_content = this.add_content.concat(res.data['add_content']) // 存储该时间段服务器运行时所有的日志信息
            let content = this.add_content.toString().replace(',', '') // 转化字符串
            let length = this.add_content.length
            this.case_detail = content.substr(length - 10240)
            this.log_sync(this.file_point, this.server_LOG, this.flag)
            // for (let i = 0; i < length / 10240; i++) {  全部的add_content数据
            //   let index_ = i * 1024
            //   this.array_cache_[i] = this.add_content.substr(index_ * 10240, (index_ + 1) * 10240)
            //   this.case_detail = this.array_cache_[i].toString()
            // }
          } else if (this.flag === 'runCase') {
            console.log('判断结束')
            this.add_content = this.add_content.concat(res.data['add_content'])
            let caseDetail_ = this.add_content.toString().replace(',', '')
            this.case_detail = caseDetail_
          } else {
            console.log('跳出递归')
          }
        })
    },
    run_single_case: function(fileName) {
      let data_ = {
        'case_name': fileName
      }
      let data = qs.stringify(data_)
      this.axios.post('http://qc-procat.ejoy.com:8210/gs_auto_unit_testing/gs_auto_unit_testing/run_single_case/', data)
        .then(res => {
          // TODO
        })
    }
  }
}
</script>
<style>
  .editor{
    width: 100%;
    height: 480px;
  }
  .v-label{
    font-size: 20px;
    font-weight: bold;
  }
</style>

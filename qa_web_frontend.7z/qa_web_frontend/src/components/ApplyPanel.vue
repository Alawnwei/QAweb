<template lang="pug">
div
  v-expansion-panel-header
    v-col(cols="4")
      strong {{apply_data._id}}
      v-chip.chip(small, outlined, flat, :color="typeTextColor", align="right") {{ typeText }}
    v-col(cols="8")

  v-expansion-panel-content()
    p.subtitle
    span 申请有效时间：
    span.blue--text {{apply_data.limit_time}}
    p.subtitle
    span 申请内容：
    v-expansion-panels(multiple=true, v-model="panel")
      v-expansion-panel(style="margin-top:5px" v-for="(umap_data,i) in apply_umap_data",:key="i")
        v-expansion-panel-header
          v-col(cols="6")
            span {{get_umap_name(umap_data)}}
          v-col(cols="4")
            span 审批人：
            span.blue--text {{umap_data.lock_user}}
          v-col(cols="2") 审批状态：
            span(v-if="umap_data.ci_status===0") 未审批
            span(v-if="umap_data.ci_status===1")
              span.green--text 通过
            span(v-if="umap_data.ci_status===2")
              span.red--text 拒绝
        v-expansion-panel-content
          div(v-for="(file_path,j) in umap_data.components", :key="j")
            p.subtitle
            span {{file_path}}
    p.subtitle
    v-textarea(outlined,v-model="apply_log", label="申请原因", :disabled="log_disable")
    div(v-if="!log_disable")
      v-spacer
        v-btn(color="blue darken-1",text,@click="commit_apply = true") 提交申请
        v-btn(color="blue darken-1",text,@click="cancel_apply()") 取消申请
    v-dialog(v-model="commit_apply",persistent,max-width="600px")
      v-card
        v-card-title
          span 临时权限申请
        v-card-text
          div(style="width:80%,margin-left:5%")
              span 你将申请以下文件的提交权限：
              div(v-for="(umap_data,i) in apply_umap_data",:key="i")
                span {{get_umap_name(umap_data)}}
                span ({{umap_data.lock_user}})
              p.subtitle
              v-textarea(outlined, label="申请原因",v-model="apply_log" , :disabled="log_disable")
        v-card-actions
          v-spacer
          v-btn(color="blue darken-1",text,@click="commit_apply = false") 关闭
          v-btn(color="blue darken-1",text,@click="send_apply") 确认
</template>

<script>

import store from '@/store'

export default {
  props: [
    'applyId'
  ],
  data: () => ({
    apply_data: '',
    panel: [],
    apply_umap_data: '',
    commit_apply: false,
    apply_log: '',
    log_text: ''
  }),
  components: {
  },
  created: function() {
    this.get_apply_data()
  },
  watch: {
  },
  computed: {
    user: () => store.getters.user,
    typeText: function() {
      // 0:未申请, 1:申请钟, 2：通过, 3：失败, 4：取消
      switch (this.apply_data.apply_status) {
        case 0:
          return '待申请'
        case 1:
          return '审批中'
        case 2:
          return '申请通过'
        case 3:
          return '申请失败'
        default:
          return '已删除'
      }
    },
    typeTextColor: function() {
      // 0:未申请, 1:申请钟, 2：通过, 3：失败, 4：取消
      switch (this.apply_data.apply_status) {
        case 0:
          return 'grey'
        case 1:
          return 'blue'
        case 2:
          return 'green'
        case 3:
          return 'red'
        default:
          return 'grey'
      }
    },
    log_disable: function() {
      // 0:未申请, 1:申请钟, 2：通过, 3：失败, 4：取消
      if (this.apply_data.apply_status === 0) {
        return false
      } else {
        return true
      }
    }
  },
  methods: {
    get_apply_data: function() {
      this.axios
        .get('/get_apply_data', {
          params: {
            apply_id: this.applyId
          }
        })
        .then(res => {
          this.apply_data = res.data
          this.apply_umap_data = this.apply_data.apply_data
          this.apply_log = this.apply_data.apply_log
        })
    },
    send_apply: function() {
      this.axios
        .post('/send_apply', {
          apply_id: this.applyId,
          apply_log: this.apply_log
        })
        .then(res => {
          this.commit_apply = false
          let msg = {}
          if (res.data === 'suc') {
            msg = {
              color: 'info',
              text: '操作成功'
            }
          } else {
            msg = {
              color: 'warning',
              text: res.data
            }
          }
          this.$emit('apply_alert', msg)
          this.get_apply_data()
        })
    },
    cancel_apply: function() {
      this.axios
        .post('/cancel_apply', {
          apply_id: this.applyId
        })
        .then(res => {
          this.commit_apply = false
          let msg = {}
          if (res.data === 'suc') {
            msg = {
              color: 'info',
              text: '操作成功'
            }
          } else {
            msg = {
              color: 'warning',
              text: res.data
            }
          }
          this.$emit('apply_alert', msg)
          this.get_apply_data()
        })
    },
    get_umap_name: function(umapData) {
      if (umapData.umap_path) {
        return umapData.umap_path
      } else {
        return umapData.umap_name
      }
    }
  }
}
</script>
<style lang='sass'>
.v-btn--active
  background-color: green
</style>

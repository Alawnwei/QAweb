<template>
  <div id="app">
    <v-container id="inspire">
      <v-row>
        <v-col cols="3">
          <DeviceSelector @changeDevice="changeDevice($event)" filter-same-ip />
          <v-card style="margin-top: 24px;overflow-y: auto" max-height="657">
            <v-sheet class="lighten-2 primary">
              <v-text-field prepend-inner-icon="search" v-model="search" hide-details label="Search" flat solo clearable clear-icon="mdi-close-circle-outline" />
            </v-sheet>
            <v-card-text>
              <v-treeview hoverable dense ref="treeview" :open="openDir" :items="scriptFiles" :search="search" :filter="filter" activatable item-key="path" @update:active="openFile($event)">
                <template v-slot:prepend="{ item, open }">
                  <v-icon v-if="item.children">{{ open ? 'mdi-folder-open' : 'mdi-folder' }}</v-icon>
                  <v-icon v-else>{{ fileTypes[item.fileType] }}</v-icon>
                </template>
                <template v-slot:append="{ item, active }">
                  <div v-if="active">
                    <v-btn v-if="item.children" color="blue darken-1" icon text @click.stop="openAddFileDialog(false)">
                      <v-icon>mdi-file-plus</v-icon>
                    </v-btn>
                    <v-btn v-if="item.children" color="blue darken-1" icon text @click.stop="openAddFileDialog(true)">
                      <v-icon>mdi-folder-plus</v-icon>
                    </v-btn>
                    <v-btn icon @click.stop="editDialog = true">
                      <v-icon>mdi-pencil</v-icon>
                    </v-btn>
                    <v-dialog v-model="addDialog" max-width="480">
                      <v-card>
                        <v-card-title class="headline">添加{{ fileLabel }}</v-card-title>
                        <v-card-text>
                          <v-text-field :label="fileLabel" v-model="newFileName" />
                        </v-card-text>
                        <v-card-actions>
                          <v-spacer></v-spacer>
                          <v-btn color="green darken-1" text @click="addDialog = false">取消</v-btn>
                          <v-btn color="green darken-1" text @click="addFile(item.path, isDir)">确认</v-btn>
                        </v-card-actions>
                      </v-card>
                    </v-dialog>

                    <v-dialog v-model="editDialog" max-width="480">
                      <v-card>
                        <v-card-title class="headline">编辑</v-card-title>
                        <v-card-text>
                          <v-text-field :label="fileLabel" v-model="item.name" />
                        </v-card-text>
                        <v-card-actions>
                          <v-btn color="#FF0000" text @click="deleteDialog = true" align="left">删除</v-btn>
                          <v-spacer></v-spacer>
                          <v-btn color="green darken-1" text @click="editDialog = false">取消</v-btn>
                          <v-btn color="green darken-1" text @click="renameFile(item)">确认</v-btn>
                        </v-card-actions>
                      </v-card>
                    </v-dialog>
                    <v-dialog v-model="deleteDialog" max-width="320">
                      <v-card>
                        <v-card-title class="headline">确认删除</v-card-title>
                        <v-card-text> {{ fileLabel + item.name }}删除后无法恢复, 确认删除? </v-card-text>
                        <v-card-actions>
                          <v-btn color="green darken-1" text @click="deleteDialog = false">取消</v-btn>
                          <v-btn color="green darken-1" text @click="delFile(item.path)">确认</v-btn>
                        </v-card-actions>
                      </v-card>
                    </v-dialog>
                  </div>
                </template>
              </v-treeview>
            </v-card-text>
          </v-card>
        </v-col>
        <v-col cols="9">
          <v-tabs v-model="activeTab" dark color="#ffffff" centered grow>
            <v-tabs-slider color="#ffffff" />
            <v-tab key="editor" style="text-transform: none !important;">
              {{ currentFile ? currentFile.path || '未选中文件' : '未选中文件' }}
            </v-tab>
            <v-tab key="logger" style="text-transform: none !important;">Log</v-tab>
            <v-tooltip top>
              <template v-slot:activator="{ on }">
                <v-btn icon style="margin: auto 8px auto auto;" v-on="on" @click="reloadFile" :loading="editorLoading"><v-icon>mdi-reload</v-icon></v-btn>
              </template>
              <span>重新载入文件</span>
            </v-tooltip>
            <v-tooltip top>
              <template v-slot:activator="{ on }">
                <v-btn icon style="margin: auto 8px auto auto;" v-on="on" @click="saveFile" :loading="saveLoading"><v-icon>mdi-content-save</v-icon></v-btn>
              </template>
              <span>保存文件</span>
            </v-tooltip>
            <v-tooltip top>
              <template v-slot:activator="{ on }">
                <v-btn icon style="margin: auto 8px auto auto;" v-on="on" @click="showMutilDeviceDialog"><v-icon>mdi-server</v-icon></v-btn>
              </template>
              <span>打开多设备配置</span>
            </v-tooltip>
            <v-tooltip top>
              <template v-slot:activator="{ on }">
                <v-btn icon style="margin: auto 8px auto auto;" v-on="on" @click="runCode" :loading="runCodeLoading"><v-icon>mdi-play-circle-outline</v-icon></v-btn>
              </template>
              <span>运行代码</span>
            </v-tooltip>
            <v-tab-item>
              <MonacoEditor ref="codeEditor" v-model="onScreenCode" theme="vs-dark" class="editor" language="lua" @change="editContent" />
            </v-tab-item>
            <v-tab-item>
              <LogWidget :log-topic="currentLogTopic" />
            </v-tab-item>
          </v-tabs>
        </v-col>
        <v-snackbar top v-model="snackbar" :color="snackbarType" :timeout="snackbarTimeout">
          {{ snackbarInfo }}
          <v-btn text @click="snackbar = !snackbar">关闭</v-btn>
        </v-snackbar>
        <v-dialog v-model="mutilDeviceDialog" width="60%">
          <MutilDeviceSelector ref="mutilDeviceSelector">
            <template v-slot:Button1>
              <v-btn text @click="showMutilDeviceDialog">取消</v-btn>
            </template>
            <template v-slot:Button2>
              <v-btn text @click="batchRunCode">批量运行</v-btn>
            </template>
          </MutilDeviceSelector>
        </v-dialog>
      </v-row>
    </v-container>
  </div>
</template>
<script>
import MonacoEditor from 'vue-monaco'
import LogWidget from '../../../components/LogWidget'
import DeviceSelector from '../../../components/DeviceSelector'
import MutilDeviceSelector from '../../../components/MutilDeviceSelector'

export default {
  components: {
    MutilDeviceSelector,
    MonacoEditor,
    DeviceSelector,
    LogWidget
  },
  data: function() {
    return {
      boomerServer: 'http://' + process.env.VUE_APP_BOOMER_SERVER,
      projectPath: 'M6Project',
      activeTab: null,
      openDir: [],
      scriptTree: [],
      scriptFiles: [],
      search: null,
      newFileName: 'new',
      editDialog: false,
      deleteDialog: false,
      addDialog: false,
      mutilDeviceDialog: false,
      isDir: false,
      saveLoading: false,
      editorLoading: false,
      runCodeLoading: false,
      fileTypes: {
        FILE: 'mdi-language-lua'
      },
      codeEditor: null,
      onScreenCode: '',
      currentFile: null,
      snackbarType: 'success',
      snackbarInfo: '',
      snackbar: false,
      snackbarTimeout: 2000,
      currentLogTopic: '',
      currentDeviceId: '127.0.0.1'
    }
  },
  watch: {
    currentFile: function(newItem, oldItem) {
      if (newItem.content == null) {
        this.reloadFileBase(newItem.path)
      }
    }
  },
  computed: {
    fileLabel: function() {
      return this.isDir ? '文件夹' : '文件'
    },
    filter: function() {
      return (item, search, textKey) => item[textKey].toLowerCase().indexOf(search.toLowerCase()) > -1
    }
  },
  methods: {
    showMutilDeviceDialog: function() {
      this.mutilDeviceDialog = !this.mutilDeviceDialog
      //      if (this.$refs.mutilDeviceSelector) {
      //        this.$refs.mutilDeviceSelector.loadDevices()
      //      }
    },
    changeDevice: function(newDevice) {
      this.currentLogTopic = newDevice.logTopic
      this.currentDeviceId = newDevice.ip
    },
    notify: function(type, info) {
      // type ['success', 'info', 'error']
      // 由于全局设置, type 暂时没生效
      const color = {
        success: '#4CAF50',
        info: '#2196F3',
        error: '#FF5252'
      }
      this.snackbarType = color[type]
      if (type === 'error') {
        this.snackbarTimeout = 0
      } else {
        this.snackbarTimeout = 2000
      }
      this.snackbarInfo = type + ': ' + info
      this.snackbar = true
    },
    openAddFileDialog: function(isDir) {
      this.addDialog = true
      this.isDir = isDir
    },
    openFile: function(itemList) {
      const filePath = itemList[0]
      if (!filePath) {
        return
      }
      const selectItem = this.findLocalFile(filePath)
      if (selectItem.file) {
        this.currentFile = selectItem
        this.onScreenCode = selectItem.content || ''
      }
      this.activeTab = 'editor'
    },
    reloadFile: function() {
      this.reloadFileBase(this.currentFile.path)
    },
    reloadFileBase: function(path) {
      this.editorLoading = true
      let formData = new FormData()
      formData.append('path', path)
      this.axios({
        method: 'post',
        url: this.boomerServer + '/scripts/get',
        data: formData,
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }).then(res => {
        if (res.status === 200 && res.data.status === 0) {
          this.currentFile.content = res.data.data.content
          this.onScreenCode = res.data.data.content
          this.editorLoading = false
          this.notify('success', '获取文件成功')
        } else {
          this.notify('error', 'reload 失败')
        }
      })
    },
    saveFile: function() {
      this.saveLoading = true
      let content = '\n'
      if (this.currentFile.content) {
        content = this.currentFile.content
      }
      let formData = new FormData()
      formData.append('path', this.currentFile.path)
      formData.append('content', content)
      this.axios({
        method: 'post',
        url: this.boomerServer + '/scripts/add',
        data: formData,
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }).then(res => {
        if (res.status === 200 && res.data.status === 0) {
          this.saveLoading = false
          this.notify('success', '保存成功')
        } else {
          this.notify('error', '保存失败')
        }
      })
    },
    delFile: function(path) {
      let formData = new FormData()
      formData.append('path', path)

      this.axios({
        method: 'post',
        url: this.boomerServer + '/scripts/del',
        data: formData,
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }).then(res => {
        this.refreshFileTree()
        this.editDialog = false
        this.deleteDialog = false
        this.notify('success', '删除成功')
      })
    },
    renameFile: function(file) {
      let formData = new FormData()
      let dirs = file.path.split('/')
      if (file.dir) {
        dirs.pop()
      }
      dirs.pop()
      dirs.push(file.name)
      if (file.dir) {
        dirs.push('')
      }
      const newPath = dirs.join('/')
      formData.append('oldPath', file.path)
      formData.append('newPath', newPath)

      this.axios({
        method: 'post',
        url: this.boomerServer + '/scripts/rename',
        data: formData,
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }).then(res => {
        if (res.data.status === 0) {
          this.editDialog = false
          this.notify('success', '重命名成功')
        } else {
          this.notify('error', '重命名失败')
        }
        this.refreshFileTree()
      })
    },
    addFile: function(parentPath, isDir) {
      const newFilePath = parentPath + this.newFileName + (isDir ? '/' : '')
      const localFile = this.findLocalFile(newFilePath)

      if (localFile) {
        this.notify('error', '存在同名文件')
        return
      }
      let formData = new FormData()
      const content = isDir ? undefined : '\n'

      formData.append('path', newFilePath)
      formData.append('content', content)

      this.axios({
        method: 'post',
        url: this.boomerServer + '/scripts/add',
        data: formData,
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }).then(res => {
        this.refreshFileTree()
        this.addDialog = false
        this.notify('success', '添加成功')
      })
    },
    findLocalFile: function(filePath) {
      function iter(iterItem, filePath) {
        for (let i = 0; i < iterItem.length; i++) {
          const item = iterItem[i]
          if (item.path === filePath) {
            return item
          } else if (item.dir && filePath.includes(item.path)) {
            if (item.children && item.children.length > 0) {
              return iter(item.children, filePath)
            }
          }
        }
      }
      return iter(this.scriptFiles, filePath)
    },
    handleFileItem: function(items, parentName) {
      if (items == null) {
        return
      }
      let toRemove = []
      for (let i = 0; i < items.length; i++) {
        let item = items[i]
        if (item['path'].indexOf('/') === -1 && item['children'] == null) {
          toRemove.push(i)
        }
        if (item['name'] === parentName && item['children'] == null) {
          toRemove.push(i)
        }
        if (item['children'] == null) {
          delete item['children']
        } else {
          // 先把自动打开去掉 避免操作其它组的数据
          // this.openDir.push(item['path'])
          this.handleFileItem(item['children'], item['name'])
        }
      }
      for (let i = 0; i < toRemove.length; i++) {
        items.splice(toRemove[i], 1)
      }
    },
    refreshFileTree: function() {
      let formData = new FormData()
      formData.append('path', this.projectPath + '/')

      this.axios({
        method: 'post',
        url: this.boomerServer + '/scripts/list_all',
        data: formData,
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }).then(res => {
        if (res.status === 200 && res.data.status === 0) {
          this.scriptFiles = res.data.data
          this.handleFileItem(this.scriptFiles, this.projectPath)
        }
      })
    },
    editContent: function(content) {
      if (this.currentFile) {
        if (this.currentFile.content !== undefined) {
          this.currentFile.content = content
        }
      }
    },
    runCode: function() {
      //  永远是执行编辑框里面的数据
      let formData = new FormData()
      formData.append('clientId', this.currentDeviceId)
      // formData.append('clientId', '30.103.91.240:53703')
      const code = this.currentFile ? this.currentFile.content : ''
      formData.append('content', code)
      formData.append('param', '')
      this.runCodeLoading = true

      this.axios({
        method: 'post',
        url: this.boomerServer + '/scripts/run_code',
        data: formData,
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })
        .then(res => {
          if (res.data.status === 0) {
            this.notify('success', '运行成功 ' + (res.data.data.result || ''))
          } else {
            this.notify('error', '运行失败 ' + (res.data.msg || ''))
          }
        })
        .finally(() => {
          this.runCodeLoading = false
        })
    },
    batchRunCode() {
      let formData = new FormData()
      const deviceIdList = this.$refs.mutilDeviceSelector.selected ? this.$refs.mutilDeviceSelector.selected.map(item => item.address) : []
      formData.append('clientIdList', deviceIdList)
      formData.append('content', this.onScreenCode)
      formData.append('param', '')
      this.axios({
        method: 'post',
        url: this.boomerServer + '/scripts/batch_run_code',
        data: formData,
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }).then(res => {
        //  TODO
      })
    }
  },
  mounted: function() {
    this.refreshFileTree()
    this.activeTab = 'editor'
  }
}
</script>

<style>
.editor {
  width: 100%;
  height: calc(75vh);
}
</style>

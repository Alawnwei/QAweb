<template>
  <div>
    <v-navigation-drawer
      absolute
      right
      v-model="value"
    >
      <v-list>
        <v-list-item class="px-2">
          <v-list-item-avatar>
            <v-icon>mdi-function-variant</v-icon>
          </v-list-item-avatar>
          <v-list-item-content>
            <v-list-item-title class="title">指令列表</v-list-item-title>
          </v-list-item-content>
          <v-icon @click="close">mdi-close-circle </v-icon>
        </v-list-item>
      </v-list>
      <v-divider></v-divider>
      <v-container>
        <v-row rows="12">
          <v-col cols="6" v-for="action in actions" :key="action.id">
            <v-btn v-text="action.name" @click="editAction(action)"/>
          </v-col>
        </v-row>
      </v-container>

      <template v-slot:append>
        <div class="pa-4">
          <v-btn
            color="primary"
            block
            @click="editAction()"
          >
            +
          </v-btn>
        </div>
        <div class="pb-10" />
      </template>
    </v-navigation-drawer>
    <v-dialog v-model="dialog" @keydown.esc="dialog = false" persistent max-width="800px">
      <v-card>
        <v-card-title v-text="dialogTitle"></v-card-title>
        <v-card-text>
          <v-container>
            <v-row>
              <v-text-field label="Action Name" v-model="currentAction.name"/>
            </v-row>
            <v-row>
              <MonacoEditor
                ref="actionEditor"
                v-model="currentAction.content"
                theme="vs-dark"
                class="editor"
                @editorDidMount="resize"
                language="lua"
              />
            </v-row>
          </v-container>
        </v-card-text>
        <v-card-actions>
          <v-btn :disabled="currentAction.id===undefined" color="red darken-1" text @click="delAction">Delete</v-btn>
          <v-btn color="blue darken-1" text @click="dialog = false">Close</v-btn>
          <v-btn color="blue darken-1" text @click="saveAction">Save</v-btn>
          <v-spacer />
          <v-btn class="primary" @click="executeAction">Send</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </div>
</template>

<script>
import MonacoEditor from 'vue-monaco'

export default {
  name: 'ActionSidebar',
  components: { MonacoEditor },
  props: ['value'],
  data: function () {
    // TODO 编辑器 dirty 判定
    return {
      dialog: false,
      pinned: true,
      currentAction: {},
      actionContent: '',
      editor: undefined,
      actions: [
        {
          id: 0,
          name: '登录',
          content: '123456789'
        },
        {
          id: 1,
          name: '移动',
          content: '123456789'
        },
        {
          id: 2,
          name: '下线',
          content: '123456789'
        },
        {
          id: 3,
          name: '获取协议',
          content: '123456789'
        },
        {
          id: 4,
          name: '获取特定协议',
          content: '123456789'
        }
      ]
    }
  },
  methods: {
    close() {
      this.$emit('close')
    },
    resize() {
      if (!this.editor) {
        this.editor = this.$refs.actionEditor.getEditor()
      }

      const that = this
      setTimeout(function () {
        that.editor.layout()
      }, 50)
    },
    editAction(action) {
      const tmp = {
        func: 123,
        params: {
          params1: 990,
          params2: '456456'
        }
      }

      // this.currentAction = action || { content: '{\n  "func":"",\n  "params":{\n    "param1":"",\n    "param2":""\n  }\n}' }
      this.currentAction = action || { content: JSON.stringify(tmp) }
      console.log(this.currentAction.id)
      this.dialog = true

      // monaca editor 如果动态创建需要手动 layout 一次
      // 但在dialog 未创建时, 无法拿到 actionEditor, 所以只能以延时形式去操作
      // ugly but WORKS
    },
    // TODO currentAction 传递
    saveAction() {
      this.dialog = false
      this.$emit('editAction', this.currentAction)
    },
    delAction() {
      this.dialog = false
      this.$emit('delAction', this.currentAction)
    },
    executeAction() {
      this.$emit('executeAction', this.currentAction)
    }
  },
  computed: {
    dialogTitle: function () {
      if (this.currentAction.id) {
        return '编辑 Action'
      } else {
        return '添加 Action'
      }
    }
  },
  mounted() {
  }
}
</script>

<style scoped>
.editor {
  width: 100%;
  height: 400px;
}
</style>

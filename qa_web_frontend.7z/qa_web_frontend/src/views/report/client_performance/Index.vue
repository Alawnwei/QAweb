<template lang="pug">
  div
    router-view
</template>

const getPeriod = function(startTime, endTime) {
  const start = new Date(startTime)
  const end = new Date(endTime)
  const result = end - start
  return (result / 1000).toFixed(1)
}

const getDeviceInfo = function(deviceInfoStr) {
  if (deviceInfoStr) {
    return JSON.parse(deviceInfoStr)
  }
  return {
    platform: 'Others',
    cpu: 'N/A',
    ram: 'N/A',
    mac_address: 'N/A'
  }
}

// [[{names, counts}, , ...], ...]
const getUnion = function(markAreaDataList) {
  const result = { names: [], counts: [] }
  if (markAreaDataList.length === 0) return result
  if (markAreaDataList.length === 1) return makeTagList(markAreaDataList[0])
  const size = markAreaDataList.length
  const pointer = new Array(size).fill(0)
  function isEnd(pointer, dataList) {
    for (let i = 0; i < size; i++) {
      if (pointer[i] !== dataList[i].names.length) {
        return false
      }
    }
    return true
  }
  while (!isEnd(pointer, markAreaDataList)) {
    for (let i = 0; i < size; i++) {
      const compareList = []
      const movePointer = [i]
      let isHeadTag = false
      const currentName = markAreaDataList[i].names[pointer[i]]
      if (currentName === undefined) continue
      compareList.push(markAreaDataList[i].counts[pointer[i]])
      for (let j = 0; j < size; j++) {
        if (i === j) continue
        if (
          markAreaDataList[j].names.indexOf(currentName) > pointer[j] ||
          result.names.includes(currentName)
        ) {
          isHeadTag = false
          break
        } else if (
          markAreaDataList[j].names.indexOf(currentName) === pointer[j]
        ) {
          compareList.push(markAreaDataList[j].counts[pointer[j]])
          movePointer.push(j)
        }
        isHeadTag = true
      }
      if (isHeadTag) {
        result.names.push(currentName)
        result.counts.push(Math.max(...compareList))
        movePointer.map(index => {
          pointer[index] += 1
        })
      }
    }
  }
  return makeTagList(result)
}

// tagUnion {names:[], counts:[]}
const makeTagList = function(tagUnion) {
  let result = []
  for (let i = 0; i < tagUnion.names.length; i++) {
    const data = new Array(tagUnion.counts[i]).fill(tagUnion.names[i])
    result = result.concat(data)
  }
  return result
}

const shiftData = function(data, dataTag, unionTag) {
  if (
    dataTag == null ||
    dataTag.length === 0 ||
    unionTag == null ||
    unionTag.length === 0
  ) {
    return data
  }
  const result = []
  let count = 0

  for (let i = 0; i < unionTag.length; i++) {
    if (count >= data.length) {
      result.push(undefined)
    }
    if (unionTag[i] === dataTag[count]) {
      result.push(data[count])
      count++
    } else {
      result.push(undefined)
    }
  }
  return result
}

const getTagRange = function(tagList) {
  const tagRange = {}
  let lastTag
  for (let i = 0; i < tagList.length; i++) {
    const tag = tagList[i]
    if (tag != null && !Object.keys(tagRange).includes(tag)) {
      tagRange[tag] = { start: i }
    }
    if (lastTag && i > 0) {
      tagRange[lastTag]['end'] = i - 1
    }
    if (tag != null && lastTag === tag && i === tagList.length - 1) {
      tagRange[lastTag]['end'] = i
    }
    lastTag = tag
  }
  return tagRange
}

const getTagStats = function(tagList) {
  const tagRange = getTagRange(tagList)

  const data = { names: [], counts: [] }
  Object.keys(tagRange).map(key => {
    data.names.push(key)
    data.counts.push(tagRange[key].end - tagRange[key].start + 1)
  })
  return data
}

// 从[tagA, tagA, tagB...] 中获取符合 echarts 格式要求的markArea
const getMarkArea = function(tagList) {
  const tagRange = getTagRange(tagList)
  const result = []

  Object.keys(tagRange).map(key => {
    const area = []
    area.push({ name: key, xAxis: tagRange[key].start })
    area.push({ xAxis: tagRange[key].end })
    result.push(area)
  })
  return result
}

export {
  getPeriod,
  getDeviceInfo,
  getUnion,
  shiftData,
  getTagStats,
  getMarkArea
}

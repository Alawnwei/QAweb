<template lang="pug">
  line-chart
</template>

<script>
import LineChart from './LineChart'

export default {
  components: {
    'line-chart': LineChart
  }
}
</script>

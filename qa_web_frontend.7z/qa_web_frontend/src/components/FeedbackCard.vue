<template lang="pug">
  v-card(height="350px", outlined, :class="{ 'active-card': isActive }", @click="onClickCard")
    div.card-content.pb-3
      v-card-text.pb-0
        fc-status(:status="cardStatus")
        div.d-block
          span.h4
            strong # {{ issue_id }}
            v-tooltip(top)
              template(v-slot:activator="{ on }")
                v-btn.my-0.px-0.ml-1.type-btn(small, text, depressed, outlined, :color="typeTextColor", v-on="on", @click="onClickToggleType") {{ typeText }}
              span 点击切换
          p.mt-2.subtitle
              strong.blue--text {{ this.assigned_by || '-'}}
              | &nbsp; 指派给 &nbsp;
              strong.blue--text {{ this.assigned_to || '-'}}
          p.subtitle
            | &nbsp;&nbsp;
            strong.blue--text {{ this.comments.length || '0'}}
            | &nbsp; 条评论 &nbsp;
      v-card-text
        v-autocomplete(label="指派给",
                v-if="assignTo.display",
                hint="搜索"
                dense, autofocus, :items="assignedToUserList", item-text="first_name",
                item-value="username", v-model="assignTo.value",
                @change="onChangeAssignTo"
                @blur="onBlurAssignTo")
        strong.d-block.card-content {{ content }}
        v-file-input(label="可多选, ctrl + enter 提交", contenteditable="true", accept="image/*", show-size, filled, dense, small-chips, multiple
                      @keyup.ctrl.enter="onSubmitUploadImage", v-model="uploadImageForm.images"
                      prepend-icon="mdi-file-image", v-if="uploadImageForm.display", @blur="onBlurUploadImageForm", autofocus)
        v-carousel.mt-2(height="150px", hide-delimiters, :show-arrows="has_more_than_one_image()", v-if="has_image()")
          v-carousel-item(v-for="(item, i) in image_urls", :key="i", :src="item.url")
            template
              v-tooltip(top)
                template(v-slot:activator="{ on }")
                  v-btn.mx-0.zoom-in(icon, @click="onClickZoomIn(item)", v-on="on")
                    v-icon(color="white") zoom_in
                span 放大
        v-card.my-2(outlined, flat, v-for="(comment, i) in comments" :key="i")
          v-card-text
            div
              span.subtitle
              strong.blue--text {{ comment.created_by }}
              | &nbsp;评论于&nbsp;
              strong.blue--text {{ timeago_format(comment.created_at) }}
          v-card-text.py-2
            div.card-content {{ comment.content }}

        v-card.my-2(flat, outlined, v-if="newComment.display")
          v-card-text
            h4 新增评论：
          v-card-text.py-2
            v-textarea(auto-grow, autofocus, outlined, filled, ref="newCommentTextarea", hint="Ctrl + Enter 提交", v-model="newComment.content", @blur="onBlurNewCommentTextarea", @keyup.ctrl.enter="onSubmitNewComment")
      v-card-text
        div.d-block
          div.my-2
          p.subtitle
            span.blue--text {{ this.created_by || '' }}
            | &nbsp; 创建于 &nbsp;
            span.blue--text {{ this.timeago_format(this.created_at) }}
          p.subtitle
            span.blue--text {{ this.updated_by || '' }}
            | &nbsp; 更新于 &nbsp;
            span.blue--text {{ this.timeago_format(this.updated_at) }}
    div.card-actions
      v-card-actions.actions
        v-tooltip(top)
          template(v-slot:activator="{ on }")
            v-btn.mx-0(text, icon, small, @click="onClickUploadImage", v-on="on")
              v-icon(color="primary") mdi-file-image
          span 上传截图
        v-tooltip(top)
          template(v-slot:activator="{ on }")
            v-btn.mx-0(text, icon, small, @click="onClickAssignTo", v-on="on")
              v-icon(color="primary") assignment_ind
          span 指派给
        v-tooltip(top)
          template(v-slot:activator="{ on }")
            v-btn.mx-0(text, icon, small, @click="onClickCreateComment", v-on="on")
              v-icon(color="primary") add_comment
          span 评论
        //- v-tooltip(top)
        //-   template(v-slot:activator="{ on }")
        //-     v-btn.mx-0(text, icon, small, @click="onClickCreateIssue", v-if="status!=4", v-on="on")
        //-       v-icon(color="primary") bug_report
        //-   span 创建bug单
        v-tooltip(top, v-if="status!=2")
          template(v-slot:activator="{ on }")
            v-btn.mx-0(text, icon, small, @click="onClickSuspend", v-on="on")
              v-icon(color="primary") hourglass_empty
          span 挂起
        v-tooltip(top, v-if="status!=6")
          template(v-slot:activator="{ on }")
            v-btn.mx-0(text, icon, small, @click="onClose", v-on="on")
              v-icon(color="primary") close
          span 关闭（已提单）
</template>

<script>
import { format } from 'timeago.js'
import _ from 'lodash'

export default {
  data: () => {
    return {
      image_urls: [],
      comments: [],
      created_by: null,
      created_at: null,
      updated_by: null,
      updated_at: null,
      assigned_to: null,
      assigned_by: null,
      closeStatus: false,
      type: null,
      newComment: {
        display: false,
        content: ''
      },
      assignTo: {
        display: false,
        value: ''
      },
      uploadImageForm: {
        display: false,
        images: []
      }
    }
  },
  props: [
    'issue_id',
    'title',
    'content',
    'assignedToUserList',
    'status',
    'selected',
    'changed'
  ],
  components: {
    'fc-status': () => import('@/components/FeedbackCardStatus.vue')
  },
  watch: {
    issue_id: function() {
      this.update_issue_info()
    },
    changed: function() {
      this.update_issue_info()
    }
  },
  created: function() {
    this.onClickToggleType = _.debounce(this.onClickToggleTypeProto, 1000)
    this.onClickSuspend = _.debounce(this.onClickSuspendProto, 1000)
  },
  computed: {
    typeText: function() {
      if (this.type === 1) {
        return '建议'
      } else if (this.type === 2) {
        return 'BUG'
      } else {
        return '未知'
      }
    },
    typeTextColor: function() {
      if (this.type === 1) {
        return 'primary'
      } else if (this.type === 2) {
        return 'error'
      } else {
        return 'warning'
      }
    },
    isActive: function() {
      return this.selected
    },
    cardStatus: function() {
      return this.status
    }
  },
  methods: {
    update_issue_info: function() {
      this.axios
        .get('/feedback/api/get_issue_info_by_issue_id/', {
          params: {
            issue_id: this.issue_id
          }
        })
        .then(res => {
          this.image_urls = res.data.data.image_urls
          this.comments = res.data.data.comments
          this.created_at = res.data.data.created_at
          this.created_by = res.data.data.created_by
          this.updated_at = res.data.data.updated_at
          this.updated_by = res.data.data.updated_by
          this.assigned_to = res.data.data.assigned_to
          this.assigned_by = res.data.data.assigned_by
          this.type = res.data.data.type
          this.newComment = {
            display: false,
            content: ''
          }
          this.assignTo.display = false
          this.assignTo.value = res.data.data.assigned_to_mail
        })
    },
    onClose: function(event, target) {
      this.axios
        .post('/feedback/api/close_issue/', {
          issue_id: this.issue_id
        })
        .then(res => {
          this.$emit('update-list')
        })
    },
    onClickCreateIssue: function() {
      this.$emit('show-create-issue-dialog', {
        issue_id: this.issue_id,
        title: '【feedback自动提单】' + this.content.trim(), // 现在没有title，暂时先填content进去
        content:
          this.content.trim() +
          this.image_urls.map(obj => '<img src="' + obj.url + '" />').join('')
      })
    },
    onClickCreateComment: function() {
      this.newComment.display = !this.newComment.display
    },
    onSubmitNewComment: function(e) {
      let content = this.newComment.content
      this.axios
        .post('/feedback/api/create_new_comment/', {
          issue_id: this.issue_id,
          content: content
        })
        .then(res => {
          this.update_issue_info()
        })
    },
    onBlurNewCommentTextarea: function() {
      this.newComment.display = false
    },
    onClickAssignTo: function() {
      this.assignTo.display = !this.assignTo.display
    },
    onChangeAssignTo: function() {
      this.axios
        .post('/feedback/api/assign_issue_to_user/', {
          issue_id: this.issue_id,
          username: this.assignTo.value
        })
        .then(res => {
          this.update_issue_info()
          this.assignTo.display = false
        })
    },
    onBlurAssignTo: function() {
      this.assignTo.display = false
    },
    onClickToggleTypeProto: function() {
      let toType = 1
      if (this.type === 1) {
        toType = 2
      } else if (this.type === 2) {
        toType = 1
      }

      this.axios
        .post('/feedback/api/set_issue_type/', {
          issue_id: this.issue_id,
          type: toType
        })
        .then(res => {
          this.update_issue_info()
        })
    },
    onClickSuspendProto: function() {
      this.axios
        .post('/feedback/api/suspend_issue/', {
          issue_id: this.issue_id
        })
        .then(res => {
          this.$emit('update-list')
        })
    },
    onClickUploadImage: function() {
      this.uploadImageForm.display = !this.uploadImageForm.display
    },
    onBlurUploadImageForm: function() {
      // this.uploadImageForm.display = false # 目前选文件时会触发 blur 事件，暂时先注掉
    },
    onSubmitUploadImage: function() {
      let images = this.uploadImageForm.images
      let headers = {
        'Content-Type': 'multipart/form-data;charset=UTF-8'
      }
      let formData = new FormData()
      formData.append('issue_id', this.issue_id)
      images.forEach(element => {
        formData.append('images[]', element)
      })
      this.axios
        .post('/feedback/api/append_images_to_issue/', formData, {
          headers: headers
        })
        .then(res => {
          this.uploadImageForm.images = []
          this.uploadImageForm.display = false
          this.update_issue_info()
        })
    },
    onClickZoomIn: function(item) {
      this.$emit('on-click-zoom-in', {
        url: item.url
      })
    },
    onClickCard: function() {
      this.$emit('on-select-card', {
        issueId: this.issue_id
      })
    },
    has_image: function() {
      return this.image_urls.length > 0
    },
    has_more_than_one_image: function() {
      return this.image_urls.length > 1
    },
    timeago_format: function(datetime) {
      return format(datetime, 'zh_CN')
    }
  },
  mounted: function() {
    this.update_issue_info()
  }
}
</script>
<style lang="sass" scoped>
.actions
  position: absolute
  bottom: 0em
  right: 0em
.card-content
  max-height: 340px
  overflow-y: auto
.card-content::-webkit-scrollbar
  width: 0 !important
p.subtitle
  font-size: .5em
  font-weight: 400
  color: grey
  margin: 0 0
h4
  padding: 10px 0
.card-title
  position: relative
.card-content
  width: 100%
.v-btn.type-btn
  min-width: 40px
  min-height: 0px
  height: 20px
  padding: 0
  margin: 0
.zoom-in
  position: absolute
  right: .5em
.active-card
  border: 1px solid green !important
</style>

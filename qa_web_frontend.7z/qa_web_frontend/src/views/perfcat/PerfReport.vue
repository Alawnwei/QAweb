<template>
  <v-app id="inspire">
    <v-container fluid>
      <v-select v-model="curLocations" :items="allLocations" multiple label="请选择采样坐标"></v-select>
      <v-btn-toggle v-model="curMetrics" mandatory>
        <span v-for="(item, index) in metricsList" :key="index">
          <v-btn :value="item">{{ item }}</v-btn>
        </span>
      </v-btn-toggle>
      <ve-line :data="curChartData"></ve-line>
      <!--<ve-histogram :data="curChartData"></ve-histogram> -->
    </v-container>
  </v-app>
</template>

<script>
import VeLine from 'v-charts/lib/line'

export default {
  components: {
    VeLine
  },
  data: () => {
    return {
      curLocations: [],
      allLocations: [],
      locationsMap: {},
      curMetrics: '',
      metricsList: [],
      chartData: {},
      curChartData: {}
    }
  },
  watch: {
    curMetrics: function(val) {
      this.onChangeMetric(val)
    },
    curLocations: function(val) {
      var locations = {}
      var count = 0
      for (var i = 0; i < val.length; i++) {
        locations[val[i]] = this.locationsMap[val[i]]
        count++
      }
      if (count > 0) {
        this.getLocationResult(locations)
      }
    }
  },
  mounted: function() {
    this.getLocations()
  },
  props: {},
  methods: {
    changeMetric: function() {
      // 前端动态 更换metics
      this.curChartData = {}
      this.curChartData['columns'] = this.chartData.columns
      this.curChartData['rows'] = []
      for (var i = 0; i < this.chartData.rows.length; i++) {
        var row = this.chartData.rows[i]
        var copy = {}
        this.curChartData.rows.push(copy)
        for (var key in row) {
          var val = row[key]
          if (val instanceof Map || val instanceof Object) {
            // 取当前的维度
            copy[key] = val[this.curMetrics]
          } else {
            copy[key] = val
          }
        }
      }
      // alert(JSON.stringify(this.curChartData))
    },
    onChangeMetric: function(metric) {
      // alert(metric)
      this.curMetrics = metric
      this.changeMetric()
    },
    getLocations: function() {
      this.axios.get('perfcat/locations/', {}).then(res => {
        if (res.status === 200) {
          var locationData = res.data
          var ls = []
          this.locationsMap = {}
          for (var i = 0; i < locationData.length; i++) {
            var item = locationData[i]
            var val = { text: item['desc'], value: item['id'] }
            ls.push(val)
            this.locationsMap[val['value']] = val['text']
          }
          this.allLocations = ls
        }
      })
    },
    getLocationResult: function(locations) {
      this.axios
        .post('/perfcat/location_test_results/charData/', {
          locations: locations
        })
        .then(res => {
          if (res.data.success) {
            // debugger
            this.chartData = res.data.perfData.chartData
            // alert(JSON.stringify(this.chartData))
            this.metricsList = res.data.perfData.metrics
            // 默认先取第一个维度
            this.curMetrics = this.metricsList[0]
            this.changeMetric()
          }
        })
    }
  }
}
</script>

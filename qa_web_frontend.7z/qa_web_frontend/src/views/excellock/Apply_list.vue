<template lang='pug'>
div
  v-content
    v-container(fluid)
      div(style="margin:15px auto")
        v-expansion-panels(multiple=true, v-model="top_panel",focusable)
          v-expansion-panel
            v-expansion-panel-header(color="green") 申请列表
            v-expansion-panel-content
              v-col(cols="12", v-if="apply_id_list.length === 0", style="text-align:center") 没有数据
              v-expansion-panels(multiple=true, v-model="panel", focusable,v-if="apply_id_list != []")
                v-expansion-panel(style="margin:15px",v-for="item in apply_id_list", :key="item" v-if="item.apply_status ===1 ")
                  apply-Panel(title="申请列表", :applyId="item", @apply_alert="apply_alert_func")
      div
        v-alert.my-0(color="blue") 审批列表
        apply-Table(title="申请列表", @apply_alert="apply_alert_func")
    v-snackbar(v-model="apply_alert",top=true,left=true,:timeout="timeout",:color="alert_color",multi-line=true)
      span {{alert_text}}
      v-btn(dark,text,@click='apply_alert = false') close
</template>

<script>
import store from '@/store'

export default {
  data: () => ({
    panel: [],
    top_panel: [0],
    apply_id_list: [],
    apply_alert: false,
    alert_text: '',
    alert_color: 'info',
    timeout: 3000
  }),
  computed: {
    user: () => store.getters.user
  },
  created: function() {
    this.get_apply_list()
    console.log('"111111111111111111111111111111"')
  },
  props: {
    source: String
  },
  methods: {
    get_apply_list: function() {
      let param = { job_number: this.user.username }
      this.axios
        .get('/get_apply_list', {
          params: param
        })
        .then(res => {
          this.apply_id_list = res.data
          console.log(res.data)
        })
    },
    apply_alert_func: function(msg) {
      this.apply_alert = true
      this.alert_color = msg.color
      this.alert_text = msg.text
    }
  },
  components: {
    'apply-Panel': () => import('@/components/ApplyPanel.vue'),
    'apply-Table': () => import('@/components/ApplyTable.vue')
  }
}
</script>

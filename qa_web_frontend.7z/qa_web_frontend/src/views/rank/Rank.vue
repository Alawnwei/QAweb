<template lang='pug'>
div
  v-tabs(v-model='tabsActive' dark='' slider-color='yellow')
    router-link.tab-link(v-for='m in monthList' :key='m' :to='m')
      v-tab(ripple='')
        | {{ m }}
  v-card(raised='')
    v-card-title
      h3 &#x6392;&#x884C;&#x699C; &#xFF08;&#x6700;&#x540E;&#x66F4;&#x65B0;&#x4E8E; {{ update_time }}&#xFF09;
      v-btn(dark='' @click='dialog = true')  &#x67E5;&#x770B;&#x5F53;&#x6708;&#x8981;&#x6C42;
      v-spacer
      v-text-field(v-model='search' append-icon='search' label='搜索（支持按姓名或职能过滤）' single-line='' hide-details='')
    v-data-table.elevation-1.text-xs-center(:headers='headers' :items='lines' :search='search' hide-actions='' :loading='loading' item-key='name' v-bind:pagination.sync='pagination')
      v-progress-linear(#progress color='blue' indeterminate='')
      template(#items='props')
        tr(@click='getDetails(props)')
          td {{ props.index + 1 }}
          td {{ props.item.name }}
          td.cyan.lighten-4(v-if="props.item.position === '策划'")
            | {{ props.item.position }}
          td.lime.lighten-4(v-else-if="props.item.position === 'QA'")
            | {{ props.item.position }}
          td.brown.lighten-4(v-else-if="props.item.position === '程序'")
            | {{ props.item.position }}
          td.green.lighten-4(v-else='') {{ props.item.position }}
          td.orange.darken-4(v-if="getParagraphColor(props) === '优秀'")
            strong {{ props.item.paragraph }}
          td.amber.accent-2(v-else-if="getParagraphColor(props) === '良好'")
            strong {{ props.item.paragraph }}
          td.teal.accent-1(v-else-if="getParagraphColor(props) === '及格'")
            strong {{ props.item.paragraph }}
          td.blue-grey.lighten-3(v-else='')
            strong {{ props.item.paragraph }}
          td.orange.darken-4(v-if="getParagraphColor(props) === '优秀'")
            | {{ props.item.level_zh }}
          td.amber.accent-2(v-else-if="getParagraphColor(props) === '良好'")
            | {{ props.item.level_zh }}
          td.teal.accent-1(v-else-if="getParagraphColor(props) === '及格'")
            | {{ props.item.level_zh }}
          td.blue-grey.lighten-3(v-else='')
            | {{ props.item.level_zh }}
          td.orange.darken-4(v-if="getScoreColor(props) === '优秀'")
            strong {{ props.item.addition_weight }}
          td.amber.accent-2(v-else-if="getScoreColor(props) === '良好'")
            strong {{ props.item.addition_weight }}
          td.teal.accent-1(v-else-if="getScoreColor(props) === '及格'")
            strong {{ props.item.addition_weight }}
          td.blue-grey.lighten-3(v-else='')
            strong {{ props.item.addition_weight }}
      template(#expand='props')
        v-container(fluid='' grid-list-md='')
          v-data-iterator(:items='getValues(props)' content-tag='v-layout' row='' wrap='')
            v-toolbar.mb-2(#header color='indigo darken-5' dark='' flat='')
              v-toolbar-title &#x8D26;&#x53F7;&#x8BE6;&#x7EC6;&#x6570;&#x636E;
            template(#item='props')
              v-flex(xs12, sm6, md4, lg3)
                v-card
                  v-card-title
                    h4
                      |123 {{ getChineseValue(props.item, &apos;&#x4EBA;&#x5458;&apos;) }}
                  v-divider
                  v-list(dense='')
                    v-list-tile(v-for='(v, k) in props.item' :key='k')
                      v-list-tile-content {{ k }}
                      v-list-tile-content.align-end
                        | {{ v }}
  v-dialog(v-model='dialog' max-width='840')
    v-card
      v-card-title.headline &#x5F53;&#x6708;&#x8981;&#x6C42;
      v-img(:src="require('@/assets/rank_requirement.png')")
      v-card-actions
        v-spacer
        v-btn(color='green darken-1' text @click='dialog = false')
          | &#x5173;&#x95ED;
</template>
<script>
import _ from 'lodash'

export default {
  props: ['month'],
  data: () => {
    return {
      tabsActive: null,
      currentMonth: null,
      pagination: {
        descending: true,
        rowsPerPage: -1,
        sortBy: 'addition_weight'
      },
      search: '',
      loading: false,
      update_time: '',
      dialog: false,
      monthList: null,
      headers: [
        {
          text: '排序',
          sortable: false,
          align: 'center',
          width: '1em'
        },
        {
          text: '姓名',
          sortable: false,
          value: 'name',
          align: 'center'
        },
        { text: '职能', value: 'position', sortable: false, align: 'center' },
        { text: '最高段位分', value: 'paragraph', align: 'center' },
        { text: '最高段位', value: 'level', sortable: false, align: 'center' },
        { text: '权值', value: 'addition_weight', align: 'center' }
      ],
      lines: []
    }
  },
  methods: {
    getDetails: function(props) {
      if (props.expanded) {
        props.expanded = false
        return
      }

      if (props.item.details !== undefined) {
        props.expanded = true
      } else {
        this.loading = true
        let url =
          '/rank/api/monthly_detail?name=' +
          props.item.name +
          '&month=' +
          this.month
        this.axios.get(url).then(res => {
          props.item.details = res.data
          props.expanded = true
          this.loading = false
        })
      }
    },
    getValues: function(props) {
      return _.values(props.item.details.ids)
    },
    getChineseValue: function(item, key) {
      return item[key]
    },
    getClassByRole: function(props) {},
    getScoreColor: function(props) {
      var ScoreStandard = {
        策划: {
          优秀: 340,
          良好: 265,
          及格: 189
        },
        QA: {
          优秀: 255,
          良好: 198,
          及格: 142
        },
        程序: {
          优秀: 170,
          良好: 132,
          及格: 95
        },
        美术: {
          优秀: 170,
          良好: 132,
          及格: 95
        },
        UX: {
          优秀: 170,
          良好: 132,
          及格: 95
        },
        PM: {
          优秀: 170,
          良好: 132,
          及格: 95
        },
        营销: {
          优秀: 170,
          良好: 132,
          及格: 95
        }
      }
      for (var i in ScoreStandard[props.item.position]) {
        if (
          props.item.addition_weight >= ScoreStandard[props.item.position][i]
        ) {
          return i
        }
      }
      return '不及格'
    },
    getParagraphColor: function(props) {
      var ParagraphStandard = {
        '2018_10': {
          策划: {
            优秀: 9000,
            良好: 6750,
            及格: 2150
          },
          QA: {
            优秀: 9000,
            良好: 6750,
            及格: 2150
          },
          程序: {
            优秀: 9000,
            良好: 6750,
            及格: 2150
          },
          美术: {
            优秀: 9000,
            良好: 6750,
            及格: 2150
          },
          PM: {
            优秀: 9000,
            良好: 6750,
            及格: 3350
          },
          UX: {
            优秀: 9000,
            良好: 6750,
            及格: 2150
          }
        },
        '2018_11': {
          策划: {
            优秀: 9000,
            良好: 6750,
            及格: 6350
          },
          QA: {
            优秀: 9000,
            良好: 6750,
            及格: 4400
          },
          程序: {
            优秀: 9000,
            良好: 6750,
            及格: 3350
          },
          美术: {
            优秀: 9000,
            良好: 6750,
            及格: 3350
          },
          PM: {
            优秀: 9000,
            良好: 6750,
            及格: 3350
          },
          UX: {
            优秀: 9000,
            良好: 6750,
            及格: 3350
          }
        }
      }
      var iMonth = ''
      if (this.month === '2018_10') {
        iMonth = '2018_10'
      } else {
        iMonth = '2018_11'
      }
      for (var i in ParagraphStandard[iMonth][props.item.position]) {
        if (
          props.item.paragraph >=
          ParagraphStandard[iMonth][props.item.position][i]
        ) {
          return i
        }
      }
      return '不及格'
    },
    updateData: function() {
      this.loading = true
      this.axios
        .get('rank/api/months')
        .then(res => {
          this.monthList = res.data
          for (let i = 0; i < this.monthList.length; i++) {
            if (this.monthList[i] === this.month) {
              this.tabsActive = i
              return this.axios.get('/rank/api/monthly/' + this.month)
            }
          }
          return Promise.reject(Error(this.monthList[0]))
        })
        .then(
          res => {
            this.lines = res.data.data
            this.update_time = res.data.update_time
            this.loading = false
          },
          err => {
            window.location.href = err.message
          }
        )
    }
  },
  mounted: function() {
    this.updateData()
  },
  watch: {
    month: function(_) {
      this.updateData()
    }
  }
}
</script>

<style>
a.tab-link {
  color: white;
  text-decoration: none;
}
a.tab-link > div {
  height: 100%;
}
</style>

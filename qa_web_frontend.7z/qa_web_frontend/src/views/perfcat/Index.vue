<template lang="pug">
v-app
  div(data-app="true")
    v-app-bar(fixed, dark, app, clipped-left)
      v-toolbar-title M6 PerfCat
      v-spacer
      v-toolbar-items.hidden-sm-and-down
        v-btn(text) 欢迎你，{{ user.firstName }}
    v-content
      v-container(fluid='')
        v-row
          v-col(cols="12", sm="2")
            navigation
          v-col(cols="12", sm="10")
            a(href="http://sonic.ep.ucweb.local/plugin/perfcat/dynamic-report") perfcat已经迁移到质效平台，点击跳转进去，如遇到权限问题，请及时联系刘威(@威盗)

</template>

<script>
import store from '@/store'
import Navigation from './Navigation'

export default {
  data: () => ({}),
  computed: {
    user: () => store.getters.user
  },
  props: {},
  methods: {},
  components: {
    navigation: Navigation
  }
}
</script>

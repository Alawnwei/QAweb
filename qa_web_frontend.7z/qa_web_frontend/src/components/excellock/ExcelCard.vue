<template lang="pug">
  v-card(height="220px", outlined, border-color="red")
    div.card-content.pb-3
      v-card-text.pb-0
        v-chip.chip(small, flat, :color="typeTextColor") {{ typeText }}
        div.d-block
          span.h4
            strong {{ excel_data.excel_name }}
          p.mt-2.subtitle
              strong.blue--text {{ excel_data.excel_path }}
      v-card-text
        v-divider
        div.d-block
          div.my-2
          p.subtitle
            span(v-if="excel_data.lock_status === 0 ") 最近操作
            span(v-else) 占用用户
            span.blue--text {{ excel_data.lock_user?excel_data.lock_user.first_name:'无' }}
          p.subtitle
            span 操作时间
            span.blue--text {{ excel_data.lock_time?excel_data.lock_time:'--' }}
    div.card-actions
      v-card-actions.actions
        v-tooltip(top, v-if="excel_data.lock_status===0")
          template(v-slot:activator="{ on }")
            v-btn.mx-0(fab, color="primary", small, @click="onLock(1)", v-on="on", :loading="lock_loading")
              v-icon() lock_open
          span 占用
        v-tooltip(top v-if="excel_data.lock_status===1 && checked_user()")
          template(v-slot:activator="{ on }")
            v-btn.mx-0(fab, color="error", small, @click="onLock(0)", v-on="on", :loading="lock_loading")
              v-icon() lock
          span 释放
        v-tooltip(top v-if="excel_data.lock_status===1 && !checked_user()")
          template(v-slot:activator="{ on }")
            v-btn(
              fab,
              small,
              color="#3296fa",
              @click="sendDing(excel_data)",
              v-on="on"
            )
              span(class="dingding")
          span 钉钉提醒
</template>

<script>

import store from '@/store'

export default {
  data: () => {
    return {
      excel_data: '',
      excel_lock: false,
      excel_unlock: false,
      lock_log: '',
      lock_loading: false
    }
  },
  props: [
    'excelId'
  ],
  components: {
  },
  watch: {
    excelId: function() {
      this.get_excel_data()
    }
  },
  created: function() {
    this.get_excel_data()
  },
  computed: {
    user: () => store.getters.user,
    typeText: function() {
      if (this.excel_data.lock_status === 0) {
        return '未占用'
      } else {
        return '占用'
      }
    },
    typeTextColor: function() {
      if (this.excel_data.lock_status === 0) {
        return 'primary'
      } else {
        return 'error'
      }
    }
  },
  methods: {
    get_excel_data: function() {
      let url = '/excellock/excel/' + this.excelId + '/'
      this.axios
        .get(url, {})
        .then(res => {
          this.excel_data = res.data
        })
    },
    checked_user: function() {
      let lockUser = this.excel_data.lock_user
      if (lockUser) {
        if (this.user.username !== lockUser.job_number) {
          return false
        }
      }
      return true
    },
    onLock: function(status) {
      this.lock_loading = true
      if (status === 1) {
        this.excel_lock = false
      } else {
        this.excel_unlock = false
      }
      let myDate = new Date()
      let nowTime = this.time_format(myDate, 'yyyy-MM-ddThh:mm:ss')
      let url = '/excellock/excel/' + this.excelId + '/'
      this.axios
        .patch(url, {
          lock_status: status,
          lock_user_id: this.user.id,
          lock_time: nowTime
        })
        .then(res => {
          let msg = {
            color: 'info',
            text: '操作成功'
          }
          this.$emit('lock_alert', msg)
          this.$emit('update_locked_list')
          this.lock_loading = false
        })
    },
    sendDing: function(excel) {
      let url = '/excellock/excel/send_notice/'
      console.log(this.user)
      let params = {
        send_name: this.user.firstName,
        excel_path: excel.excel_path,
        job_number: excel.lock_user.job_number
      }
      this.axios
        .post(url, params)
        .then(res => {
          let msg = {
            color: 'info',
            text: '操作成功'
          }
          this.$emit('lock_alert', msg)
          this.$emit('update_locked_list')
        })
    },
    time_format: function(datatime, fmt) {
      let date = new Date(datatime)
      if (/(y+)/.test(fmt)) {
        fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length))
      }
      let o = {
        'M+': date.getMonth() + 1,
        'd+': date.getDate(),
        'h+': date.getHours(),
        'm+': date.getMinutes(),
        's+': date.getSeconds()
      }
      for (var k in o) {
        if (new RegExp('(' + k + ')').test(fmt)) {
          var str = o[k] + ''
          fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? str : ('00' + str).substr(str.length))
        }
      }
      return fmt
    }
  },
  mounted: function() {
  }
}
</script>
<style lang="sass" scoped>
.actions
  position: absolute
  bottom: 0em
  right: 0em
.card-content
  max-height: 340px
  overflow-y: auto
.card-content::-webkit-scrollbar
  width: 0 !important
p.subtitle
  font-size: .5em
  font-weight: 400
  color: grey
  margin: 0 0
h4
  padding: 10px 0
.card-title
  position: relative
.card-content
  width: 100%
.v-btn.type-btn
  min-width: 40px
  min-height: 0px
  height: 20px
  padding: 0
  margin: 0
.zoom-in
  position: absolute
  right: .5em
.active-card
  border: 1px solid green !important
.chip
  position: absolute
  right: .5em
  top: 1em

</style>

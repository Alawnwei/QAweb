<template>
  <div>
    <v-card>
      <v-card-title>
        静态资源检查
      </v-card-title>
      <v-subheader class="inCardElement">最近一次扫描结果</v-subheader>
      <v-divider />
      <v-row>
        <v-col cols="4" v-for="(item, index) in fakeData" :key="index">
          <v-dash-board-card
            style="margin-bottom: 24px"
            :title="item.title"
            :desc="item.desc"
            :additional="nowDate"
            :label-list="labelList"
            :value-list="item.valueList"
            :color="item.color"
          />
        </v-col>
      </v-row>
    </v-card>
    <v-card class="lowerCard">
      <v-card-title>
        总体趋势
      </v-card-title>
      <v-profile-chart :options="fakeOption" />
    </v-card>
    <v-expansion-panels class="lowerCard">
      <v-expansion-panel>
        <v-expansion-panel-header style="font-size: 1.25rem"
          >历史扫描</v-expansion-panel-header
        >
        <v-expansion-panel-content>
          <v-text-field
            v-model="search"
            append-icon="search"
            label="Search"
            single-line
            hide-details
          />
          <v-data-table :headers="headers" :items="jobList" :search="search">
            <template v-slot:item.action>
              <v-icon>edit</v-icon>
              &nbsp;
              <v-icon>mdi-open-in-new </v-icon>
            </template>
          </v-data-table>
        </v-expansion-panel-content>
      </v-expansion-panel>
    </v-expansion-panels>
  </div>
</template>

<script>
import DashBoardCard from './DashBoardCard'
import ProfileChart from '../../../components/ProfileChart'

export default {
  name: 'Report',
  components: {
    'v-dash-board-card': DashBoardCard,
    'v-profile-chart': ProfileChart
  },
  data: function() {
    return {
      editor: null,
      editorOptions: {
        theme: 'bubble',
        modules: {
          toolbar: [
            [{ size: [false, 'large', 'huge'] }],
            ['bold', 'strike', 'underline'],
            [{ list: 'ordered' }, { list: 'bullet' }],
            [
              { color: ['white', 'black', 'red', 'yellow'] },
              { background: ['white', 'black', 'red', 'yellow'] }
            ],
            ['clean']
          ]
        }
      },
      nowDate: new Date().toLocaleString('chinese', { hour12: false }),
      labelList: [
        1,
        2,
        3,
        4,
        5,
        6,
        7,
        8,
        9,
        10,
        11,
        12,
        13,
        14,
        15,
        16,
        17,
        18,
        19,
        20
      ],
      fakeData: [
        {
          title: '模型顶点超标报错: 15',
          desc:
            '共计超标58622顶点, 报错数量比上次降低20次, 比最近20次扫描均值降低176次, 请马上排查',
          valueList: [
            60,
            80,
            100,
            120,
            140,
            200,
            300,
            360,
            320,
            280,
            240,
            300,
            260,
            220,
            260,
            240,
            200,
            320,
            400,
            320
          ],
          color: 'red'
        },
        {
          title: '资源引用报错: 48',
          desc:
            '报错数量比上次降低20次, 比最近20次扫描均值降低176次, 请注意增量',
          valueList: [
            60,
            80,
            100,
            120,
            140,
            200,
            300,
            360,
            320,
            280,
            240,
            300,
            260,
            220,
            260,
            240,
            200,
            320,
            400,
            320
          ],
          color: 'yellow'
        },
        {
          title: '贴图尺寸报错: 60',
          desc:
            '报错数量比上次降低20次, 比最近20次扫描均值降低176次, 请查看对应截图',
          valueList: [
            320,
            400,
            320,
            200,
            240,
            260,
            220,
            260,
            300,
            240,
            280,
            320,
            360,
            300,
            200,
            140,
            120,
            100,
            80,
            60
          ],
          color: 'green'
        }
      ],
      headers: [
        {
          text: '任务标签',
          align: 'center',
          value: 'job_label'
        },
        {
          text: 'SVN 版本号',
          align: 'center',
          value: 'svn_version'
        },
        {
          text: '开始时间',
          align: 'center',
          value: 'started_at'
        },
        {
          text: '结束时间',
          align: 'center',
          value: 'finished_at'
        },
        {
          text: '操作',
          align: 'center',
          value: 'action'
        }
      ],
      fakeOption: {
        tooltip: {
          trigger: 'axis'
        },
        legend: {
          data: ['模型顶点超标', '资源引用错误', '贴图尺寸错误']
        },
        grid: {
          left: '3%',
          right: '4%',
          bottom: '3%',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          boundaryGap: false,
          data: ['周一', '周二', '周三', '周四', '周五', '周六', '周日']
        },
        yAxis: {
          type: 'value'
        },
        series: [
          {
            name: '模型顶点超标',
            type: 'line',
            stack: '总量',
            data: [120, 132, 101, 134, 90, 230, 210]
          },
          {
            name: '资源引用错误',
            type: 'line',
            stack: '总量',
            data: [220, 182, 191, 234, 290, 330, 310]
          },
          {
            name: '贴图尺寸错误',
            type: 'line',
            stack: '总量',
            data: [150, 232, 201, 154, 190, 330, 410]
          }
        ]
      },
      jobList: [],
      search: ''
    }
  },
  methods: {
    getJobList: function() {
      this.axios
        .get('/perfcat/jobs/', {
          job_type: 1
        })
        .then(res => {
          this.jobList = res.data.results
        })
    }
  },
  mounted() {
    this.getJobList()
  }
}
</script>

<style scoped>
.lowerCard {
  margin-top: 24px;
}
.inCardElement {
  margin-left: 24px;
  margin-top: 16px;
}
</style>

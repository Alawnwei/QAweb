<template lang='pug'>
v-app
  v-toolbar(color='amber', app, clipped-left, fixed)
    v-toolbar-title M6 天眼 Ver2
    v-spacer
    v-toolbar-items.hidden-sm-and-down
      v-btn(text) 欢迎你，{{ user.firstName }}
  router-view
  v-footer(height='auto', color='amber', app)
    v-layout(justify-center, row, wrap)
      v-flex(py-3, text-xs-center, white--text, xs12)
        | M6-天眼 Ver2 ©2019 —
        strong M6QA
</template>

<script>
import store from '@/store'
import '../../plugins/vuetify'

export default {
  data: () => ({}),
  computed: {
    user: () => store.getters.user
  },
  props: {
    source: String
  },
  methods: {
    clickNavigation: function(item) {
      this.$router.push(item.link)
    }
  },
  components: {}
}
</script>

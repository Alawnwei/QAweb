<template lang="pug">
  div.echarts-container
    v-chart(:options="options", style="width:100%")
</template>
<script>
import Echarts from 'vue-echarts/components/ECharts.vue'
import 'echarts/lib/chart/line'
import 'echarts/lib/component/title'
import 'echarts/lib/component/legend'

export default {
  props: ['serial', 'initData'],
  components: {
    'v-chart': Echarts
  },
  data: function() {
    return {
      options: {},
      grid: [
        {
          left: 50,
          right: 50,
          height: '35%'
        },
        {
          left: 50,
          right: 50,
          height: '35%'
        },
        {
          left: 50,
          right: 50,
          height: '35%'
        }
      ],
      xAxis: [{}],
      dataset: [
        { time: '2019/11/15 12:00:00', fps: 30, dp: 100 },
        { time: '2019/11/15 12:00:01', fps: 29, dp: 200 },
        { time: '2019/11/15 12:00:02', fps: 28, dp: 250 },
        { time: '2019/11/15 12:00:03', fps: 27, dp: 120 },
        { time: '2019/11/15 12:00:04', fps: 26, dp: 190 },
        { time: '2019/11/15 12:00:05', fps: 25, dp: 170 }
      ]
    }
  },
  mounted: function() {}
}
</script>

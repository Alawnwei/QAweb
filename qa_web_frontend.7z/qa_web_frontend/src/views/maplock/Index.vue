<template lang="pug">
v-app
  div
    v-toolbar(fixed, dark)
      v-toolbar-title M6 MapLock
      v-spacer
      v-toolbar-items.hidden-sm-and-down
        v-btn(color="cyan", @click="goPage('maplock')") 地图资源
        v-btn(color="green", @click="goPage('maplock/apply')") 临时权限
        v-btn(color="blue", @click="goPage('maplock/white')") 白名单
        v-btn(text) 欢迎你，{{ user.firstName }}
  router-view.pb-4
  v-footer.py-0(height='auto', dark, fixed)
    v-layout(justify-center, row, wrap)
      v-flex(py-2, text-center, white--text, xs12)
        | 反馈平台 ©2019 &nbsp;
        strong M6 QA
</template>

<script>
import store from '@/store'

export default {
  data: () => ({}),
  computed: {
    user: () => store.getters.user
  },
  props: {
    source: String
  },
  methods: {
    clickNavigation: function(item) {
      this.$router.push(item.link)
    },
    goPage: function(page) {
      window.location.href = '/' + page
    }
  },
  components: {
  }
}
</script>

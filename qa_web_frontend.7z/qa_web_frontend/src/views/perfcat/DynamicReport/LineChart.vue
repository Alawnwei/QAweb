<template>
  <div>
    <v-app id="inspire">
      <v-snackbar v-model="runResult" top :timeout="tipsTimeout" :color="tipsColor">
        {{ runTips }}
        <v-btn text @click="runResult = !runResult">关闭</v-btn>
      </v-snackbar>
      <v-dialog v-model="detailDialog" max-width="600">
        <v-card>
          <v-card-title class="headline">详情查看</v-card-title>
          <v-card-text>
            <v-row>
              <v-col cols="4">
                <v-btn @click="sendJump()">跳转指令</v-btn>
              </v-col>
            </v-row>
          </v-card-text>
          <v-card-actions>
            <v-spacer></v-spacer>
            <v-btn color="green darken-1" text @click="detailDialog = false">关闭</v-btn>
          </v-card-actions>
        </v-card>
      </v-dialog>
      <v-dialog v-model="saveDialog" max-width="600">
        <v-card>
          <v-card-title>
            保存性能数据
          </v-card-title>
          <v-text-field v-model="taskName" :rules="taskNameRule" style="margin-left: 24px; margin-right: 24px" counter="20" label="数据名称" hint="可简要描述测试的目的或对象" />
          <v-card-actions>
            <v-spacer />
            <v-btn text @click="saveDialog = false" color="">取消</v-btn>
            <v-btn text @click="saveData()" color="blue darken-1">保存</v-btn>
          </v-card-actions>
        </v-card>
      </v-dialog>
      <v-tabs dark color="#ffffff" centered grow v-model="activeTab">
        <v-tabs-slider color="#ffffff" />
        <v-tab style="text-transform: none !important;">
          数据采集
        </v-tab>
        <v-tab style="text-transform: none !important;">
          设备日志
        </v-tab>
        <v-tab-item>
          <v-row>
            <v-col cols="10">
              <DeviceSelector @changeDevice="changeDevice($event)" filter-same-ip />
            </v-col>
            <v-col cols="2">
              <v-btn @click="switchPerf(true)" :disabled="openFlag" style="margin-left: 8px; margin-top: 8px">
                开启
              </v-btn>
              <v-btn @click="switchPerf(false)" :disabled="!openFlag" style="margin-left: 8px; margin-top: 8px">
                停止
              </v-btn>
              <v-btn @click="saveDialog = true" :disabled="openFlag || !currentDevice || !(originData.length > 0)" style="margin-left: 8px; margin-top: 8px">
                保存
              </v-btn>
            </v-col>
          </v-row>
          <v-row>
            <v-col cols="6" class="echarts-container" v-for="(options, index) in metricsData" :key="index">
              <v-row>
                <v-chart :options="options['data']" @click="dataClick" style="width:100%" ref="chartRef" />
              </v-row>
              <v-row style="justify-content: center">
                <div v-if="options.data.statistics != undefined && options.data.statistics.max != undefined">
                  <v-chip color="#f5f5f5" label small> 最大值:{{ options.data.statistics.max }} </v-chip>
                  <v-chip color="#f5f5f5" label small style="margin-left: 8px"> 最小值:{{ options.data.statistics.min }} </v-chip>
                  <v-chip color="#f5f5f5" label small style="margin-left: 8px"> 平均值:{{ options.data.statistics.avg }} </v-chip>
                  <v-chip color="#f5f5f5" label small style="margin-left: 8px"> 标准差:{{ options.data.statistics.standardDeviation }} </v-chip>
                </div>
              </v-row>
            </v-col>
          </v-row>
          <v-row>
            <v-col cols="12">
              <v-range-slider color="darken-3" style="margin-top: 24px" max="100" min="0" step="0.1" v-model="timeSlider" label="时间轴" @change="onDataZoom"> </v-range-slider>
            </v-col>
          </v-row>
        </v-tab-item>
        <v-tab-item>
          <v-row>
            <v-col cols="12">
              <LogWidget :log-topic="currentLogTopic" />
            </v-col>
          </v-row>
        </v-tab-item>
      </v-tabs>
    </v-app>
  </div>
</template>
<script>
import Echarts from 'vue-echarts/components/ECharts.vue'
import 'echarts/lib/chart/line'
import 'echarts/lib/component/title'
import 'echarts/lib/component/legend'
import 'echarts/lib/component/tooltip'
import 'echarts/lib/component/dataZoom'
import store from '@/store'
import _ from 'lodash'

import DeviceSelector from '../../../components/DeviceSelector'
import LogWidget from '../../../components/LogWidget'

// Vue.use(vueNats, {
//  url: 'ws://100.84.73.66:32802/nats',
//  json: true, // use JSON data payload
//  reconnect: true, // always reconnect
//  maxReconnectAttempts: -1, // retry forever
//  reconnectTimeWait: 1000 // try to reconnect every second
// });

export default {
  props: ['serial', 'initData'],
  components: {
    'v-chart': Echarts,
    DeviceSelector,
    LogWidget
  },
  computed: {
    user: () => store.getters.user
  },
  data: function() {
    return {
      activeTab: 0,
      timeSlider: [0, 100],
      openFlag: false,
      boomerServer: 'http://' + process.env.VUE_APP_BOOMER_SERVER,
      currentDevice: null,
      currentLogTopic: '',
      sidProfile: null,
      options: {
        title: {
          text: ''
        },
        tooltip: {
          show: true,
          trigger: 'axis',
          axisPointer: {
            animation: false
          }
        },
        dataZoom: [
          {
            show: true,
            start: 0,
            end: 100
          }
        ],
        legend: {
          data: []
        },
        xAxis: {
          data: []
        },
        yAxis: {
          type: 'value'
        },
        series: [
          {
            name: '',
            type: 'line',
            smooth: true,
            data: []
          }
        ],
        statistics: {}
      },
      xAxis: [],
      dataSet: [
        //        { time: '2019/11/15 12:00:00', fps: 30, dp: 100 },
        //        { time: '2019/11/15 12:00:01', fps: 29, dp: 200 },
      ],
      dataCount: 0,
      maxDataCount: 100,
      originData: [],
      currentPoint: null,
      detailDialog: false,
      saveDialog: false,
      taskName: '',
      taskNameRule: [v => v.length <= 20 || '不可超过20个字符, 多余字符将被舍弃'],
      savedDataZoom: [0, 100],
      runResult: false,
      tipsColor: '',
      runTips: '',
      tipsTimeout: 2000,
      runtTips: '',
      metricsList: [],
      // TODO 暂时只能在前端配置显示什么指标
      metricsData: {
        fps: { data: {}, range: { delta: 30 }, name: '帧率' },
        mem: { data: {}, range: { delta: 50 }, name: '内存(MB)' },
        v_count: { data: {}, range: { delta: 50000 }, name: '顶点数' },
        dp: { data: {}, range: { delta: 1000 }, name: 'draw call' }
      }
    }
  },
  watch: {
    currentDevice: function(newVal, oldVal) {
      if (oldVal != null) {
        if (this.sidProfile != null) {
          this.$nats.unsubscribe(this.sidProfile)
        }
      }
      if (newVal != null) {
        this.dataCount = 0
        this.onInitMetricsData()
        this.sidProfile = this.$nats.subscribe(newVal.profileTopic, event => {
          if (this.dataCount > this.maxDataCount) {
            this.onShiftMetricsData()
          } else {
            this.dataCount++
          }
          this.onPushMetricsData(event)
        })
      }
    }
  },
  methods: {
    print: function(msg) {
      console.log(msg)
    },
    getStandardDeviation: function(data) {
      if (!data || data.length === 0) {
        return 0
      }
      let getMean = function(data) {
        return (
          data.reduce(function(a, b) {
            return Number(a) + Number(b)
          }) / data.length
        )
      }
      let m = getMean(data)
      return Math.sqrt(
        data.reduce(function(sq, n) {
          return sq + Math.pow(n - m, 2)
        }, 0) /
          (data.length - 1)
      ).toFixed(2)
    },
    notify: function(type, info) {
      // type ['success', 'info', 'error']
      // 由于全局设置, type 暂时没生效
      const color = {
        success: '#4CAF50',
        info: '#2196F3',
        error: '#FF5252'
      }
      this.tipsColor = color[type]
      if (!this.tipsColor) {
        this.tipsColor = color['info']
      }
      if (type === 'error') {
        this.tipsTimeout = 0
      } else {
        this.tipsTimeout = 2000
      }
      this.runTips = type + ': ' + info
      this.runResult = true
    },
    doStatistics: function() {
      for (var i = 0; i < this.metricsList.length; i++) {
        var metricsKey = this.metricsList[i]
        var tOptions = this.metricsData[metricsKey]['data']
        var datalist = tOptions.series[0].data
        var start = tOptions.dataZoom[0].start
        var end = tOptions.dataZoom[0].end
        var startIndex = Math.round(datalist.length * ((start * 1.0) / 100))
        var endIndex = Math.round(datalist.length * ((end * 1.0) / 100))
        if (startIndex >= datalist.length) {
          startIndex = datalist.length - 1
        }
        if (endIndex >= datalist.length) {
          endIndex = datalist.length - 1
        }
        if (startIndex <= 0) {
          startIndex = 0
        }
        if (endIndex <= 0) {
          endIndex = 0
        }
        var sub = _.slice(datalist, startIndex, endIndex)
        var max = _.max(sub)
        var min = _.min(sub)
        var avg = _.mean(sub)
        var standardDeviation = this.getStandardDeviation(sub, avg)
        if (tOptions.statistics === undefined) {
          tOptions.statistics = {}
        }
        tOptions.statistics.max = max
        tOptions.statistics.min = min
        tOptions.statistics.avg = Math.round(avg * 100) / 100
        tOptions.statistics.standardDeviation = standardDeviation
      }
      this.$forceUpdate()
    },
    sendJump: function() {
      var x = this.currentPoint[0]
      var y = this.currentPoint[1]
      var z = this.currentPoint[2]
      let formData = new FormData()
      formData.append('path', 'M6Project/M6项目/指令脚本/jump.lua')
      formData.append('param', JSON.stringify({ X: x, Y: y, Z: z }))
      formData.append('clientId', this.currentDevice.ip)
      this.axios({
        method: 'post',
        url: this.boomerServer + '/scripts/run_file',
        data: formData,
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }).then(res => {
        if (res.status === 200 && res.data.status === 0) {
          this.notify('success', '发送指令成功')
        } else {
          this.notify('error', '发送指令失败')
        }
      })
    },
    dataClick: function(event) {
      this.currentPoint = this.originData[event.dataIndex]['location']
      this.detailDialog = true
    },
    formatter(params) {
      let param = params[0]
      let tips = '时间: ' + param['name'] + '<br>'
      for (var i = 0; i < this.metricsList.length; i++) {
        var metricsKey = this.metricsList[i]
        var tOptions = this.metricsData[metricsKey]['data']
        tips += metricsKey + ': ' + tOptions.series[0].data[param['dataIndex']] + '<br>'
      }
      var location = this.originData[param['dataIndex']]['location']
      tips += ' 坐标: (' + location[0] + ',' + location[1] + ',' + location[2] + ')' + '<br>'
      tips += ' 朝向: (' + location[3] + ',' + location[4] + ',' + location[5] + ')'
      return tips
    },
    onDataZoom(event) {
      this.savedDataZoom = [event[0], event[1]]
      for (var i = 0; i < this.metricsList.length; i++) {
        var metricsKey = this.metricsList[i]
        var tOptions = this.metricsData[metricsKey]['data']
        tOptions.dataZoom[0].start = event[0]
        tOptions.dataZoom[0].end = event[1]
      }
    },
    onInitMetricsData() {
      this.originData = []
      for (var i = 0; i < this.metricsList.length; i++) {
        var metricsKey = this.metricsList[i]
        var tOptions = _.cloneDeep(this.options)
        tOptions.yAxis.min = this.metricsData[metricsKey]['range']['min']
        tOptions.yAxis.max = this.metricsData[metricsKey]['range']['max']
        this.metricsData[metricsKey]['data'] = tOptions
        tOptions.series[0].name = metricsKey
        tOptions.title.text = this.metricsData[metricsKey]['name']
        tOptions.series[0].data = []
        tOptions.tooltip.formatter = this.formatter
      }
    },
    changeDevice: function(newDevice) {
      this.currentDevice = newDevice
      this.currentLogTopic = newDevice.logTopic
    },
    onPushMetricsData(event) {
      if (!event.data) {
        return
      }
      var data = event.data[0]
      for (var i = 0; i < this.metricsList.length; i++) {
        var metricsKey = this.metricsList[i]
        var tOptions = this.metricsData[metricsKey]['data']
        tOptions.xAxis.data.push(data['capturedAt'].split(' ')[1])
        var v
        if (metricsKey === 'mem') {
          v = data['performanceData'][metricsKey]
          data['performanceData'][metricsKey] = Math.round(v * 100) / 100
        }
        v = data['performanceData'][metricsKey]
        tOptions.series[0].data.push(v)
        if (tOptions.yAxis.min === undefined) {
          tOptions.yAxis.min = Math.round(v) - this.metricsData[metricsKey]['range']['delta']
          if (tOptions.yAxis.min < 0) {
            tOptions.yAxis.min = 0
          }
          tOptions.yAxis.max = Math.round(v) + this.metricsData[metricsKey]['range']['delta']
        }
        if (v < tOptions.yAxis.min) {
          tOptions.yAxis.min = Math.round(v) - this.metricsData[metricsKey]['range']['delta']
          if (tOptions.yAxis.min < 0) {
            tOptions.yAxis.min = 0
          }
        }
        if (v > tOptions.yAxis.max) {
          tOptions.yAxis.max = Math.round(v) + this.metricsData[metricsKey]['range']['delta']
        }
      }
      this.originData.push(data)
    },
    onShiftMetricsData() {
      this.originData.shift()
      for (var i = 0; i < this.metricsList.length; i++) {
        var metricsKey = this.metricsList[i]
        var tOptions = this.metricsData[metricsKey]['data']
        tOptions.xAxis.data.shift()
        tOptions.series[0].data.shift()
      }
    },
    switchPerf(val) {
      this.openFlag = val
      if (val) {
        this.onInitMetricsData()
      }
      let formData = new FormData()
      formData.append('path', 'M6Project/M6项目/指令脚本/switch_perf.lua')
      formData.append('param', JSON.stringify({ flag: val }))
      formData.append('clientId', this.currentDevice.ip)
      this.axios({
        method: 'post',
        url: this.boomerServer + '/scripts/run_file',
        data: formData,
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }).then(res => {
        if (res.data.status === 0) {
          this.notify('success', '执行成功')
        } else {
          this.notify('error', '执行失败' + res.data.msg)
        }
      })
    },
    saveData: function() {
      if (this.taskName.length === 0) {
        return
      }
      if (this.taskName.length > 20) {
        this.taskName = this.taskName.substring(0, 19)
      }
      const clientId = this.currentDevice.ip
      const taskInfo = {
        taskName: this.taskName,
        projectId: '1',
        projectName: 'M6',
        userEmail: this.user.email,
        userName: this.user.firstName,
        dataZoom: JSON.stringify(this.savedDataZoom),
        deviceInfo: JSON.stringify(this.currentDevice)
      }
      const formData = new FormData()

      formData.append('taskInfo', JSON.stringify(taskInfo))
      formData.append('clientId', clientId)

      this.axios({
        method: 'post',
        url: this.boomerServer + '/api/profile/save_task',
        data: formData
      }).then(res => {
        if (res.data.status === 0) {
          this.saveDialog = false
          this.notify('success', this.taskName + '保存成功')
        } else {
          this.notify('error', this.taskName + '保存失败')
        }
      })
    }
  },
  mounted: function() {
    setInterval(this.doStatistics, 2000)
    for (var key in this.metricsData) {
      this.metricsList.push(key)
    }
    this.onInitMetricsData()
  }
}
</script>

<style>
.editor {
  width: 100%;
  height: 800px;
}
</style>

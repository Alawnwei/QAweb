<template>
  <v-card>
    <v-dialog v-model="taskDetailDialog" width="80%">
      <div>
        <v-btn @click="saveImg" :loading="capturing" style="margin-top: 8px">
          保存为图片
          <v-icon small>save</v-icon>
        </v-btn>
        <a ref="downloadPuppet"></a>
        <div ref="report">
          <v-card outlined>
            <v-card-title>
              数据详情
            </v-card-title>
            <v-subheader>
              结论
            </v-subheader>
            <v-divider />
            <div>
              <v-rich-text-editor ref="editor" v-model="conclusion" :options="editorOptions" style="margin-left: 32px;margin-right: 32px" />
            </div>
            <v-subheader>
              任务信息
            </v-subheader>
            <v-divider></v-divider>
            <v-card outlined class="inDialogTable" style="margin-top: 12px">
              <v-simple-table dense>
                <template v-slot:default>
                  <thead>
                    <tr>
                      <th>任务名称</th>
                      <th>设备系统</th>
                      <th>设备型号</th>
                      <th>CPU(SOC)</th>
                      <th>内存(GB)</th>
                      <th>创建人</th>
                      <th>创建时间</th>
                      <th>结束时间</th>
                      <th>持续时间(s)</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="(item, index) in rawData" :key="index">
                      <td>{{ item.task.taskName }}</td>
                      <td>
                        {{ getDeviceInfo(item.task.deviceInfo).platform || 'N/A' }}
                      </td>
                      <td>
                        {{ getDeviceInfo(item.task.deviceInfo).model || 'N/A' }}
                      </td>
                      <td>
                        {{ getDeviceInfo(item.task.deviceInfo).cpu || 'N/A' }}
                      </td>
                      <td>
                        {{ getDeviceInfo(item.task.deviceInfo).ram || 'N/A' }}
                      </td>
                      <td>{{ item.task.userName }}</td>
                      <td>{{ normalizeTime(item.task.startTime) }}</td>
                      <td>{{ normalizeTime(item.task.endTime) }}</td>
                      <td>
                        {{ getPeriod(item.task.startTime, item.task.endTime) }}
                      </td>
                    </tr>
                  </tbody>
                </template>
              </v-simple-table>
            </v-card>
            <v-subheader v-if="Object.keys(platformChartOption).length > 1">
              快捷跳转
              <v-chip-group style="margin-left: 32px">
                <v-chip small v-for="platform in Object.keys(platformChartOption)" :key="platform" :href="'#' + platform">
                  {{ platform }}
                </v-chip>
              </v-chip-group>
            </v-subheader>
            <v-tabs v-for="(platform, index) in Object.keys(platformChartOption)" :key="index" :id="platform" style="margin-top: 8px;" grow>
              <v-tab>
                {{ platform }}
              </v-tab>
              <v-tab-item>
                <v-subheader>
                  统计信息
                </v-subheader>
                <v-divider></v-divider>
                <v-data-iterator :items="platformChartOption[platform]" disable-pagination hide-default-footer>
                  <template v-slot:default="props">
                    <v-row>
                      <v-col v-for="item in props.items" :key="item.name" lg="6" md="12">
                        <v-card class="inDialogTable" outlined>
                          <v-subheader>{{ item.title.text }}</v-subheader>
                          <v-divider></v-divider>
                          <v-simple-table dense>
                            <template v-slot:default>
                              <thead>
                                <tr>
                                  <th>任务名</th>
                                  <th>最大值</th>
                                  <th>最小值</th>
                                  <th>均值</th>
                                  <th>标准差</th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr v-for="(data, index) in item.series" :key="index">
                                  <td>{{ data.name }}</td>
                                  <td>{{ data.max }}</td>
                                  <td>{{ data.min }}</td>
                                  <td>{{ data.mean }}</td>
                                  <td>{{ data.standardDeviation }}</td>
                                </tr>
                              </tbody>
                            </template>
                          </v-simple-table>
                        </v-card>
                      </v-col>
                    </v-row>
                  </template>
                </v-data-iterator>
                <v-subheader id="jump">
                  数据表格
                </v-subheader>
                <v-divider></v-divider>
                <v-row>
                  <v-col lg="6" md="12" v-for="(option, index) in platformChartOption[platform]" :key="index">
                    <ProfileChart :options="option" />
                  </v-col>
                </v-row>
              </v-tab-item>
            </v-tabs>
          </v-card>
        </div>
      </div>
    </v-dialog>
    <div>
      <TaskTable ref="taskTable" @updateData="updateMetricsData($event)" />
    </div>
  </v-card>
</template>

<script>
import ProfileChart from '../../../components/ProfileChart'
import TaskTable from './TaskTable'
import html2canvas from 'html2canvas'
import 'quill/dist/quill.core.css'
import 'quill/dist/quill.snow.css'
import 'quill/dist/quill.bubble.css'
import { quillEditor } from 'vue-quill-editor'

import _ from 'lodash'
import { getPeriod, getDeviceInfo, getUnion, shiftData, getTagStats, getMarkArea } from './Utils'

export default {
  name: 'History',
  components: {
    ProfileChart,
    TaskTable,
    'v-rich-text-editor': quillEditor
  },
  data() {
    return {
      capturing: false,
      conclusion: null,
      editorOptions: {
        theme: 'bubble',
        placeholder: '请在这里填写结论...',
        modules: {
          toolbar: [
            [{ size: [false, 'large', 'huge'] }],
            ['bold', 'strike', 'underline'],
            [{ list: 'ordered' }, { list: 'bullet' }],
            [{ color: ['white', 'black', 'red', 'yellow'] }, { background: ['white', 'black', 'red', 'yellow'] }],
            ['clean']
          ]
        }
      },
      screenUrl: '',
      boomerServer: 'http://' + process.env.VUE_APP_BOOMER_SERVER,
      taskDetailDialog: false,
      taskDetailDialogWidth: false,
      initOptions: {
        title: {
          text: ''
        },
        tooltip: {
          show: true,
          trigger: 'axis',
          axisPointer: {
            animation: false
          }
        },
        legend: {
          right: '48',
          orient: 'vertical',
          data: []
        },
        xAxis: {
          data: [],
          boundaryGap: false,
          type: 'category'
        },
        yAxis: {
          type: 'value'
        },
        series: [],
        statistics: {}
      },
      rawData: [],
      chartOptionList: [],
      platformChartOption: {},
      taskMetricsData: [],
      dataZoomList: [],
      metrics: {
        fps: { data: {}, range: { delta: 5 }, name: '帧率' },
        mem: { data: {}, range: { delta: 25 }, name: '内存(MB)' },
        v_count: { data: {}, range: { delta: 50000 }, name: '顶点数' },
        dp: { data: {}, range: { delta: 1000 }, name: 'draw call' }
      }
    }
  },
  methods: {
    saveImg: function() {
      this.capturing = true
      html2canvas(this.$refs.report, { backgroundColor: null }).then(canvas => {
        let dataUrl = canvas.toDataURL('image/png')
        this.capturing = false
        this.screenUrl = dataUrl

        this.$refs.downloadPuppet.href = dataUrl
        this.$refs.downloadPuppet.download = '对比结果.png'
        this.$refs.downloadPuppet.click()
        //  模拟点击下载
      })
    },
    print: function(msg) {
      console.log(msg)
    },
    changeDialogSize: function() {
      this.taskDetailDialogWidth = !this.taskDetailDialogWidth
      this.updateMetricsData([])
      this.$refs.taskTable.getData()
    },
    getDeviceInfo: function(deviceInfoStr) {
      return getDeviceInfo(deviceInfoStr)
    },
    getPeriod: function(startTime, endTime) {
      return getPeriod(startTime, endTime)
    },
    updateMetricsData: function(incomingMetricsData) {
      this.rawData = incomingMetricsData
      this.dataZoomList = this.getInPlotDataZoom()
      this.updatePlot()
      if (incomingMetricsData && incomingMetricsData.length > 0) {
        this.taskDetailDialog = true
      }
    },
    updatePlot: function() {
      const taskNames = {}
      this.chartOptionList = []
      this.platformChartOption = {}

      // 从原始数据中规整数据, 获取taskMetricsData
      this.taskMetricsData = this.rawData.map(taskData => {
        const { taskName, dataZoom, deviceInfo } = taskData.task
        const { platform } = getDeviceInfo(deviceInfo)
        if (!(platform in this.platformChartOption)) {
          this.platformChartOption[platform] = []
          taskNames[platform] = []
        }
        taskNames[platform].push(taskName)
        const data = this.normalizeData(taskData.data, JSON.parse(dataZoom))

        return { taskName, platform, ...data }
      })

      // 处理 tag 相关信息
      this.taskMetricsData = this.taskMetricsData.map(data => {
        const { names } = data
        const tagStats = getTagStats(names)
        return { ...data, tagStats }
      })

      Object.keys(this.platformChartOption).map(platform => {
        const chartOptions = {}
        const metricsSeries = {}

        Object.keys(this.metrics).map(key => {
          metricsSeries[key] = []
          const maxValue = []
          const lengthList = []
          chartOptions[key] = _.cloneDeep(this.initOptions)
          for (let i = 0; i < this.taskMetricsData.length; i++) {
            if (this.taskMetricsData[i].platform !== platform) {
              continue
            }
            const max = Math.max(...this.taskMetricsData[i][key]).toFixed(2)
            const min = Math.min(...this.taskMetricsData[i][key]).toFixed(2)
            const mean = this.getMean(this.taskMetricsData[i][key]).toFixed(2)
            const standardDeviation = this.getStandardDeviation(this.taskMetricsData[i][key], mean)
            maxValue.push(max)
            maxValue.push(min)
            lengthList.push(this.taskMetricsData[i][key].length)
            const seriesData = {
              name: this.taskMetricsData[i].taskName + '->' + this.taskMetricsData[i].platform + '->' + key,
              tagNames: this.taskMetricsData[i].names,
              data: this.taskMetricsData[i][key],
              type: 'line',
              smooth: true,
              symbol: 'circle',
              symbolSize: 4,
              max,
              min,
              mean,
              standardDeviation
            }
            metricsSeries[key].push(seriesData)
          }
          const max = Math.max(...maxValue)
          const min = Math.min(...maxValue)
          const dataLength = Math.max(...lengthList)
          let i = 0
          const xAxisData = []
          while (dataLength >= i) {
            xAxisData.push(i)
            i++
          }
          // 控制住数据轴, 不要变得过于夸张
          if (max - min < 0.01 * min) {
            chartOptions[key].yAxis.max = Math.round(max + 0.01 * min)
            chartOptions[key].yAxis.min = Math.round(min - 0.01 * min)
          } else {
            chartOptions[key].yAxis.max = Math.round(0.25 * (max - min) + max)
            chartOptions[key].yAxis.min = Math.round(min - 0.25 * (max - min))
          }
          if (chartOptions[key].yAxis.min < 0) {
            chartOptions[key].yAxis.min = 0
          }
          chartOptions[key].xAxis.data = xAxisData
          chartOptions[key].title.text = this.metrics[key].name
          chartOptions[key].series = metricsSeries[key]
          chartOptions[key].legend.data = taskNames[platform].map(taskName => taskName + '->' + key)
          chartOptions[key].tooltip.formatter = this.formatter
          this.platformChartOption[platform].push(chartOptions[key])
        })

        const platformMarkArea = []
        this.taskMetricsData.map(data => {
          if (data.platform === platform) {
            platformMarkArea.push(data.tagStats)
          }
        })

        const tagUnion = getUnion(platformMarkArea)
        const markAreaData = getMarkArea(tagUnion)
        if (tagUnion.length === 0) {
          return
        }
        this.platformChartOption[platform] = this.platformChartOption[platform].map(dataOption => {
          let { series } = dataOption
          series = series.map(seriesData => {
            const newData = shiftData(seriesData.data, seriesData.tagNames, tagUnion)
            return { ...seriesData, data: newData }
          })
          series[0].markArea = { data: markAreaData, label: { show: false } }
          return { ...dataOption, series }
        })
      })
    },
    getMean: function(data) {
      return (
        data.reduce(function(a, b) {
          return Number(a) + Number(b)
        }) / data.length
      )
    },
    getStandardDeviation: function(data, mean) {
      let m = this.getMean(data)
      return Math.sqrt(
        data.reduce(function(sq, n) {
          return sq + Math.pow(n - m, 2)
        }, 0) /
          (data.length - 1)
      ).toFixed(2)
    },
    getInPlotDataZoom: function() {
      return this.rawData.map(data => ({
        taskName: data.task.taskName,
        dataZoom: JSON.parse(data.task.dataZoom)
      }))
    },
    normalizeTime: function(time) {
      const date = new Date(time)
      return date.toLocaleString('chinese', { hour12: false })
    },
    normalizeData: function(profileData, dataZoom) {
      const result = {}
      Object.keys(this.metrics).map(key => {
        result[key] = []
      })
      result['timeStamp'] = []
      result['names'] = []

      const zoomedData = profileData.slice(Math.round((profileData.length * dataZoom[0]) / 100), Math.round((profileData.length * dataZoom[1]) / 100))
      if (zoomedData.length === 0) {
        return
      }
      const startTimeStamp = zoomedData[0].captureTime
      result.startTimeStamp = startTimeStamp
      zoomedData.map(profile => {
        result['timeStamp'].push(profile.captureTime - startTimeStamp)
        result['names'].push(profile.extra_data)
        Object.keys(profile.data[0].performanceData).map(key => {
          result[key].push(profile.data[0].performanceData[key])
        })
      })
      return result
    },
    formatter: function(params) {
      const localParams = params[0]
      const { seriesName, dataIndex } = localParams
      let key = ''
      let platform = ''
      const tmpList = seriesName.split('->')
      if (tmpList.length > 2) {
        key = tmpList[tmpList.length - 1]
        platform = tmpList[tmpList.length - 2]
      } else {
        return 'seriesName 错误: ' + seriesName
      }
      const series = this.getSeries(platform, key)

      let tooltips = []
      const { tagNames } = series[0]
      if (tagNames && tagNames.length > 0) {
        tooltips.push('tag: ' + tagNames[dataIndex])
      }

      series.map(data => {
        const content = 'Value: ' + data.data[dataIndex] + '(' + data.name + ')'
        tooltips.push(content)
      })

      return tooltips.join('<br/>')
    },
    getSeries: function(platform, key) {
      const { name } = this.metrics[key]
      for (let i = 0; i < this.platformChartOption[platform].length; i++) {
        if (this.platformChartOption[platform][i].title.text === name) {
          return this.platformChartOption[platform][i].series
        }
      }
    }
  },
  mounted() {
    this.updateMetricsData([])
  }
}
</script>

<style scoped>
.inDialogTable {
  margin-left: 24px;
  margin-right: 24px;
}
</style>

<template>
  <v-app>
    <v-form>
      <v-container>
        <v-row>
          <v-col>
            <v-text-field label="Solo" placeholder="输入job id (用于演示，后面可以去掉)" solo v-model="jobId"></v-text-field>
          </v-col>
        </v-row>
      </v-container>
    </v-form>

    <v-simple-table>
      <template v-slot:default>
        <thead>
          <tr>
            <th class="text-left">资源路径</th>
            <th class="text-left">问题列表</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="result in invalidCheckData" :key="result.index">
            <td>{{ result.resource.virtual_path }}</td>
            <td>
              <v-list-item v-for="reason in result.invalid_reason" :key="reason.index">
                <v-list-item-content>
                  <v-list-item-title>{{ reason }}</v-list-item-title>
                </v-list-item-content>
              </v-list-item>
            </td>
          </tr>
        </tbody>
      </template>
    </v-simple-table>
  </v-app>
</template>

<script>
export default {
  components: {},
  data: () => {
    return {
      jobId: null,
      checkData: {}
    }
  },
  watch: {
    jobId: function(val) {
      this.fetchCheckData()
    }
  },
  computed: {
    invalidCheckData: function() {
      return this.checkData.filter(x => !x.is_valid)
    }
  },
  mounted: function() {},
  props: {},
  methods: {
    fetchCheckData: function() {
      this.axios.get('/perfcat/resource_test_results/?job=' + this.jobId, {}).then(res => {
        if (res.status === 200) {
          this.checkData = res.data.results
        }
      })
    }
  }
}
</script>

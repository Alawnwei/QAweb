<template lang="pug">
  router-view
</template>

<script></script>

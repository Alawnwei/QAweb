function ServerWebsocket() {
  var szServer = 'ws://m6-qa-test001.ejoy.com:12001'
  var socket = null
  var bOpen = false
  var cmdList = null
  var restart = false
  var messageevent = {
    onInit: function() {
      socket = new WebSocket(szServer)
      this.render('start to connect to server websocket \n')
    },

    onOpen: function() {
      bOpen = true
      this.render('success to connect to server websocket \n')
      if (cmdList != null) {
        let func = cmdList.shift()
        if (func === undefined) {
          this.close()
        }
        let method = func['method']
        method(func['args'])
      }
    },

    onSend: function(msg) {
      socket.send(msg)
    },

    onMessage: function(msg) {
      if (msg.data === 'exec_success') {
        if (cmdList != null) {
          let func = cmdList.shift()
          if (func === undefined) {
            if (restart === true) {
              restart = false
            }
            this.close()
          } else {
            let method = func['method']
            method(func['args'])
          }
        }
        return
      } else if (msg.data === 'exec_fail') {
        this.render('#Rwebsocket connect error \n')
        socket.close()
        return
      }
      this.render(msg.data.substr(4))
    },

    onErrow: function(event) {
      this.render(event)
    },

    onClose: function(event) {
      this.render('server websocket close \n')
      if (socket.close() != null) {
        bOpen = false
        socket = null
      }
    }
  }

  this.connect = function() {
    messageevent.onInit()
    socket.onopen = messageevent.onOpen
    socket.onmessage = messageevent.onMessage
    socket.onerror = messageevent.onError
    socket.onclose = messageevent.onClose
  }

  this.send = function(data) {
    if (bOpen === false) {
      return false
    }
    messageevent.onSend(data)
    this.render(data + '\n')
    return true
  }

  this.close = function() {
    messageevent.onClose()
  }

  this.reset_ca = function(usr) {
    let cmd = 'exec_cmd python3 ~/m6_tools/serverctrl/main.py reset_ca_dir -u ' + usr
    messageevent.onSend(cmd)
  }

  this.update = function(usr) {
    let cmd = 'exec_cmd python3 ~/m6_tools/serverctrl/main.py update -u ' + usr
    messageevent.onSend(cmd)
  }

  this.restart = function(usr) {
    restart = true
    let cmd = 'exec_cmd python3 ~/m6_tools/serverctrl/main.py restart_server -u ' + usr
    messageevent.onSend(cmd)
  }

  this.tail = function(usr) {
    let cmd = 'exec_cmd cd ~/m6_tools/serverctrl/' + usr + '/server/log; tail -f goscon_*.log usc_*.log app_*.log -n 200'
    messageevent.onSend(cmd)
  }

  this.switch_branch = function(args) {
    let usr = args['usr']
    let branch = args['branch']
    let cmd = 'exec_cmd python3 ~/m6_tools/serverctrl/main.py switch_branch -u ' + usr + ' --branch ' + branch
    messageevent.onSend(cmd)
  }

  this.sshcmd = function(cmd) {
    messageevent.onSend('exec_cmd ' + cmd)
  }

  this.docmd = function(funcList = null) {
    if (funcList !== null) {
      cmdList = funcList
    }
    let func = cmdList.shift()
    if (func === undefined) {
      this.close()
    }
    let method = func['method']
    this.render(func['args'])
    method(func['args'])
  }

  this.test = function() {
    this.render('only test!!!!!!')
  }

  this.render = function(msg) {
    console.log(msg)
  }

  return this
}

export default ServerWebsocket

<template lang="pug">
div
  v-navigation-drawer(fixed, clipped, class='grey lighten-4', app)
    v-toolbar(flat)
      v-list
        v-list-tile
          v-list-tile-title.title {{ current_thread_status_text }}
    v-divider
    v-list.pt-0(dense)
      v-list-tile
        v-list-tile-action
          v-icon dashboard
        v-list-tile-content
          v-list-tile-title 编号 : {{ serial }}
      v-list-tile
        v-list-tile-action
          v-icon dashboard
        v-list-tile-content
          v-list-tile-title ip : {{ ip }}
      v-list-tile
        v-list-tile-action
          v-icon dashboard
        v-list-tile-content
          v-list-tile-title 机器 : {{ machine }}
      v-list-tile
        v-list-tile-action
          v-icon dashboard
        v-list-tile-content
          v-list-tile-title 操作系统 : {{ os }}
      v-list-tile
        v-list-tile-action
          v-icon dashboard
        v-list-tile-content
          v-list-tile-title 操作系统版本 : {{ os_version }}
      v-list-tile
        v-list-tile-action
          v-icon dashboard
        v-list-tile-content
          v-list-tile-title 进程id : {{ pid }}
      v-list-tile
        v-list-tile-action
          v-icon dashboard
        v-list-tile-content
          v-list-tile-title 进程名 : {{ process_name }}
  v-content
    v-container
      slc(:serial="serial", :initData="cpu_stat" v-if="current_thread_status")
      slc(:serial="serial", :initData="memory_stat" v-if="current_thread_status")
</template>
<script>
import SkyeeLineChart from '@/components/SkyeeLineChart'

export default {
  data: function() {
    return {
      current_thread_status: false,
      ip: '',
      machine: '',
      os: '',
      os_version: '',
      pid: '',
      process_name: '',
      cpu_stat: {
        labels: ['cpu'],
        cols: ['cpu'],
        title: 'CPU(%)',
        multiplier: 1,
        unit: '%'
      },
      memory_stat: {
        labels: ['memory'],
        cols: ['memory'],
        title: '内存(mb)',
        multiplier: 0.000001,
        unit: 'mb'
      }
    }
  },
  props: ['serial'],
  computed: {
    current_thread_status_text: function() {
      if (this.current_thread_status) {
        return '当前活跃信息'
      } else {
        return '当前无活跃进程'
      }
    }
  },
  components: {
    slc: SkyeeLineChart
  },
  methods: {
    updateSysInfo: function() {
      this.axios
        .get('/skyee/api/get_sys_info_by_serial/', {
          params: {
            serial: this.serial
          }
        })
        .then(res => {
          if (res.data.success) {
            this.current_thread_status = true

            let resData = res.data.data
            this.ip = resData.ip
            this.machine = resData.machine
            this.os = resData.os
            this.os_version = resData.os_version
            this.pid = resData.pid
            this.process_name = resData.process_name
          }
        })
    }
  },
  mounted: function() {
    this.updateSysInfo()
  }
}
</script>

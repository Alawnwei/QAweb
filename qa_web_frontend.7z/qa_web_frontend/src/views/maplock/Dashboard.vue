<template lang='pug'>
div
  v-content
    v-container(fluid)
      div
        v-alert.my-0(color="green") 常用地图
      div(style="overflow-x:scroll;display:flex")
        v-col(v-for="umap_id in common_list", :key="umap_id", cols="1", sm="4", md="3", lg="2")
          maplock-Card(title="Umap", :umapId="umap_id", :dataFilter="filter", @update_locked_list="update_list", @lock_alert="lock_alert_func")
    v-container(fluid)

      v-expansion-panels(multiple=true,v-model="panel")
        v-expansion-panel(style="margin-top:15px")
          v-expansion-panel-header(color="cyan")
            v-col(cols="8") 已锁地图
          v-expansion-panel-content()
            v-col(v-if="locked_list.length == 0") 暂时没有地图被锁定
            div(style="overflow-x:scroll;display:flex")
              v-col(v-for="umap_id in locked_list", :key="umap_id", cols="1", sm="4", md="3", lg="2")
                maplock-Card(title="Umap", :umapId="umap_id", :dataFilter="filter",  @update_locked_list="update_list", @lock_alert="lock_alert_func")

        v-expansion-panel(style="margin:30px")
          v-expansion-panel-header(color="blue")
            v-col(cols="8") 地图列表
          v-expansion-panel-content
            maplock-Table(title="地图列表", @update_locked_list="update_list", @lock_alert="lock_alert_func")

    v-snackbar(v-model="lock_alert",top=true,left=true,:timeout="timeout",:color="alert_color",multi-line=true)
      span {{alert_text}}
      v-btn(dark,text,@click='lock_alert = false') close
</template>

<script>
import store from '@/store'

export default {
  data: () => ({
    filter: {
    },
    panel: [0],
    common_list: [],
    locked_list: [],
    lock_alert: false,
    alert_text: '',
    alert_color: 'info',
    timeout: 3000
  }),
  computed: {
    user: () => store.getters.user
  },
  created: function() {
    this.update_list()
  },
  props: {
    source: String
  },
  methods: {
    get_common_list: function() {
      this.axios
        .get('/get_umap_common_list')
        .then(res => {
          this.common_list = res.data
        })
    },
    get_locked_list: function() {
      this.axios
        .get('/get_umap_locked_list')
        .then(res => {
          this.locked_list = res.data
        })
    },
    update_list: function() {
      this.get_common_list()
      this.get_locked_list()
    },
    lock_alert_func: function(msg) {
      this.lock_alert = true
      this.alert_color = msg.color
      this.alert_text = msg.text
    }
  },
  components: {
    'maplock-Card': () => import('@/components/MaplockCard.vue'),
    'maplock-Table': () => import('@/components/MaplockTable.vue')
  }
}
</script>

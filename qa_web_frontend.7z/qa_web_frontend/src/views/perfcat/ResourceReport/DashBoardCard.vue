<template>
  <v-card
      class="mt-4 mx-auto"
      max-width="400"
  >
    <v-card-title :color="color">
      <v-icon :color="color">mdi-alarm-light </v-icon>
      &nbsp;
      {{title}}
    </v-card-title>
    <v-card-text class="pt-0">
      <div class="subheading font-weight-light grey--text">{{desc}}</div>
      <v-divider class="my-2"></v-divider>
      <v-row>
        <div style="margin-left: 8px">
          <v-icon class="mr-2" small>
            mdi-clock
          </v-icon>
          <span class="caption grey--text font-weight-light">{{additional}}</span>
        </div>
        <v-spacer/>
        <v-btn icon @click="goto" style="margin-right: 36px;" small>
          趋势&nbsp;
          <v-icon>mdi-chart-line</v-icon>
        </v-btn>
        <v-btn icon @click="goto" style="margin-right: 18px" small>
          详情&nbsp;
          <v-icon>mdi-arrow-right</v-icon>
        </v-btn>
      </v-row>
    </v-card-text>
  </v-card>
</template>

<script>
export default {
  name: 'DashBoardCard',
  props: {
    title: { type: String, required: true },
    desc: { type: String, required: true },
    additional: { type: String, required: true },
    color: {
      type: String,
      default: 'cyan'
    }
  },
  methods: {
    goto: function () {
      this.$router.push({
        path: '/perfcat/resource-report-detail',
        params: {
          id: 9952356
        }
      })
    }
  }
}
</script>

<style scoped>
  .v-sheet--offset {
    top: -24px;
    position: relative;
  }
</style>

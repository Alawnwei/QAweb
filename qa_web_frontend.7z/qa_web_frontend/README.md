# QA_WEB_FRONTEND
-------------------

注意此项目的部署依赖于后端工程 [qa_web](http://gitlab.alibaba-inc.com/m6qa/qa_web)

## 简介

qa_web 是一套组内 QA 工具框架，其中已经包含了在 M6 得到实践的一些工具集。后端工程是 [qa_web](http://gitlab.alibaba-inc.com/m6qa/qa_web)，前端工程是 [qa_web_frontend](http://gitlab.alibaba-inc.com/m6qa/qa_web_frontend)。

此工程最初是由 [M6QA](http://gitlab.alibaba-inc.com/groups/m6qa) 维护。如果有任何使用相关问题，欢迎联系 蔡乾(caiqian.cq@alibaba-inc.com) 解决。

### 何时使用

如果你想要在组内使用以下已经在 M6 组内得到实践的功能：

 - aone 工单查询和统计
 - one 平台通用登录和验证
 - 钉钉机器人
 - 反馈平台（feedback）
 - gs 管理平台（初版）
 - perfcat 性能测试工具（部分功能）
 - 天眼 客户端及服务端监测平台
 - ...

或者如果你想要的功能在上面没有，想基于以下我们提供的服务进行快速二次开发：

 - **登录认证和用户管理**。我们接入了 [one](https://one.ejoy.com/admin/) 平台的用户系统，用户可以通过类似 openid 的方式一键登录到 qa_web，并且 qa_web 能轻松拿到用户的 工号、邮箱、姓名、职能（需要在 one 配置）等信息，并存在 qa_web 的数据库中，我们也提供了界面去操作用户的权限。
 - **邮件提醒**。可以调用我们的接口来实现对某个人发邮件提醒的功能。
 - **jenkins api**。我们提供 jenkins api 的统一调用入口，可以轻松通过脚本对已配置好的 jenkins job 进行控制。
 - **报错查询**。我们提供了根据代码报错信息，通过 svn 或 git 提交信息来查询相关提交人信息的接口。只需提供代码行号，就能查到这个错误是谁提交的。
 - **客户端设备管理**。天眼可以拿到当前所有已经连接到服务端的设备列表，并且已经接通报错显示和指令输入。
 - .....

### 正确的使用方式

qa_web 目的是 **以一套通用的框架** 来 **快速地** 解决组内 **工具需求** ，但我们反对重复造轮子。

我们通过内部开放源码的方式。如果你有定制开发需求，可以自行修改代码。并且如果有好的改进，欢迎向 master 提 merge request。我们希望和大家一起来维护这个 repo。

如果有通用的功能需求并且中台已经提供支持，请优先考虑使用中台的 [**质效平台**](http://sonic.ep.ucweb.local/project)。如果有通用功能需求中台还未支持的，欢迎联系 刘威(lw89491@alibaba-inc.com) 或 刘原龙(luke.lyl@alibaba-inc.com) 提需求。

## 部署指南

### 环境需求

 - 操作系统不限。目前没有遇到过在不同 OS 上的构建问题。
 - **NodeJS 11+** 。13.3.0 是我们线上部署的版本。
 - **Caddy** or **Nginx**。这是用作反向代理服务器，从部署简易程度上来说我们建议使用 Caddy。因为前端构建出来是一堆静态文件，强烈建议在部署时使用反向代理。

**以上所有的东西在 MacOS 上都能用 homebrew 解决。**

### 最简部署流程

检出对应分支的代码：
```
git clone git@gitlab.alibaba-inc.com:m6qa/qa_web_frontend.git
```

or use http：
```
git clone http://gitlab.alibaba-inc.com/m6qa/qa_web_frontend.git
```

切换到对应分支：
```
git checkout xxx_dev
```

or 如果分支不存在可以自行从master拉出：
```
git checkout -b xxx_dev
```

安装依赖：
```
npm install
```

修改后台地址指向 qa_web 后端地址
```
vi src/http.js
```

修改认证模块使用组内 one 分组
```
vi src/router.js
```

开发模式启动：
```
npm run serve
```

or 生产环境build
```
npm run build
```
然后把反向代理指向 dist 文件夹即可
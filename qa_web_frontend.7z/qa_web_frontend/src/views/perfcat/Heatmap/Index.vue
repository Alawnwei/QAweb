<template lang="pug">
  heatmap
</template>

<script>
import Heatmap from './Heatmap'

export default {
  components: {
    heatmap: Heatmap
  }
}
</script>

<template lang="pug">
v-app(id="inspire")
  div
    v-toolbar(fixed, color="cyan")
      v-toolbar-title M6 指令大全
      v-spacer
      v-toolbar-items.hidden-md-and-down
        v-btn(text) 欢迎你, {{ user.firstName }}
    v-text-field(
      label="搜索",
      hide-details,
      append-icon="search",
      style="width:50%; float:left; margin-left:20%",
      v-model="searchtext"
    )
    v-btn(
      class="ma-2",
      outlined,
      color="cyan",
      @click="searchGM()"
    ) 搜索
    v-dialog(
      v-model="addgm",
      permanent,
      max-width="800px"
      )
      template(v-slot:activator="{ on }")
        v-btn(
          class="ma-1",
          outlined,
          color="teal",
          v-on="on"
        ) 添加
      v-card
        v-card-title
          span(class="headline") 添加指令
        v-card-text
          v-container
            v-textarea(
              label="Tip:格式为xxx//xxx(前者为指令，后者为描述，用//隔开)，添加多个指令请分行区分开",
              v-model="addGmValue"
            )
        v-card-actions
          v-spacer
            v-btn(color="blue darken-1", text, @click="addGM()") 提交
            v-btn(color="blue darken-1", text, @click="addgm = false") 取消
    v-dialog(
      v-model="editgm",
      permanent,
      max-width="800px"
    )
      v-card
        v-card-title
          span(class="headline") 修改指令
        v-card-text
          v-container
            v-text-field(
              v-model="updateGMText",
              label="指令",
              outlined
            )
            v-text-field(
              v-model="updateGMDesc",
              label="描述",
              outlined
            )
        v-card-actions
          v-spacer
            v-btn(color="blue darken-1", text, @click="updateGM()") 修改
            v-btn(color="blue darken-1", text, @click="editgm = false") 取消
    v-data-table(
      :headers="headers",
      :items="items",
      :items-per-page="5",
      sort-by="calories",
      class="elevation-1"
    )
      template(v-slot:item.actions="{ item }")
        v-icon(small, class="mr-2",@click="updateDialog(item)") mdi-pencil
        v-icon(small, @click="deleGM(item)") mdi-delete
</template>

<script>
import Qs from 'qs'
import store from '@/store'

export default {
  props: [],
  data: () => ({
    dialog: false,
    addgm: false,
    editgm: false,
    searchtext: '',
    headers: [
      { text: '指令', align: 'center', value: 'gm_text' },
      { text: '描述', align: 'center', value: 'gm_desc' },
      { text: '提交人', align: 'center', value: 'gm_auth' },
      { text: '修改时间', align: 'center', value: 'update_time' },
      { text: '操作', align: 'center', value: 'actions', sortable: false }
    ],
    items: [],
    search: '',
    newItem: '',
    editItem: {
      gm_text: '',
      gm_desp: ''
    },
    addGmValue: '',
    updateGMText: '',
    updateGMDesc: '',
    tempGM: ''
  }),
  computed: {
    user: () => store.getters.user
  },
  components: {},
  created: function() {
    this.updateGMList()
  },
  methods: {
    updateGMList: function() {
      this.axios
        .get('/get_gm_cmd')
        .then(res => {
          this.items = res.data
        })
    },
    deleGM: function(item) {
      let gmText = item['gm_text']
      let gmDesc = item['gm_desc']
      let gmAuth = item['gm_auth']
      let updateTime = item['update_time']
      // console.log(gmDesp)
      let oldCmd = {
        'gm_text': gmText,
        'gm_desc': gmDesc,
        'gm_auth': gmAuth,
        'update_time': updateTime
      }
      // console.log(JSON.stringify(oldCmd))
      let postData = Qs.stringify({ old_cmd: JSON.stringify(oldCmd) })
      this.axios
        .post('/gm_cmd_handler', postData)
        .then(res => {
          if (res.data === 'suc') {
            alert('删除成功')
            window.location.reload()
          }
        })
    },
    addGM: function() {
      let newCmd = this.addGmValue
      let postData = Qs.stringify({ new_cmd: JSON.stringify(newCmd) })
      this.axios
        .post('/gm_cmd_handler', postData)
        .then(res => {
          alert('新增成功')
          window.location.reload()
        })
    },
    updateDialog: function(item) {
      this.editgm = true
      this.updateGMText = item.gm_text
      this.updateGMDesc = item.gm_desc
      this.tempGM = {
        'gm_text': item.gm_text,
        'gm_desc': item.gm_desc,
        'gm_auth': item.gm_auth,
        'update_time': item.update_time
      }
      // console.log(this.tempGM)
    },
    updateGM: function() {
      let oldCmd = this.tempGM
      let gmText = this.updateGMText
      let gmDesc = this.updateGMDesc
      let newCmd = gmText + '/' + gmDesc
      let postData = Qs.stringify({ old_cmd: JSON.stringify(oldCmd), new_cmd: newCmd })
      this.axios
        .post('/gm_cmd_handler', postData)
        .then(res => {
          alert('修改成功')
          window.location.reload()
        })
    },
    searchGM: function() {
      let gm = this.searchtext
      let postData = Qs.stringify({ gm: gm })
      this.axios
        .post('/search_gm_cmd', postData)
        .then(res => {
          this.items = res.data
        })
    }
  }
}
</script>

<template lang="pug">
v-navigation-drawer(permanent,)
  v-list-item
    v-list-item-title 图表类型
  v-divider
  v-list(dense)
    router-link(v-for="item in items", :to="item.link", :key="item.title", tag="a")
      v-list-item(link)
        v-list-item-content
          v-list-item-title {{ item.title }}
</template>

<script>
export default {
  data: function() {
    return {
      items: [
        { title: '散点图', link: '/perfcat/scatter-3d' },
        { title: '性能趋势', link: '/perfcat/perf-report' },
        // { title: '坐标点比较', link: '/perfcat/location-report' },
        // { title: '坐标点趋势图', link: '/perfcat/position-report' },
        { title: '静态资源检查', link: '/perfcat/resource-report' },
        { title: '动态数据', link: '/perfcat/dynamic-report' },
        { title: '性能历史', link: '/perfcat/profile-history' },
        { title: '脚本管理', link: '/perfcat/script-mgr' }
      ]
    }
  }
}
</script>
<style lang="sass">
a
  text-decoration: none
</style>

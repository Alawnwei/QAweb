<template lang="pug">
  div.echarts-container
    v-chart(:options="options", style="width:100%")
</template>
<script>
import Echarts from 'vue-echarts/components/ECharts.vue'
import 'echarts/lib/chart/line'
import 'echarts/lib/component/title'
import 'echarts/lib/component/legend'

export default {
  props: ['serial', 'initData'],
  components: {
    'v-chart': Echarts
  },
  data: function() {
    return {
      options: null
    }
  },
  mounted: function() {
    this.axios
      .get('/skyee/api/tick/get_history_data/', {
        params: {
          serial: this.serial,
          cols: this.initData.cols
        }
      })
      .then(res => {
        let series = []
        for (var i = 0; i < this.initData.cols.length; i++) {
          series[i] = {
            name: this.initData.labels[i],
            type: 'line',
            data: res.data.data.map(item =>
              Math.round(item[this.initData.cols[i]] * this.initData.multiplier)
            ),
            markLine: false,
            label: {
              show: true,
              fontSize: 10,
              distance: 5,
              position: 'bottom'
            },
            smooth: true
          }
        }

        this.options = {
          title: {
            text: this.initData.title
          },
          legend: {
            orient: 'verticle',
            right: 0,
            top: 0,
            data: this.initData.labels
          },
          tooltip: {
            trigger: 'axis'
          },
          xAxis: {
            data: res.data.data.map(item => item.created_at)
          },
          yAxis: {
            splitLine: {
              show: false
            }
          },
          toolbox: {
            left: 'center',
            feature: {
              dataZoom: {
                yAxisIndex: 'none'
              },
              restore: {},
              saveAsImage: {}
            }
          },
          dataZoom: [
            {
              type: 'inside'
            }
          ],
          series: series
        }
      })
  }
}
</script>

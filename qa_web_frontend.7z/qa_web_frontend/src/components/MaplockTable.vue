<template lang="pug">
div
  v-container(fluid)
    v-data-table(
      :headers="headers",
      :items="brands",
      :search="search",
      class="elevation-1"
    )
      template(slot="items",slot-scope="props")
      template(v-slot:top)
        v-text-field(v-model="search",label="搜索地图名",class="mx-4")
      template(v-slot:item.umap_lock="{ item }")
        span(v-if="item.umap_lock=='enlock'") 被锁定
        span(v-if="item.umap_lock=='unlock'") 正常
      template(v-slot:item.action="{ item }")
        v-btn.mx-0(text, icon, small, @click="unlock_tips(item)", v-if="item.umap_lock=='enlock' && user.username == item.job_num", :loading="lock_loading")
          v-icon(color="primary") lock_open
        v-btn.mx-0(text, icon, small, @click="lock_confirm(item)", v-if="item.umap_lock=='unlock'", :loading="lock_loading")
          v-icon(color="primary") lock
        v-btn.mx-0(text, icon, small, @click="onapply(item)", v-if="item.umap_lock=='enlock' && user.username != item.job_num", :loading="lock_loading")
          v-icon(color="primary") send
    v-dialog(v-model="map_lock",persistent,max-width="600px")
      v-card
        v-card-title
          span 地图锁定确认
        v-card-text
          div(style="width:80%,margin-left:5%")
              span 你要锁定的地图为：
              p.mt-2.subtitle
              span
                strong {{ select_map.umap_name }}
              div(style="width:80%")
                strong.blue--text(style="word-wrap:break-word") {{ select_map.umap_path }}
          v-textarea("label"="记录日志",v-model="lock_log")
        v-card-actions
          v-spacer
          v-btn(color="blue darken-1",text,@click="map_lock = false") 关闭
          v-btn(color="blue darken-1",text,@click="onLock('enlock',select_map)") 确认
    v-dialog(v-model="map_unlock",persistent,max-width="600px")
      v-card
        v-card-title
          span 地图解锁确认
        v-card-text
          div(style="width:80%,margin-left:5%")
              span 你要解锁的地图为：
              p.mt-2.subtitle
              span
                strong {{ select_map.umap_name }}
              div(style="width:80%")
                strong.blue--text(style="word-wrap:break-word") {{ select_map.umap_path }}
        v-card-actions
          v-spacer
          v-btn(color="blue darken-1",text,@click="map_unlock = false") 关闭
          v-btn(color="blue darken-1",text,@click="onLock('unlock',select_map)") 确认
</template>

<script>

import store from '@/store'

export default {
  props: [],
  data: () => ({
    headers: [ // headers表头数组，里面是对象
      { text: '地图名称', align: 'center', value: 'umap_name', sortable: false },
      { text: '路径', align: 'center', value: 'umap_path', sortable: false },
      { text: '地图锁', align: 'center', value: 'umap_lock', sortable: false },
      { text: '最近操作', align: 'center', value: 'lock_user', sortable: false },
      { text: '时间', align: 'center', value: 'lock_time', sortable: false },
      { text: '操作', align: 'center', value: 'action', sortable: false }
    ],
    brands: [],
    search: '',
    lock_log: '',
    map_lock: false,
    map_unlock: false,
    select_map: {
      umap_name: '',
      umap_path: ''
    },
    lock_loading: false
  }),
  components: {
  },
  created: function() {
    this.updateUmapList()
  },
  watch: {
  },
  computed: {
    user: () => store.getters.user
  },
  methods: {
    lock_confirm: function(item) {
      this.select_map = item
      this.map_lock = true
    },
    unlock_tips: function(item) {
      this.select_map = item
      this.map_unlock = true
    },
    onLock: function(status, item) {
      let msg = ''
      if (status === 'enlock') {
        msg = this.lock_log
        if (msg === '') {
          let msg = {
            color: 'warning',
            text: '请记录上锁日志'
          }
          this.$emit('lock_alert', msg)
          return
        }
      } else {
        msg = '正常'
      }
      this.lock_loading = true
      if (status === 'enlock') {
        this.map_lock = false
      } else {
        this.map_unlock = false
      }
      this.axios
        .post('/svn_lock_umap', {
          umap: item.umap_path,
          status: status,
          ci_user: this.user.firstName,
          ci_msg: msg,
          ci_job_number: this.user.username
        })
        .then(res => {
          if (res.data === 'suc') {
            let msg = {
              color: 'info',
              text: '操作成功'
            }
            this.$emit('lock_alert', msg)
          } else {
            let msg = {
              color: 'warning',
              text: res.data
            }
            this.$emit('lock_alert', msg)
          }
          this.updateUmapList()
          this.$emit('update_locked_list')
          this.lock_loading = false
        })
      console.log(item)
    },
    updateUmapList: function() {
      this.axios
        .get('/get_umap_list')
        .then(res => {
          this.brands = res.data
        })
    },
    filterMapname: function(value, search, item) {
      console.log('111')
      return 1
    }
  }
}
</script>
<style lang='sass'>
.v-btn--active
  background-color: green
</style>

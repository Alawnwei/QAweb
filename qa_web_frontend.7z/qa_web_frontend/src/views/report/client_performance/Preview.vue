<template lang="pug">
div
  section.hero
    .hero-body
      .container
        h1.title {{ report.title }}

  section.content.is-small.container
    h2 总结 &nbsp;
      span.tag.is-success(v-if="report.warning_level === 1") 总体状况：极佳
      span.tag.is-primary(v-else-if="report.warning_level === 2") 总体状况：正常
      span.tag.is-warning(v-else-if="report.warning_level === 3") 总体状况：一般
      span.tag.is-warning(v-else-if="report.warning_level === 4") 总体状况：较差
      span.tag(v-else) ...加载中
    .notification.is-info(v-html="report.summary")
    h2 数据总览
    .columns.is-desktop(v-for="i in Math.ceil(reportData.length / 2)")
      .column.is-half(v-for="(rd, index) in reportData.slice((i - 1) * 2, i * 2)")
        l-chart(:labels="rd.labels", :cols="rd.cols", :title="rd.title")
    h2 详细数据
    div(v-for="rd in reportData")
      h3 {{ rd.title }}
      s-table(:labels="rd.labels", :cols="rd.cols", :reportId="reportId")
    div
      h3 内存压测
      div(v-html="report.memory_d60_e2_s1", width="100%")
  footer.footer.is-primary
    div.content.has-text-centered
      p 该邮件由
        strong M6-QA 测试报告小组
        | 发送，归档于
        a(href="http://192.168.41.216:8801/admin/") M6-测试报告平台
        | 。如果有显示问题，请升级邮件客户端。
</template>
<script>
import { library } from '@fortawesome/fontawesome-svg-core'
import { faWineBottle } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/vue-fontawesome'
import Vue from 'vue'

import ReportLineChart from '@/components/ReportLineChart.vue'
import ReportSectionTable from '@/components/ReportSectionTable.vue'

library.add(faWineBottle)

Vue.component('fa-i', FontAwesomeIcon)

export default {
  data: () => {
    return {
      report: {
        title: '',
        summary: '',
        warning_level: null,
        memory_d60_e2_s1: ''
      },
      reportData: [
        // {
        //   title: 'FPS-0726引擎-单人主流程',
        //   cols: [
        //     'fps_s_d80_e1_s1',
        //     'fps_s_d60_e1_s1',
        //     'fps_s_d40_e1_s1',
        //     'fps_s_d20_e1_s1'
        //   ],
        //   labels: ['极致', '高', '低', '流畅']
        // },
        {
          title: 'FPS-单人主流程-0927引擎',
          cols: [
            'fps_s_d80_e2_s1',
            'fps_s_d60_e2_s1',
            'fps_s_d40_e2_s1',
            'fps_s_d20_e2_s1'
          ],
          labels: ['极致', '高', '低', '流畅']
        },
        // {
        //   title: 'FPS-0726引擎-多人压测',
        //   cols: [
        //     'fps_m_d80_e1_s1',
        //     'fps_m_d60_e1_s1',
        //     'fps_m_d40_e1_s1',
        //     'fps_m_d20_e1_s1'
        //   ],
        //   labels: ['极致', '高', '低', '流畅']
        // },
        {
          title: 'FPS-多人压测-0927引擎',
          cols: [
            'fps_m_d80_e2_s1',
            'fps_m_d60_e2_s1',
            'fps_m_d40_e2_s1',
            'fps_m_d20_e2_s1'
          ],
          labels: ['极致', '高', '低', '流畅']
        },
        // {
        //   title: 'FPS-0726引擎-新手流程',
        //   cols: [
        //     'fps_t_d80_e1_s2',
        //     'fps_t_d60_e1_s2',
        //     'fps_t_d40_e1_s2',
        //     'fps_t_d20_e1_s2'
        //   ],
        //   labels: ['极致', '高', '低', '流畅']
        // },
        {
          title: 'FPS-新手流程-0927引擎',
          cols: [
            'fps_t_d80_e2_s2',
            'fps_t_d60_e2_s2',
            'fps_t_d40_e2_s2',
            'fps_t_d20_e2_s2'
          ],
          labels: ['极致', '高', '低', '流畅']
        }
        // {
        //   title: 'FPS-单人主流程-0927引擎-新场景',
        //   cols: [
        //     'fps_s_d80_e2_s2',
        //     'fps_s_d60_e2_s2',
        //     'fps_s_d40_e2_s2',
        //     'fps_s_d20_e2_s2'
        //   ],
        //   labels: ['极致', '高', '低', '流畅']
        // }
      ]
    }
  },
  mounted: function() {
    this.axios
      .get('/report/api/client_performance_report/' + this.reportId + '/')
      .then(res => {
        this.report.title = res.data.title
        this.report.summary = res.data.summary
        this.report.warning_level = res.data.warning_level
        this.report.memory_d60_e2_s1 = res.data.memory_d60_e2_s1
      })
  },
  components: {
    'l-chart': ReportLineChart,
    's-table': ReportSectionTable
  },
  props: ['reportId']
}
</script>
<style scoped lang="sass" src="@/../node_modules/bulma/bulma.sass"></style>

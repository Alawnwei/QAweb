let DataTableHeaders = [
  {
    text: '资源ID',
    value: 'id'
  },
  {
    text: '资源路径（UE路径）',
    value: 'virtualPath'
  },
  {
    text: '资源类型',
    value: 'resourceType'
  },
  {
    text: '资源问题数量',
    value: 'problemCount'
  }
]

let transformTableData = function(data) {
  return data.map(o => {
    var ret = {
      id: o.resource.id,
      virtualPath: o.resource.virtual_path,
      resourceType: o.resource.resource_type.name,
      problemCount: o.problems.length,
      attributes: o.attributes
    }

    for (let key in o.attributes) {
      ret[key] = o.attributes[key]
    }

    return ret
  })
}

export { DataTableHeaders, transformTableData }

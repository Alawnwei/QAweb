<template lang="pug">
  v-container(fluid)
    v-row
      v-toolbar(color="#e8e8e8")
        v-toolbar-title
          span {{duty_data.name}}
        v-spacer
        v-autocomplete.mx-2.my-autocomplete(
          v-model="add_user"
          :items="items",
          label="Search",
          item-text="first_name",
          item-value="id",
          flat, solo, hide-details,
        )
        v-btn(large, depressed, @click="add_group") add
    v-row(justify="space-around")
      div(style="overflow-x:scroll;display:flex;width:100%")
        draggable(
          id = "duty_data.id",
          v-model="duty_order",
          tag="v-layout"
        )
          v-col(
            v-for="row, i in duty_order",
            :key="i"
          )
            v-card(color="grey lighten-5")
              v-card-title
                h3 {{i+1}}
                v-spacer
                v-btn(@click="del_group(i)",icon)
                  v-icon close
              v-card-text
                draggable(
                  :list="row",
                  :group="{name:'row'}",
                  @change="onUpdate"
                )
                  user_chip(
                    v-for="item,j in row",
                    :key="j",
                    :userId="item",
                    @chip_delete="chip_delete(i,j)"
                  )
</template>

<script>
import draggable from 'vuedraggable'
import store from '@/store'
export default {
  data: () => ({
    duty_data: {},
    duty_order: [],
    items: [],
    add_user: null
  }),
  computed: {
    user: () => store.getters.user
  },
  props: ['duty_id'],
  created: function() {
    // console.log(this.duty_id)
    this.get_group_data()
  },
  methods: {
    onUpdate: function() {
      let tempIndex = []
      for (let i = 0; i < this.duty_order.length; i++) {
        if (this.duty_order[i].length === 0) {
          tempIndex.push(i)
        }
      }
      for (let j = 0; j < tempIndex.length; j++) {
        this.del_group(tempIndex[j])
        this.duty_order.splice(tempIndex[j], 1)
      }
    },
    del_group: function(index) {
      this.duty_order.splice(index, 1)
    },
    chip_delete: function(groupIndex, userIndex) {
      this.duty_order[groupIndex].splice(userIndex, 1)
      this.onUpdate()
    },
    add_group: function() {
      console.log(this.add_user)
      if (this.add_user) {
        let newGroup = [this.add_user]
        this.duty_order.push(newGroup)
      }
      // let newGroup = [2]
      // this.duty_order.push(newGroup)
    },
    get_group_data: function() {
      let url = '/checklist/duty_groups/' + this.duty_id
      this.axios.get(url, {}).then(res => {
        this.duty_data = res.data
        this.duty_order = res.data.duty_order
        this.get_duty_user_group(res.data.group)
      })
    },
    get_duty_user_group: function(group) {
      let url
      let flag = false
      if (group) {
        url = '/auth/groups/' + group.id
        flag = true
      } else {
        url = 'auth/users'
      }
      this.axios.get(url, {}).then(res => {
        if (flag) {
          this.items = res.data.user_set
        } else {
          this.items = res.data
        }
      })
    }
  },
  watch: {
    duty_order: function(oldVal, newVal) {
      if (newVal.length === 0) {
        return
      }
      let url = '/checklist/duty_groups/' + this.duty_id + '/'
      let params = {
        'duty_order': newVal
      }
      this.axios
        .patch(url, params)
        .then(res => {
          return res.data
        })
    }
  },
  components: {
    draggable,
    user_chip: () => import('@/components/UserChip.vue')
  }
}
</script>

<style lang="sass">
.my-autocomplete
  max-width: 300px
</style>

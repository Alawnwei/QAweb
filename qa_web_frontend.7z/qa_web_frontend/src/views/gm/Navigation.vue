<template lang="pug">
v-navigation-drawer(permanent,)
  v-list-item
    v-list-item-title 功能列表

  v-divider
  v-list(dense)
    router-link(v-for="item in items", :to="item.link", :key="item.title", tag="a")
      v-list-item(link)
        v-list-item-content
          v-list-item-title {{ item.title }}
</template>

<script>
export default {
  data: function() {
    return {
      items: [
        { title: 'gm指令', link: '/gm/gm-directive' },
        { title: 'gm管理', link: '/gm/gm-mgr' }
      ]
    }
  }
}
</script>
<style lang="sass">
a
  text-decoration: none
</style>

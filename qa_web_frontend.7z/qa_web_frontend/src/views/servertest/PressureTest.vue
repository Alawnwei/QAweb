<template>
  <div>
    <ServerSidebar
      v-model="serverDrawer"
      @close="serverDrawer = !serverDrawer"
      @changeServer="changeServer"
      @selectedServerNotCoolDown="errorNotify"/>
    <ActionSidebar @executeAction="executeAction" v-model="functionDrawer" @close="functionDrawer = !functionDrawer"/>
    <v-container fluid class="px-8">
      <v-row>
        <v-card-title >临时测试按钮: </v-card-title>
        <v-btn @click="addLogger">Add</v-btn>
        <v-btn @click="clearLogger">clear</v-btn>
        <v-btn @click="serverDrawer=!serverDrawer">Server</v-btn>
        <v-btn @click="functionDrawer=!functionDrawer">Func</v-btn>
      </v-row>
      <v-row>
        <v-col justify="space-around" v-for="i in logger" :key="i" :cols="12/logger.length">
          <LogWidgetNoSub ref="logger" :loggerName="i"/>
        </v-col>
      </v-row>
      <v-row>
        <ServerCmd @executeCmd="executeAction"/>
      </v-row>
    </v-container>
    <NotifySnackbar :isNotify="isNotify" :text="notifyText" :color="notifyColor" :x="notifyX" :y="notifyY" @close="closeNotify"/>
  </div>
</template>

<script>
import ServerSidebar from '../../components/ServerSidebar'
import ActionSidebar from '../../components/ActionSidebar'
import LogWidgetNoSub from '../../components/LogWidgetNoSub'
import ServerCmd from '../../components/ServerCmd'
import NotifySnackbar from '../../components/NotifySnackbar'

export default {
  components: {
    NotifySnackbar,
    ServerSidebar,
    ActionSidebar,
    LogWidgetNoSub,
    ServerCmd
  },
  data: function () {
    return {
      logger: [],
      isNotify: false,
      notifyText: '',
      notifyColor: 'error',
      notifyX: 'left',
      notifyY: 'bottom',
      wsConnection: undefined,
      serverDrawer: false,
      functionDrawer: false
    }
  },
  methods: {
    addLogger() {
      this.logger.push(Math.random())
      window.localStorage.setItem('loggerConfig', JSON.stringify(this.logger))
      const that = this
      setTimeout(() => { that.$refs.logger.map(logger => logger.reload()) }, 50)
    },
    clearLogger() {
      this.logger = []
      window.localStorage.setItem('loggerConfig', JSON.stringify(this.logger))
    },
    loadLoggerConfig() {
      const loggerConfig = window.localStorage.getItem('loggerConfig')
      if (loggerConfig !== undefined && loggerConfig !== null) {
        this.logger = JSON.parse(loggerConfig)
      }
    },
    executeAction(action) {
      if (!action) {
        return
      }
      console.log('run cmd', action.name)
      this.wsConnection.send(action.content)
    },
    changeServer(server) {
      console.log('change server', server)
      const targetServer = { host: server.ip, port: server.port }
      const cmd = { func: 'changeServer', params: { ...targetServer } }
      this.wsConnection.send(JSON.stringify(cmd))
    },
    connectToServer() {
      if (!this.wsConnection || this.wsConnection.readyState !== 1) {
        this.wsConnection = new WebSocket('ws://localhost:8000/ws/servertest/gsrobotrpc')
      }
      const that = this
      this.wsConnection.onopen = function(evt) {
        console.log('Connection opened ...')
        console.log(that.wsConnection)
        that.wsConnection.send('connected')
      }
      this.wsConnection.onmessage = function(evt) {
        console.log('Received Message: ' + evt.data)
      }
      this.wsConnection.onclose = function(evt) {
        // TODO 做一个断开连接的弹窗, 让用户自己点了重连
        console.log('Connection closed.')
      }
      console.log(this.wsConnection)
    },
    closeNotify() {
      this.isNotify = false
    },
    baseNotify(notifyType, text) {
      this.notifyColor = notifyType
      this.notifyText = text
      this.isNotify = true
    },
    normalNotify(text) {
      this.baseNotify('info', text)
    },
    errorNotify(text) {
      this.baseNotify('error', text)
    },
    successNotify(text) {
      this.baseNotify('success', text)
    }
  },
  mounted() {
    this.loadLoggerConfig()
    this.connectToServer()
  }
}
</script>

<style scoped>

</style>

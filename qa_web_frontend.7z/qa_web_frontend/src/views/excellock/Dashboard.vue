<template lang='pug'>
div
  v-content
    //-
      v-container(fluid)
        div
          v-alert.my-0(color="green") 常用表格
        div(style="overflow-x:scroll;display:flex")
          v-col(v-for="excelData in commonList", :key="excelData.id", cols="1", sm="4", md="3", lg="2")
            excellock-Card(title="Excel", :excelId="excelData.id", :dataFilter="filter", @update_locked_list="on_update_list", @lock_alert="lock_alert_func", ref="excelCard")
    v-container(fluid)
      v-expansion-panels(multiple=true,v-model="panel")

        v-expansion-panel(style="margin-top:15px")
          v-expansion-panel-header(color="cyan")
            v-col(cols="8") 当前占用表格
          v-expansion-panel-content()
            v-col(v-if="locked_list.length == 0") 暂时没有表格被占用
            div(style="overflow-x:scroll;display:flex")
              v-col(v-for="excelData in locked_list", :key="excelData.id", cols="1", sm="4", md="3", lg="2")
                excellock-Card(title="Excel", :excelId="excelData.id", :dataFilter="filter",  @update_locked_list="on_update_list", @lock_alert="lock_alert_func", ref="excelCard")

        v-expansion-panel(style="margin:30px")
          v-expansion-panel-header(color="blue")
            v-col(cols="8") 表格列表
          v-expansion-panel-content
            excellock-Table(title="表格列表", @update_locked_list="on_update_list", @lock_alert="lock_alert_func", ref="excelTable")

    v-snackbar(v-model="lock_alert",top=true,left=true,:timeout="timeout",:color="alert_color",multi-line=true)
      span {{alert_text}}
      v-btn(dark,text,@click='lock_alert = false') close
</template>

<script>
import store from '@/store'

export default {
  data: () => ({
    filter: {
    },
    panel: [0, 1],
    commonList: [],
    locked_list: [],
    lock_alert: false,
    alert_text: '',
    alert_color: 'info',
    timeout: 3000
  }),
  computed: {
    user: () => store.getters.user
  },
  created: function() {
    this.update_list()
  },
  props: {
    source: String
  },
  methods: {
    get_locked_list: function() {
      this.axios
        .get('/excellock/excel/?lock_status=1')
        .then(res => {
          this.locked_list = res.data
        })
    },
    update_list: function() {
      this.get_locked_list()
    },
    lock_alert_func: function(msg) {
      this.lock_alert = true
      this.alert_color = msg.color
      this.alert_text = msg.text
    },
    on_update_list: function() {
      // 表格或者卡片有修改则更新所有内容
      let excelCards = this.$refs.excelCard
      let excelTable = this.$refs.excelTable
      excelCards.forEach(function(excel) {
        excel.get_excel_data()
      })
      excelTable.updateExcelList()
      this.get_locked_list()
    }
  },
  components: {
    'excellock-Card': () => import('@/components/excellock/ExcelCard.vue'),
    'excellock-Table': () => import('@/components/excellock/ExcelTable.vue')
  }
}
</script>

<style lang="sass">
.dingding
  display: inline-block
  width: 2em
  height: 2em
  vertical-align: -0.125em
  background: url('https://api.iconify.design/ant-design:dingding-outlined.svg?height=18&color=%23ffffff') no-repeat center center / contain
</style>

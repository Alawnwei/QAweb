<template lang='pug'>
div
  v-toolbar(fixed, dark)
    v-toolbar-title M6 FEEDBACK
    v-spacer
    // v-overflow-btn(:items=followers, label="跟进人", hide-details, dense, class="pa-0")
    v-btn-toggle(v-model="filter.toggleButtons", multiple, text, dark)
      v-btn(:value="1", text) 指派给我
      v-btn(:value="2", text) 我创建的
      v-btn(:value="3", text) 未提单
      v-btn(:value="4", text) 建议
      v-btn(:value="5", text) 缺陷
    v-text-field(prepend-icon="search", placeholder="搜索，支持按issue号、人名、内容检索", v-model="filter.search")
    // v-btn(text, dark) 提交
    v-toolbar-items.hidden-sm-and-down
      v-btn(text) 欢迎你，{{ user.firstName }}
  v-content
    v-container(fluid)
      div
        v-alert.my-0(dismissible, color="cyan") 提示：选中 issue 后按 ctrl + v 可以添加截图。点击下方操作按钮可以上传本地图片。
      feedback-iterator(title="所有反馈", :dataFilter="filter", :assignedToUserList="redmine.userList", @show-create-issue-dialog="onShowCreateIssueDialog", @on-click-zoom-in="onClickZoomIn")
  v-dialog(v-model="dialog.display", width="500", persistent)
    v-card
      v-card-title.headline 自动创建BUG单
      v-card-text
        v-form(ref="form")
          v-container(grid-list-md)
            v-layout(wrap)
              v-flex(xs12)
                v-text-field(label="主题", v-model="dialog.title", :value="dialog.content", required)
              v-flex(xs12)
                v-textarea(label="内容", v-model="dialog.content" :value="dialog.content", outlined, required)
              v-flex(xs12)
                v-autocomplete(label="版本", :items="redmine.versionList", v-model="dialog.version", outlined, required)
              v-flex(xs12)
                v-autocomplete(label="指派给", :items="redmine.userList", v-model="dialog.assignedTo",item-text="name", :rules="rules.assignedTo", item-value="mail", outlined, dense, required)
              v-flex(xs12)
                v-autocomplete(label="跟进QA", :items="redmine.qaUserList", v-model="dialog.followQA", item-text="name", item-value="mail", outlined, dense, required)
              v-flex(xs12)
                v-autocomplete(label="策划", :items="redmine.deUserList", v-model="dialog.followDE", item-text="name", item-value="id", outlined, dense, required)
              v-flex(xs12)
                v-menu(v-model="dialog.datePicker")
                  template(v-slot:activator="{ on }")
                    v-text-field(label="完成日期", v-model="dialog.completeDate", prepend-icon="event", v-on="on", :rules="rules.datePicker")
                  v-date-picker(v-model="dialog.completeDate", @input="dialog.datePicker=false", locale="zh-cn")
      v-card-actions.fixed
        v-spacer
        v-btn.primary(@click="submit") 开单
        v-btn.warning(@click="onClickCloseCreateIssueDialog") 关闭
  v-dialog(v-model="imagePreviewDialog.display", width="1000")
    v-card
      v-card-text
        v-img(:src="imagePreviewDialog.src", v-if="imagePreviewDialog.display")
  v-snackbar(v-model="createIssueSnackbar.display", :color="createIssueSnackbar.color", top, :timeout="createIssueSnackbar.timeout")
    span(v-html="createIssueSnackbar.text")
    v-btn(color="pink", text, @click="createIssueSnackbar.display=false")
</template>

<script>
import store from '@/store'
import _ from 'lodash'
import moment from 'moment'

export default {
  data: () => ({
    filter: {
      toggleButtons: [3, 4, 5],
      search: ''
    },
    redmine: {
      qaUserList: [],
      userList: [],
      deUserList: [],
      versionList: []
    },
    dialog: {
      issue_id: null,
      display: false,
      title: '',
      content: '',
      completeDate: '',
      datePicker: false,
      followQA: '',
      followDE: 264,
      assignedTo: null,
      version: null
    },
    rules: {
      assignedTo: [v => !!v || '请选择指派人']
    },
    createIssueSnackbar: {
      display: false,
      color: 'success',
      text: '',
      timeout: 10000
    },
    imagePreviewDialog: {
      display: false,
      src: null
    }
  }),
  computed: {
    user: () => store.getters.user
  },
  created: function() {
    this.updateRedmineUserList()

    // 以下接口还有问题，暂时先干掉
    // this.updateRedmineQAUserList()
    // this.updateRedmineDEUserList()
    // this.getVersionList()
    // this.updateDefaultVersion()
  },
  props: {
    source: String
  },
  methods: {
    clickNavigation: function(item) {
      this.$router.push(item.link)
    },
    onClickCloseCreateIssueDialog: function() {
      this.dialog = {
        issue_id: null,
        display: false,
        title: '',
        content: '',
        completeDate: moment().format('YYYY-MM-DD'),
        datePicker: false,
        followQA: '',
        followDE: 264,
        assignedTo: null,
        version: null
      }
      this.dialog.display = false
    },
    updateRedmineQAUserList: function() {
      this.axios
        .get('/ejoy/api/get_qa_user_list/', {
          params: {
            project: 'M6'
          }
        })
        .then(res => {
          this.redmine.qaUserList = _.sortBy(res.data.data, ['name'])
        })
    },
    updateRedmineUserList: function() {
      this.axios
        .get('/ejoy/api/get_user_list/', {
          params: {
            project: 'M6'
          }
        })
        .then(res => {
          this.redmine.userList = _.sortBy(res.data, ['first_name'])
        })
    },
    updateRedmineDEUserList: function() {
      this.axios
        .get('/ejoy/api/get_de_user_list/', {
          params: {
            project: 'M6'
          }
        })
        .then(res => {
          this.redmine.deUserList = _.sortBy(res.data.data, ['name'])
        })
    },
    getVersionList: function() {
      this.axios
        .get('/ejoy/api/get_version_list/', {
          params: {
            project: 'M6'
          }
        })
        .then(res => {
          this.redmine.versionList = _.sortBy(res.data.data, ['name'])
        })
    },
    onShowCreateIssueDialog: function(payload) {
      this.dialog.issue_id = payload.issue_id
      this.dialog.content = payload.content
      this.dialog.title = payload.title
      this.dialog.display = true
      this.dialog.completeDate = ''
    },
    onClickZoomIn: function(payload) {
      this.imagePreviewDialog.src = payload.url
      this.imagePreviewDialog.display = true
    },
    updateDefaultVersion: function(payload) {
      this.axios
        .get('/ejoy/api/get_current_version/', {
          params: {
            project: 'M6'
          }
        })
        .then(res => {
          this.dialog.version = res.data.data.name
        })
    },
    submit: function() {
      if (this.$refs.form.validate()) {
        this.axios
          .post('/feedback/api/redmine/create_bug/', {
            issue_id: this.dialog.issue_id,
            project: 'M6-缺陷跟踪',
            title: this.dialog.title,
            content: this.dialog.content,
            completeDate: this.dialog.completeDate,
            followQA: this.dialog.followQA,
            followDE: this.dialog.followDE,
            assignedTo: this.dialog.assignedTo,
            version: this.dialog.version
          })
          .then(res => {
            if (res.data.success) {
              this.createIssueSnackbar.color = 'success'
              this.createIssueSnackbar.text =
                '提单成功，详情见 <a href="=dts-bug&issueId=' +
                res.data.msg +
                '">BUG #' +
                res.data.msg +
                '</a>'
              this.createIssueSnackbar.display = true
            } else {
              this.createIssueSnackbar.color = 'error'
              this.createIssueSnackbar.text =
                '提单失败，错误信息：' + res.data.msg
              this.createIssueSnackbar.display = false
            }
          })
      }
    }
  },
  components: {
    'feedback-iterator': () => import('@/components/FeedbackIterator.vue')
  }
}
</script>

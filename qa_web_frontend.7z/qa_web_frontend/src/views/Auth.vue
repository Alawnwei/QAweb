<template lang="pug">
div
  button(@click='jump') 点我跳转到钉钉认证
</template>
<script>
import router from '../router.js'

const RESPONSE_TYPE = 'token'
const AUTH_URL = 'https://one.ejoy.com/oauth'
const PRODUCT_CODE = 10463
const SCOPE = 'profile'
const STATE = 'login'
const NONCE = Math.floor(Math.random() * 1000000)
const REDIRECT_URI =
  window.location.protocol +
  '//' +
  window.location.hostname +
  ':' +
  window.location.port +
  router.resolve('auth_callback').resolved.fullPath

export default {
  methods: {
    jump: () => {
      let url = AUTH_URL
      let params = {
        response_type: RESPONSE_TYPE,
        product_code: PRODUCT_CODE,
        scope: SCOPE,
        state: STATE,
        nonce: NONCE,
        redirect_uri: REDIRECT_URI
      }
      window.location.href =
        url +
        '?' +
        Object.entries(params)
          .map(e => e.join('='))
          .join('&')
    }
  }
}
</script>

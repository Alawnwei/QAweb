<template lang="pug">
  v-chip(
    color="cyan",
    close,
    close-icon="mdi-delete"
    @click:close="chip_del"
  ) {{user_data.first_name}}
</template>

<script>
import store from '@/store'
export default {
  data: () => ({
    user_data: {}
  }),
  computed: {
    user: () => store.getters.user
  },
  props: ['userId'],
  created: function() {
    this.get_user_data()
  },
  methods: {
    get_user_data: function() {
      let url = '/auth/users/' + this.userId
      this.axios
        .get(url, {})
        .then(res => {
          this.user_data = res.data
        })
    },
    chip_del: function() {
      console.log('click')
      this.$emit('chip_delete')
    }
  },
  watch: {
  },
  components: {
    'dutygroup': () => import('@/components/DutyGroup.vue')
  }
}
</script>

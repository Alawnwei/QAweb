<template lang='pug'>
div
  v-content
    v-container(fluid)
      div
        v-alert.my-0(color="blue") 白名单列表
        whitle-Table(title="申请列表", @apply_alert="alert_func")
    v-snackbar(v-model="apply_alert",top=true,left=true,:timeout="timeout",:color="alert_color",multi-line=true)
      span {{alert_text}}
      v-btn(dark,text,@click='apply_alert = false') close
</template>

<script>
import store from '@/store'

export default {
  data: () => ({
    white_list: [],
    apply_alert: false,
    alert_text: '',
    alert_color: 'info',
    timeout: 3000
  }),
  computed: {
    user: () => store.getters.user
  },
  created: function() {
  },
  props: {
    source: String
  },
  methods: {
    get_White_list: function() {
      this.axios
        .get('/get_white_list', {
        })
        .then(res => {
          this.white_list = res.data
          console.log(this.white_list)
        })
    },
    alert_func: function(msg) {
      this.apply_alert = true
      this.alert_color = msg.color
      this.alert_text = msg.text
    }
  },
  components: {
    'whitle-Table': () => import('@/components/WhiteTable.vue')
  }
}
</script>

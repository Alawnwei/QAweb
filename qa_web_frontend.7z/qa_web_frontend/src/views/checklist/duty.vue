<template lang="pug">
v-container
  v-row
    v-col(cols=2)
      v-row
        v-btn(color="cyan",@click="toadmin()", dark) 创建值班组
      v-row.mt-2
        v-btn(v-if="duty_type === 'week'", dark, color="cyan" @click="goPage('checklist/dutymanager/day')") 值日管理
        v-btn(v-else,color="cyan", dark, @click="goPage('checklist/dutymanager/week')") 值周管理
    v-col(cols=8)
      dutygroup(v-for="item in group_data",:key="item.id",:duty_id="item.id")
    v-col(cols=2)
      div(class="my_col")
        v-navigation-drawer(permanent,floating)
          //-
            v-list-item(v-if="duty_type==='week'")
              span 刷新节点
              v-form
                v-select(
                  v-model="select_day",
                  :items="day",
                  @change="changeRefresh"
                )
          v-list-item
            v-list-item-content
              v-list-item-title
                h2.strong(v-if="duty_type === 'week'") 当前值周
                h2.strong(v-else) 当前值日
          v-divider
          v-card(v-for="duty_group, i in duty_list", :key="i")
            v-card-title()
              span {{duty_group.name}}
            v-card-text
              v-list-item(v-for="username, j in duty_group.users",:key="j")
                v-list-item-content
                  v-list-item-title {{ username }}
</template>

<script>
import store from '@/store'
export default {
  data: () => ({
    group_data: [],
    duty_type: '',
    day: [
      {
        value: 0,
        text: '星期一'
      },
      {
        value: 1,
        text: '星期二'
      },
      {
        value: 2,
        text: '星期三'
      },
      {
        value: 3,
        text: '星期四'
      },
      {
        value: 4,
        text: '星期五'
      },
      {
        value: 5,
        text: '星期六'
      },
      {
        value: 6,
        text: '星期日'
      }
    ],
    select_day: 0,
    duty_list: []
  }),
  computed: {
    user: () => store.getters.user
  },
  props: {
  },
  created: function() {
    this.duty_type = this.$route.params.type
    this.get_duty_groups()
  },
  methods: {
    get_duty_groups: function() {
      let params = {}
      if (this.duty_type === 'week') {
        params = {
          refresh_type: 2
        }
      } else {
        params = {
          refresh_type: 1
        }
      }

      this.axios
        .get('/checklist/duty_groups/', {
          params: params
        })
        .then(res => {
          this.group_data = res.data
          // console.log(this.group_data)
        })
    },
    dealFirstDuty: async function() {
      for (let i in this.group_data) {
        let dutyData = {}
        let group = this.group_data[i]
        console.log(group)
        dutyData.name = group.name
        dutyData.users = []
        for (let j in group.duty_order[0]) {
          let uid = group.duty_order[0][j]
          let uname = await this.getUserNameById(uid)
          dutyData.users.push(uname)
        }
        this.duty_list.push(dutyData)
      }
    },
    getUserNameById: async function(uid) {
      let url = '/auth/users/' + uid
      let name = await this.axios
        .get(url, {})
        .then(res => {
          let userData = res.data
          return userData.first_name
        })
      return name
    },
    changeRefresh: function() {
      console.log(this.select_day)
    },
    goPage: function(page) {
      window.location.href = '/' + page
    },
    toadmin: function() {
      window.location.href = this.axios.defaults.baseURL + '/admin/checklist/dutygroup/'
    }
  },
  watch: {
    group_data: function(newV, oldV) {
      this.dealFirstDuty()
    }
  },
  components: {
    'dutygroup': () => import('@/components/DutyGroup.vue')
  }
}
</script>

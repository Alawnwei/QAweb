<template lang="pug">
    v-app
        div(data-app="true")
            v-app-bar(fixed, dark, app, clipped-left)
                v-toolbar-title 性能报告
                v-spacer
            v-content
                v-container(fluid='')
                    v-row
                        v-col(cols="12", sm="2")
                        v-col(cols="12", sm="10")
                            router-view

</template>

<script>
import store from '@/store'

export default {
  data: () => ({}),
  computed: {
    user: () => store.getters.user
  },
  props: {},
  methods: {},
  components: {
  }
}
</script>

<template>
    <v-container id="inspire">
        <v-row>
            <v-col cols="8">
                <DeviceSelector @changeDevice="changeDevice($event)"/>
            </v-col>
            <v-col cols="4">
                <GMPanel></GMPanel>
            </v-col>
        </v-row>
        <v-row>
            <v-col cols="12">
                <LogWidget :log-topic="currentLogTopic" />
            </v-col>
        </v-row>
    </v-container>
</template>
<script>

import LogWidget from '../../../components/LogWidget'
import DeviceSelector from '../../../components/DeviceSelector'
import GMPanel from '../../../components/GMPanel'

export default {
  components: {
    DeviceSelector,
    LogWidget,
    GMPanel
  },
  data: function() {
    return {
      boomerServer: 'http://' + process.env.VUE_APP_BOOMER_SERVER,
      currentLogTopic: '',
      currentDeviceId: '127.0.0.1'
    }
  },
  watch: {
  },
  computed: {
  },
  methods: {

    changeDevice: function(newDevice) {
      this.currentLogTopic = newDevice.logTopic
      this.currentDeviceId = newDevice.ip
    }

  },
  mounted: function() {
  }
}

</script>

<style scoped>
    .editor {
        width: 100%;
        height: calc(75vh);
    }
</style>
